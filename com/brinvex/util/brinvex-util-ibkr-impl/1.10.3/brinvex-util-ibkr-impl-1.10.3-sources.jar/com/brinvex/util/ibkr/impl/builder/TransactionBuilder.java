package com.brinvex.util.ibkr.impl.builder;

import com.brinvex.util.ibkr.api.model.Country;
import com.brinvex.util.ibkr.api.model.Currency;
import com.brinvex.util.ibkr.api.model.InstrumentType;
import com.brinvex.util.ibkr.api.model.FinTransaction;
import com.brinvex.util.ibkr.api.model.FinTransactionType;
import lombok.Setter;
import lombok.experimental.Accessors;

import java.math.BigDecimal;
import java.time.LocalDate;

@Setter
@Accessors(fluent = true, chain = true)
public class TransactionBuilder {

    private String id;
    private LocalDate reportDate;
    private FinTransactionType type;
    private Country country;
    private String symbol;
    private String isin;
    private String figi;
    private InstrumentType instrumentType;
    private BigDecimal qty;
    private Currency currency;
    private BigDecimal price;
    private BigDecimal grossValue;
    private BigDecimal netValue;
    private BigDecimal tax;
    private BigDecimal fees;
    private LocalDate settleDate;
    private String description;
    private String extraDateTimeStr;

    public FinTransaction build() {
        return new FinTransaction(
                this.id,
                this.reportDate,
                this.type,
                this.country,
                this.symbol,
                this.isin,
                this.figi,
                this.instrumentType,
                this.qty,
                this.currency,
                this.price,
                this.grossValue,
                this.netValue,
                this.tax,
                this.fees,
                this.settleDate,
                this.description,
                this.extraDateTimeStr
        );
    }
}
