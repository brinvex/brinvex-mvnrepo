package com.brinvex.fintracker.core.impl.dao;

import com.brinvex.util.persistence.api.AbstractEntityDao;
import jakarta.persistence.EntityManager;

import java.io.Serializable;
import java.util.function.Supplier;

abstract class BaseDao<ENTITY, ID extends Serializable> extends AbstractEntityDao<ENTITY, ID> {

    private final Supplier<EntityManager> entityManagerSupplier;

    protected BaseDao(Class<ENTITY> entityType, Class<ID> idType, Supplier<EntityManager> entityManagerSupplier) {
        super(entityType, idType);
        this.entityManagerSupplier = entityManagerSupplier;
    }

    @Override
    protected EntityManager entityManager() {
        return entityManagerSupplier.get();
    }
}
