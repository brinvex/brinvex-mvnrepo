package com.brinvex.fintracker.core.api.domain.vo;

import com.brinvex.fintracker.core.api.domain.enu.Currency;

import java.math.BigDecimal;

import static java.util.Objects.requireNonNull;

public record Money(
        Currency ccy,
        BigDecimal amount
) {
    public Money {
        requireNonNull(ccy);
        requireNonNull(amount);
    }

    public Money(String ccy, BigDecimal amount) {
        this(Currency.valueOf(ccy), amount);
    }
}
