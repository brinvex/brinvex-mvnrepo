package com.brinvex.fintracker.core.api;

public interface CoreModule extends FinTrackerModule {
}
