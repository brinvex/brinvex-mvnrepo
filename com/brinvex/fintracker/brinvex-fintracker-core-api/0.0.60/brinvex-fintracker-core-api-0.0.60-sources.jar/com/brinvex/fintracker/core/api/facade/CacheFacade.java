package com.brinvex.fintracker.core.api.facade;

import java.util.Optional;
import java.util.concurrent.Callable;

public interface CacheFacade {

    <T> Optional<T> get(Object key);

    <T> T get(Object key, Class<T> type);

    <T> T get(Object key, Callable<T> valueLoader);

    void put(Object key, Object value);

    <T> Optional<T> putIfAbsent(Object key, Object value);

    void evict(Object key);

    boolean evictIfPresent(Object key);

    boolean invalidate();
}
