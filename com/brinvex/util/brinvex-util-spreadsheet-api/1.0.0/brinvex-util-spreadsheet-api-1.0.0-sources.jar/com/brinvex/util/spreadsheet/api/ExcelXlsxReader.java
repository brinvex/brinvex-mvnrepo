package com.brinvex.util.spreadsheet.api;

public interface ExcelXlsxReader extends ExcelReader{
}
