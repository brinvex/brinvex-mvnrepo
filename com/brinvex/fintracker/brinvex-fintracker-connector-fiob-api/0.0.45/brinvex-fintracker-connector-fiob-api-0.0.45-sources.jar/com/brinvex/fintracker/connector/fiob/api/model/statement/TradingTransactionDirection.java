package com.brinvex.fintracker.connector.fiob.api.model.statement;

public enum TradingTransactionDirection {

    BUY,

    SELL,

    BANK_TRANSFER,

    CURRENCY_CONVERSION,
}
