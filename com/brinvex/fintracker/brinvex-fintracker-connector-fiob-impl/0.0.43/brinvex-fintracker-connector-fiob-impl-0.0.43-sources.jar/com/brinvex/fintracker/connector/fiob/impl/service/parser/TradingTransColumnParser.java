package com.brinvex.fintracker.connector.fiob.impl.service.parser;

import com.brinvex.fintracker.connector.fiob.api.model.statement.Lang;
import com.brinvex.fintracker.connector.fiob.api.model.statement.TradingTransaction;
import com.brinvex.util.java.StringUtil;

import java.util.Set;
import java.util.function.BiConsumer;
import java.util.function.BiFunction;
import java.util.function.Function;


@SuppressWarnings("SpellCheckingInspection")
enum TradingTransColumnParser {

    TRADE_DATE("Dátum obchodu", "Datum obchodu", "Trade Date", FiobParsingUtil::toFioDateTime, TradingTransaction.TradingTransactionBuilder::tradeDate),
    DIRECTION("Smer", "Směr", "Direction", FiobParsingUtil::toDirection, TradingTransaction.TradingTransactionBuilder::direction),
    SYMBOL("Symbol", "Symbol", "Symbol", StringUtil::stripToNull, TradingTransColumnParser::fillSymbol),
    PRICE("Cena", "Cena", "Price", FiobParsingUtil::toDecimal, TradingTransaction.TradingTransactionBuilder::price),
    SHARES("Počet", "Počet", "Shares", FiobParsingUtil::toDecimal, TradingTransaction.TradingTransactionBuilder::shares),
    CURRENCY("Mena", "Měna", "Currency", StringUtil::stripToNull, TradingTransaction.TradingTransactionBuilder::ccy),
    VOLUME_CZK("Objem v CZK", "Objem v CZK", "Volume (CZK)", FiobParsingUtil::toDecimal, TradingTransaction.TradingTransactionBuilder::volumeCzk),
    FEES_CZK("Poplatky v CZK", "Poplatky v CZK", "Fees", FiobParsingUtil::toDecimal, TradingTransaction.TradingTransactionBuilder::feesCzk),
    VOLUME_USD("Objem v USD", "Objem v USD", "Volume in USD", FiobParsingUtil::toDecimal, TradingTransaction.TradingTransactionBuilder::volumeUsd),
    FEES_USD("Poplatky v USD", "Poplatky v USD", "Fees (USD)", FiobParsingUtil::toDecimal, TradingTransaction.TradingTransactionBuilder::feesUsd),
    VOLUME_EUR("Objem v EUR", "Objem v EUR", "Volume (EUR)", FiobParsingUtil::toDecimal, TradingTransaction.TradingTransactionBuilder::volumeEur),
    FEES_EUR("Poplatky v EUR", "Poplatky v EUR", "Fees (EUR)", FiobParsingUtil::toDecimal, TradingTransaction.TradingTransactionBuilder::feesEur),
    MARKET("Trh", "Trh", "Market", StringUtil::stripToNull, TradingTransaction.TradingTransactionBuilder::market),
    INSTRUMENT_NAME("Názov FN", "Název CP", "Title", StringUtil::stripToNull, TradingTransaction.TradingTransactionBuilder::instrumentName),
    SETTLEMENT_DATE("Dátum vysporiadania", "Datum vypořádání", "Settlement Date", FiobParsingUtil::toFioDate, TradingTransaction.TradingTransactionBuilder::settlementDate),
    STATUS("Stav", "Stav", "Status", StringUtil::stripToNull, TradingTransaction.TradingTransactionBuilder::status),
    ORDER_ID("Pokyn ID", "Pokyn ID", "Order ID", StringUtil::stripToNull, TradingTransaction.TradingTransactionBuilder::orderId),
    TEXT("Text FIO", "Text FIO", "Text FIO", StringUtil::stripToNull, TradingTransaction.TradingTransactionBuilder::text),
    USER_COMMENTS("Užívateľská identifikácia", "Uživatelská identifikace", "User Comments", StringUtil::stripToNull, TradingTransaction.TradingTransactionBuilder::userComments),
    ;

    public static final Set<TradingTransColumnParser> STANDARD_COLUMNS = Set.of(
            TRADE_DATE,
            DIRECTION,
            SYMBOL,
            PRICE,
            SHARES,
            CURRENCY,
            VOLUME_CZK,
            FEES_CZK,
            VOLUME_USD,
            FEES_USD,
            VOLUME_EUR,
            FEES_EUR,
            TEXT
    );

    private final String titleSK;

    private final String titleCZ;

    private final String titleEN;

    private final BiFunction<Lang, String, ?> mapper;

    private final BiConsumer<TradingTransaction.TradingTransactionBuilder, ?> filler;

    <T> TradingTransColumnParser(
            String titleSK,
            String titleCZ,
            String titleEN,
            BiFunction<Lang, String, T> mapper,
            BiConsumer<TradingTransaction.TradingTransactionBuilder, T> filler
    ) {
        this.titleSK = titleSK;
        this.titleCZ = titleCZ;
        this.titleEN = titleEN;
        this.mapper = mapper;
        this.filler = filler;
    }

    @SuppressWarnings("unused")
    <T> TradingTransColumnParser(
            String titleSK,
            String titleCZ,
            String titleEN,
            Function<String, T> mapper,
            BiConsumer<TradingTransaction.TradingTransactionBuilder, T> filler
    ) {
        this(titleSK, titleCZ, titleEN, (lang, s) -> mapper.apply(s), filler);
    }

    public static TradingTransColumnParser ofTitle(String title, Lang lang) {
        for (TradingTransColumnParser value : values()) {
            if (value.getTitle(lang).equals(title)) {
                return value;
            }
        }
        return null;
    }

    public String getTitle(Lang lang) {
        return switch (lang) {
            case CZ -> titleCZ;
            case EN -> titleEN;
            case SK -> titleSK;
        };
    }

    private static void fillSymbol(TradingTransaction.TradingTransactionBuilder tranBuilder, String rawSymbol) {
        if (rawSymbol != null && !rawSymbol.isBlank()) {
            tranBuilder.rawSymbol(rawSymbol);
            tranBuilder.symbol(rawSymbol.endsWith("*") ? rawSymbol.substring(0, rawSymbol.length() - 1) : rawSymbol);
        }
    }

    public void fill(TradingTransaction.TradingTransactionBuilder tranBuilder, String cell, Lang lang) {
        Object value = mapper.apply(lang, cell);
        @SuppressWarnings("unchecked")
        BiConsumer<TradingTransaction.TradingTransactionBuilder, Object> filler = (BiConsumer<TradingTransaction.TradingTransactionBuilder, Object>) this.filler;
        filler.accept(tranBuilder, value);
    }
}
