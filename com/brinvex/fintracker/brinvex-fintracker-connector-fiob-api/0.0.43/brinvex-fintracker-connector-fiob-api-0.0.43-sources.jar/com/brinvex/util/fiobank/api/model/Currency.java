package com.brinvex.util.fiobank.api.model;

public enum Currency {

    CZK,

    EUR,

    USD,

}
