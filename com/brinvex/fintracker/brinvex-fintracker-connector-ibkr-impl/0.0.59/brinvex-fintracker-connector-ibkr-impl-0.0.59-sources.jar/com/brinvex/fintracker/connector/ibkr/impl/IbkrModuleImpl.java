package com.brinvex.fintracker.connector.ibkr.impl;

import com.brinvex.fintracker.connector.ibkr.api.IbkrModule;
import com.brinvex.fintracker.connector.ibkr.api.service.IbkrDms;
import com.brinvex.fintracker.connector.ibkr.api.service.IbkrFetcher;
import com.brinvex.fintracker.connector.ibkr.api.service.IbkrFinTransactionMapper;
import com.brinvex.fintracker.connector.ibkr.api.service.IbkrPtfProgressProvider;
import com.brinvex.fintracker.connector.ibkr.api.service.IbkrStatementMerger;
import com.brinvex.fintracker.connector.ibkr.api.service.IbkrStatementParser;
import com.brinvex.fintracker.connector.ibkr.impl.service.IbkrDmsImpl;
import com.brinvex.fintracker.connector.ibkr.impl.service.IbkrFetcherImpl;
import com.brinvex.fintracker.connector.ibkr.impl.service.IbkrFinTransactionMapperImpl;
import com.brinvex.fintracker.connector.ibkr.impl.service.IbkrPtfProgressProviderImpl;
import com.brinvex.fintracker.connector.ibkr.impl.service.IbkrStatementMergerImpl;
import com.brinvex.fintracker.connector.ibkr.impl.service.IbkrStatementParserImpl;
import com.brinvex.fintracker.core.api.FinTrackerModule;
import com.brinvex.fintracker.core.api.FinTrackerModuleContext;
import com.brinvex.fintracker.core.api.FinTrackerModuleFactory;
import com.brinvex.fintracker.core.api.provider.Provider;
import com.brinvex.fintracker.core.api.provider.PtfProgressProvider;

import java.util.List;
import java.util.SequencedCollection;
import java.util.Set;

import static java.util.Collections.emptyList;

public class IbkrModuleImpl implements IbkrModule, FinTrackerModule {

    public static class IbkrModuleFactory implements FinTrackerModuleFactory<IbkrModule> {

        @Override
        public Class<IbkrModule> moduleType() {
            return IbkrModule.class;
        }

        @Override
        public Set<Class<? extends Provider<?, ?>>> providerTypes() {
            return Set.of(PtfProgressProvider.class);
        }

        @Override
        public IbkrModule createModule(FinTrackerModuleContext moduleCtx) {
            return new IbkrModuleImpl(moduleCtx);
        }
    }

    private final FinTrackerModuleContext moduleCtx;

    public IbkrModuleImpl(FinTrackerModuleContext moduleCtx) {
        this.moduleCtx = moduleCtx;
    }

    @Override
    public SequencedCollection<Provider<?, ?>> providers(Class<? extends Provider<?, ?>> providerType) {
        if (providerType == PtfProgressProvider.class) {
            return List.of(ptfProgressProvider());
        }
        return emptyList();
    }

    @Override
    public IbkrStatementMerger statementMerger() {
        return moduleCtx.singletonService(IbkrStatementMerger.class, IbkrStatementMergerImpl::new);
    }

    @Override
    public IbkrStatementParser statementParser() {
        return moduleCtx.singletonService(IbkrStatementParser.class, IbkrStatementParserImpl::new);
    }

    @Override
    public IbkrFinTransactionMapper finTransactionMapper() {
        return moduleCtx.singletonService(IbkrFinTransactionMapper.class, IbkrFinTransactionMapperImpl::new);
    }

    @Override
    public IbkrDms dms() {
        return moduleCtx.singletonService(IbkrDms.class, () -> new IbkrDmsImpl(moduleCtx.dms()));
    }

    @Override
    public IbkrFetcher fetcher() {
        return moduleCtx.singletonService(IbkrFetcher.class, IbkrFetcherImpl::new);
    }

    @Override
    public IbkrPtfProgressProvider ptfProgressProvider() {
        return moduleCtx.singletonService(IbkrPtfProgressProvider.class, () -> new IbkrPtfProgressProviderImpl(
                dms(),
                statementParser(),
                fetcher(),
                statementMerger(),
                finTransactionMapper()
        ));
    }
}
