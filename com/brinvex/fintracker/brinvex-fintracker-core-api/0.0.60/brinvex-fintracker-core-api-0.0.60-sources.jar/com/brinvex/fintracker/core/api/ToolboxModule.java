package com.brinvex.fintracker.core.api;

import com.brinvex.fintracker.core.api.facade.JsonMapperFacade;
import com.brinvex.fintracker.core.api.facade.PdfReaderFacade;
import com.brinvex.fintracker.core.api.facade.ValidatorFacade;

public interface ToolboxModule extends FinTrackerModule {

    ValidatorFacade validator();

    PdfReaderFacade pdfReader();

    JsonMapperFacade jsonMapper();
}
