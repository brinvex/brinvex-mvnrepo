package com.brinvex.util.spreadsheet.impl;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.ss.util.CellReference;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

@SuppressWarnings("SameParameterValue")
public class AbstractReaderImplPoi {

    protected List<Map<String, Object>> readColumns(Map<String, Class<?>> columnNamesAndTypes, Sheet sheet, int rowsToSkip, boolean breakIfEmptyRow) {

        List<Map<String, Object>> results = new ArrayList<>();

        for (Row row : sheet) {
            int rowNum = row.getRowNum();
            if (rowsToSkip > rowNum) {
                continue;
            }

            Map<String, Object> resultRow = new LinkedHashMap<>();
            boolean atLeastOneNotNull = false;
            for (Map.Entry<String, Class<?>> e : columnNamesAndTypes.entrySet()) {
                String colName = e.getKey();
                Class<?> expectedCellValueType = e.getValue();

                Cell cell = row.getCell(CellReference.convertColStringToIndex(colName));
                Object cellValue = getCellValue(cell, expectedCellValueType);

                if (cellValue != null) {
                    resultRow.put(colName, cellValue);
                    atLeastOneNotNull = true;
                }
            }
            if (atLeastOneNotNull) {
                results.add(resultRow);
            } else {
                if (breakIfEmptyRow) {
                    break;
                }
            }
        }
        return results;
    }

    protected List<Map<String, Object>> readTable(Map<String, Class<?>> headerNamesAndTypes, Sheet sheet, boolean breakIfEmptyRow) {
        Set<String> headers = headerNamesAndTypes.keySet();

        Map<String, Integer> headerToColIndexMap = new LinkedHashMap<>();
        List<Map<String, Object>> results = new ArrayList<>();

        int prevRovNum = -1;
        for (Row row : sheet) {
            if (headerToColIndexMap.isEmpty()) {
                for (Cell cell : row) {
                    Class<?> expectedCellValueType = Object.class;
                    Object cellValue = getCellValue(cell, expectedCellValueType);
                    if (cellValue instanceof String && headers.contains(cellValue)) {
                        headerToColIndexMap.put((String) cellValue, cell.getColumnIndex());
                        prevRovNum = row.getRowNum();
                    }
                }
            } else {
                int rowNum = row.getRowNum();
                if (breakIfEmptyRow && prevRovNum + 1 != rowNum) {
                    break;
                }
                prevRovNum = rowNum;

                Set<String> nonFoundHeaders = new HashSet<>(headers);
                nonFoundHeaders.removeAll(headerToColIndexMap.keySet());
                if (!nonFoundHeaders.isEmpty()) {
                    throw new IllegalArgumentException("Headers not found: " + headerNamesAndTypes);
                }
                Map<String, Object> resultRow = new LinkedHashMap<>();
                boolean atLeastOneNotNull = false;
                for (Map.Entry<String, Integer> e : headerToColIndexMap.entrySet()) {
                    String header = e.getKey();
                    Integer colIndex = e.getValue();
                    Class<?> expectedCellValueType = headerNamesAndTypes.get(header);

                    Cell cell = row.getCell(colIndex);
                    Object cellValue = getCellValue(cell, expectedCellValueType);

                    if (cellValue != null) {
                        resultRow.put(header, cellValue);
                        atLeastOneNotNull = true;
                    }
                }
                if (atLeastOneNotNull) {
                    results.add(resultRow);
                } else {
                    if (breakIfEmptyRow) {
                        break;
                    }
                }
            }
        }
        return results;
    }

    protected Object getCellValue(Cell cell, Class<?> expectedType) {
        if (cell == null) {
            return null;
        }
        CellType cellType = cell.getCellType();
        switch (cellType) {
            case NUMERIC, FORMULA -> {
                CellStyle cellStyle = cell.getCellStyle();
                short cellDataFormat = cellStyle.getDataFormat();
                if (cellDataFormat >= 14 && cellDataFormat <= 22) {
                    if (expectedType.isAssignableFrom(LocalDateTime.class)) {
                        return cell.getLocalDateTimeCellValue();
                    }
                    if (expectedType.isAssignableFrom(LocalDate.class)) {
                        LocalDateTime dateTime = cell.getLocalDateTimeCellValue();
                        return dateTime == null ? null : dateTime.toLocalDate();
                    }
                    if (expectedType.isAssignableFrom(BigDecimal.class)) {
                        double numericCellValue = cell.getNumericCellValue();
                        return BigDecimal.valueOf(numericCellValue);
                    }
                } else {
                    if (expectedType.isAssignableFrom(BigDecimal.class)) {
                        double numericCellValue = cell.getNumericCellValue();
                        return BigDecimal.valueOf(numericCellValue);
                    }
                    if (expectedType.isAssignableFrom(LocalDateTime.class)) {
                        return cell.getLocalDateTimeCellValue();
                    }
                    if (expectedType.isAssignableFrom(LocalDate.class)) {
                        LocalDateTime dateTime = cell.getLocalDateTimeCellValue();
                        return dateTime == null ? null : dateTime.toLocalDate();
                    }
                }
            }
            case STRING -> {
                if (expectedType.isAssignableFrom(String.class)) {
                    return cell.getStringCellValue();
                }
            }
            case BLANK -> {
                return null;
            }
            case BOOLEAN -> {
                if (expectedType.isAssignableFrom(boolean.class)) {
                    return cell.getBooleanCellValue();
                }
                if (expectedType.isAssignableFrom(Boolean.class)) {
                    return cell.getBooleanCellValue();
                }
            }
        }
        throw new IllegalStateException(
                "Unsupported cell type: " + cellType + " of cell '" + cell + "' at address " + cell.getAddress() + ", expectedCellType=" + expectedType);
    }

}
