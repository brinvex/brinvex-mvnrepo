/*
package com.brinvex.fintracker.core.api.facade;

import java.io.IOException;
import java.net.URI;
import java.nio.charset.Charset;
import java.util.Map;

import static java.util.Collections.emptyMap;

public interface HttpClientFacade {

    sealed interface HttpResponse<BODY> {

        int statusCode();

        BODY body();
    }

    record StringHttpResponse(@Override int statusCode, @Override String body) implements HttpResponse<String> {
    }

    record BytesHttpResponse(@Override int statusCode, @Override byte[] body) implements HttpResponse<byte[]> {
    }

    default StringHttpResponse doGet(URI uri, Charset respCharset) throws IOException {
        return doGet(uri, emptyMap(), respCharset);
    }

    StringHttpResponse doGet(URI uri, Map<String, Object> headers, Charset respCharset) throws IOException;

    default BytesHttpResponse doGet(URI uri) throws IOException {
        return doGet(uri, emptyMap());
    }

    BytesHttpResponse doGet(URI uri, Map<String, Object> headers) throws IOException;


    default StringHttpResponse doPost(URI uri, String payload, Charset respCharset) throws IOException {
        return doPost(uri, emptyMap(), payload, respCharset);
    }

    StringHttpResponse doPost(URI uri, Map<String, Object> headers, String payload, Charset respCharset) throws IOException;

    BytesHttpResponse doPost(URI uri, Map<String, Object> headers, String payload) throws IOException;

}
*/
