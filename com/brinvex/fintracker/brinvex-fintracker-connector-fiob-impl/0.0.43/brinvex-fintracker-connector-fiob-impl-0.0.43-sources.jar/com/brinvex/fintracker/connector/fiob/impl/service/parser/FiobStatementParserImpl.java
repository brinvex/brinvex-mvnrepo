package com.brinvex.fintracker.connector.fiob.impl.service.parser;

import com.brinvex.fintracker.connector.fiob.api.model.statement.Statement;
import com.brinvex.fintracker.connector.fiob.api.service.FiobStatementParser;

public class FiobStatementParserImpl implements FiobStatementParser {

    private final TradingTransStatementParser tradingTransStatementParser;

    public FiobStatementParserImpl() {
        tradingTransStatementParser = new TradingTransStatementParser();
    }

    @Override
    public Statement.TradingTransStatement parseTradingTransStatement(String statementCsvContent) {
        return tradingTransStatementParser.parseTransStatement(statementCsvContent);
    }
}
