package com.brinvex.fintracker.connector.amnd.api.service;

import com.brinvex.fintracker.connector.amnd.api.model.AmndTransStatementDocKey;

public interface AmndDms {

    AmndTransStatementDocKey getTradingAccountStatementDocKey(String accountNumber);

    byte[] getStatementContent(AmndTransStatementDocKey docKey);

}
