package com.brinvex.fintracker.connector.fiob.api.service;

import com.brinvex.fintracker.connector.fiob.api.model.FiobAccount;
import com.brinvex.fintracker.connector.fiob.api.model.statement.Statement;

import java.time.LocalDate;

public interface FiobFetcher {

    String fetchStatement(
            Class<? extends Statement> statementType,
            FiobAccount account,
            LocalDate fromDateIncl,
            LocalDate toDateIncl
    );
}
