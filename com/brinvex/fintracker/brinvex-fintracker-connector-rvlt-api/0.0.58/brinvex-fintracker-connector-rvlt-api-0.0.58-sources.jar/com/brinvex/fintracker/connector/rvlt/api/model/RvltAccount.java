package com.brinvex.fintracker.connector.rvlt.api.model;

import com.brinvex.fintracker.core.api.domain.enu.Currency;

import java.util.Map;

public record RvltAccount(
        String accountNumber,
        String accountName,
        Currency pcy
) {
    public RvltAccount {
        if (accountNumber == null || accountNumber.isBlank()) {
            throw new IllegalArgumentException("accountNumber must not be null or blank");
        }
        if (accountName != null && accountName.isBlank()) {
            throw new IllegalArgumentException("accountName must not be blank");
        }
        if (pcy == null) {
            throw new IllegalArgumentException("pcy must not be null");
        }
    }

    public static RvltAccount of(Map<String, String> props) {
        String accountNumber = props.get("accountNumber");
        if (accountNumber == null || accountNumber.isEmpty()) {
            return null;
        }
        String accountName = props.get("accountName");
        Currency pcy = Currency.valueOf(props.get("pcy"));
        return new RvltAccount(accountNumber, accountName, pcy);
    }

}
