package com.brinvex.fintracker.connector.fiob.api.service;

import com.brinvex.fintracker.connector.fiob.api.model.FiobAccount;

import java.time.LocalDate;

public interface FiobFetcher {

    String fetchTransStatement(
            FiobAccount account,
            LocalDate fromDateIncl,
            LocalDate toDateIncl
    );

    String fetchSnapshotStatement(
            FiobAccount account,
            LocalDate date
    );

    FiobFetcher newSessionReusingFetcher();
}
