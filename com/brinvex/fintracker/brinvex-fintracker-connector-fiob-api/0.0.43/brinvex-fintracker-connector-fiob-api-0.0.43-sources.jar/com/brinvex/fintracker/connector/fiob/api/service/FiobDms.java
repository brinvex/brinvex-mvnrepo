package com.brinvex.fintracker.connector.fiob.api.service;


import com.brinvex.fintracker.connector.fiob.api.model.FiobDocKey;
import com.brinvex.fintracker.connector.fiob.api.model.FiobDocKey.TradingTransDocKey;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

public interface FiobDms {

    List<TradingTransDocKey> getTradingTransDocKeys(String accountId, LocalDate fromDateIncl, LocalDate toDateIncl);

    String getStatementContent(FiobDocKey docKey);

    boolean putTradingTransStatement(TradingTransDocKey docKey, String content);

    void delete(FiobDocKey docKey);

    void putMetaProperties(String accountId, String metaFileName, Map<String, String> metaProperties);

    Map<String, String> getMetaProperties(String accountId, String metaFileName);
}
