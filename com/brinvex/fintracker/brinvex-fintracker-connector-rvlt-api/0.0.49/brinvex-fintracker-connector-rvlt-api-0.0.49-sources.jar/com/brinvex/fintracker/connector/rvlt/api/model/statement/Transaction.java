package com.brinvex.fintracker.connector.rvlt.api.model.statement;

import lombok.Builder;

import java.math.BigDecimal;
import java.time.ZonedDateTime;

@Builder(toBuilder = true)
public record Transaction(
        ZonedDateTime date,
        String ccy,
        String country,
        String symbol,
        TransactionType type,
        BigDecimal qty,
        BigDecimal price,
        TransactionSide side,
        BigDecimal value,
        String securityName,
        BigDecimal grossAmount,
        BigDecimal fees,
        BigDecimal commission,
        BigDecimal withholdingTax,
        String isin
) {
}
