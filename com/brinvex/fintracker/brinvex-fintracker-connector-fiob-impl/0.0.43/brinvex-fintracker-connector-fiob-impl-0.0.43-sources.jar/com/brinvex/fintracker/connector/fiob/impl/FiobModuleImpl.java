package com.brinvex.fintracker.connector.fiob.impl;

import com.brinvex.fintracker.connector.fiob.api.FiobModule;
import com.brinvex.fintracker.connector.fiob.api.service.FiobDms;
import com.brinvex.fintracker.connector.fiob.api.service.FiobFetcher;
import com.brinvex.fintracker.connector.fiob.api.service.FiobFinTransactionMapper;
import com.brinvex.fintracker.connector.fiob.api.service.FiobStatementParser;
import com.brinvex.fintracker.connector.fiob.impl.service.FiobDmsImpl;
import com.brinvex.fintracker.connector.fiob.impl.service.FiobFetcherImpl;
import com.brinvex.fintracker.connector.fiob.impl.service.mapper.FiobFinTransactionMapperImpl;
import com.brinvex.fintracker.connector.fiob.impl.service.parser.FiobStatementParserImpl;
import com.brinvex.fintracker.core.api.infra.FinTrackerModule;
import com.brinvex.fintracker.core.api.infra.FinTrackerModuleContext;
import com.brinvex.fintracker.core.api.infra.FinTrackerModuleFactory;
import com.brinvex.fintracker.core.api.infra.FinTrackerSupport;

public class FiobModuleImpl implements FiobModule, FinTrackerModule {

    public static class FiobModuleFactory implements FinTrackerModuleFactory<FiobModule> {

        @Override
        public Class<FiobModule> moduleType() {
            return FiobModule.class;
        }

        @Override
        public FiobModule createModule(FinTrackerModuleContext moduleCtx) {
            return new FiobModuleImpl(moduleCtx);
        }
    }

    private final FinTrackerModuleContext moduleCtx;

    public FiobModuleImpl(FinTrackerModuleContext moduleCtx) {
        this.moduleCtx = moduleCtx;
    }

    @Override
    public FinTrackerSupport support() {
        return moduleCtx.support();
    }

    @Override
    public FiobFetcher fetcher() {
        return moduleCtx.singletonService(FiobFetcher.class, FiobFetcherImpl::new);
    }

    @Override
    public FiobDms dms() {
        return moduleCtx.singletonService(FiobDms.class, () -> new FiobDmsImpl(moduleCtx.dms()));
    }

    @Override
    public FiobStatementParser statementParser() {
        return moduleCtx.singletonService(FiobStatementParser.class, FiobStatementParserImpl::new);
    }

    @Override
    public FiobFinTransactionMapper finTransactionMapper() {
        return moduleCtx.singletonService(FiobFinTransactionMapper.class, FiobFinTransactionMapperImpl::new);
    }

}
