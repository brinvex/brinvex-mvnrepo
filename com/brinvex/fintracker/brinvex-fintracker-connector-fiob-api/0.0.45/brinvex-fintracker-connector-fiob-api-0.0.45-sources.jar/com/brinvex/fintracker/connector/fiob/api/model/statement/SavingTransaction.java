package com.brinvex.fintracker.connector.fiob.api.model.statement;

import lombok.Builder;

import java.math.BigDecimal;
import java.time.LocalDate;

@Builder
public record SavingTransaction(
        String id,
        LocalDate date,
        BigDecimal volume,
        String ccy,
        String type
) {

}