/*
 * Copyright © 2023 Brinvex (dev@brinvex.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.brinvex.util.ibkr.api.extension;

import com.brinvex.util.ibkr.api.model.Country;
import com.brinvex.util.ibkr.api.model.FinTransaction;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.StringJoiner;

public class Holding implements Serializable {
    private Country country;
    private String symbol;
    private BigDecimal qty;
    private final List<FinTransaction> transactions = new ArrayList<>();

    public Country getCountry() {
        return country;
    }

    public void setCountry(Country country) {
        this.country = country;
    }

    public String getSymbol() {
        return symbol;
    }

    public void setSymbol(String symbol) {
        this.symbol = symbol;
    }

    public BigDecimal getQty() {
        return qty;
    }

    public void setQty(BigDecimal qty) {
        this.qty = qty;
    }

    public List<FinTransaction> getTransactions() {
        return transactions;
    }

    @Override
    public String toString() {
        return new StringJoiner(", ", Holding.class.getSimpleName() + "[", "]")
                .add("country=" + country)
                .add("symbol='" + symbol + "'")
                .add("qty=" + qty)
                .toString();
    }
}
