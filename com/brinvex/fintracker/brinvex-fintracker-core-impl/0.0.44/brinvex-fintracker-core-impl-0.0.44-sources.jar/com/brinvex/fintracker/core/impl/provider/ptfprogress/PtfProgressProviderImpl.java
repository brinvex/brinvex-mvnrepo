package com.brinvex.fintracker.core.impl.provider.ptfprogress;

import com.brinvex.fintracker.core.api.exception.NotYetImplementedException;
import com.brinvex.fintracker.core.api.model.domain.PtfProgress;
import com.brinvex.fintracker.core.api.provider.PtfProgressProvider;

public class PtfProgressProviderImpl implements PtfProgressProvider {

    @Override
    public boolean supports(PtfProgressReq ptfProgressReq) {
        return true;
    }

    @Override
    public PtfProgress process(PtfProgressReq ptfProgressReq) {
        throw new NotYetImplementedException();
    }
}
