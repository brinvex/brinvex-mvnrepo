package com.brinvex.util.ibkr.impl.builder;

import com.brinvex.util.ibkr.api.model.statement.AssetCategory;
import com.brinvex.util.ibkr.api.model.statement.AssetSubCategory;
import com.brinvex.util.ibkr.api.model.Currency;
import com.brinvex.util.ibkr.api.model.statement.CorporateAction;
import com.brinvex.util.ibkr.api.model.statement.CorporateActionType;
import com.brinvex.util.ibkr.api.model.statement.SecurityIDType;
import lombok.Setter;
import lombok.experimental.Accessors;

import java.math.BigDecimal;
import java.time.LocalDate;

@Setter
@Accessors(fluent = true, chain = true)
public class CorporateActionBuilder {
    private LocalDate reportDate;
    private AssetCategory assetCategory;
    private AssetSubCategory assetSubCategory;
    private String symbol;
    private CorporateActionType type;
    private Currency currency;
    private BigDecimal amount;
    private BigDecimal value;
    private BigDecimal quantity;
    private BigDecimal proceeds;
    private String description;
    private String securityID;
    private SecurityIDType securityIDType;
    private String figi;
    private String isin;
    private String listingExchange;
    private String issuerCountryCode;
    private String extraDateTimeStr;
    private String transactionId;
    private String actionID;


    public CorporateAction build() {
        return new CorporateAction(
                this.reportDate,
                this.assetCategory,
                this.assetSubCategory,
                this.symbol,
                this.type,
                this.currency,
                this.amount,
                this.value,
                this.quantity,
                this.proceeds,
                this.description,
                this.securityID,
                this.securityIDType,
                this.figi,
                this.isin,
                this.listingExchange,
                this.issuerCountryCode,
                this.extraDateTimeStr,
                this.transactionId,
                this.actionID);
    }
}
