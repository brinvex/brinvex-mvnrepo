/*
 * Copyright © 2023 Brinvex (dev@brinvex.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.brinvex.util.ibkr.api.model.statement;

public enum BuySell {

    BUY("BUY"),

    SELL("SELL");

    private final String value;

    public static BuySell fromValue(String value) {
        for (BuySell tradeType : BuySell.values()) {
            if (tradeType.value.equals(value)) {
                return tradeType;
            }
        }
        throw new IllegalArgumentException("Unknown value: " + value);
    }

    BuySell(String value) {
        this.value = value;
    }

    public String value() {
        return value;
    }
}
