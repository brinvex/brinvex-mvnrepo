package com.brinvex.util.ibkr.api.model.statement;

import com.brinvex.util.ibkr.api.model.Currency;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDate;

public record EquitySummary(
        LocalDate reportDate,
        Currency currency,
        BigDecimal cash,
        BigDecimal stock,
        BigDecimal dividendAccruals,
        BigDecimal interestAccruals,
        BigDecimal total
) implements Serializable {
}
