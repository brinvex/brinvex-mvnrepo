/*
 * Copyright © 2023 Brinvex (dev@brinvex.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.brinvex.util.ibkr.impl.builder;

import com.brinvex.util.ibkr.api.model.Currency;
import com.brinvex.util.ibkr.api.model.statement.EquitySummary;
import lombok.Setter;
import lombok.experimental.Accessors;

import java.math.BigDecimal;
import java.time.LocalDate;

@Setter
@Accessors(fluent = true, chain = true)
public class EquitySummaryBuilder {
    private LocalDate reportDate;
    private Currency currency;
    private BigDecimal cash;
    private BigDecimal stock;
    private BigDecimal dividendAccruals;
    private BigDecimal interestAccruals;
    private BigDecimal total;

    public EquitySummary build() {
        return new EquitySummary(
                this.reportDate,
                this.currency,
                this.cash,
                this.stock,
                this.dividendAccruals,
                this.interestAccruals,
                this.total
        );
    }
}
