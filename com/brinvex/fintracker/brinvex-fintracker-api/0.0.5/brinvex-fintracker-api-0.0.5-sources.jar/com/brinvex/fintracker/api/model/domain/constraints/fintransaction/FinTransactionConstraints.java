package com.brinvex.fintracker.api.model.domain.constraints.fintransaction;

import com.brinvex.fintracker.api.model.domain.Asset;
import com.brinvex.fintracker.api.model.domain.FinTransaction;
import com.brinvex.fintracker.api.model.domain.FinTransactionType;
import jakarta.validation.constraints.NotNull;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.StringJoiner;

public class FinTransactionConstraints {

    private final FinTransaction finTransaction;

    protected FinTransactionConstraints(FinTransaction finTransaction) {
        this.finTransaction = finTransaction;
    }

    public String getId() {
        return finTransaction.id();
    }

    @NotNull
    public FinTransactionType getType() {
        return finTransaction.type();
    }

    @NotNull
    public LocalDate getDate() {
        return finTransaction.date();
    }

    public String getCcy() {
        return finTransaction.ccy();
    }

    @NotNull
    public BigDecimal getNetValue() {
        return finTransaction.netValue();
    }

    @NotNull
    public BigDecimal getQty() {
        return finTransaction.qty();
    }

    public BigDecimal getPrice() {
        return finTransaction.price();
    }

    public Asset getAsset() {
        return finTransaction.asset();
    }

    @NotNull
    public BigDecimal getGrossValue() {
        return finTransaction.grossValue();
    }

    public BigDecimal getTax() {
        return finTransaction.tax();
    }

    @NotNull
    public BigDecimal getFee() {
        return finTransaction.fee();
    }

    public LocalDate getSettleDate() {
        return finTransaction.settleDate();
    }

    public String getGroupId() {
        return finTransaction.groupId();
    }

    public String getExtraId() {
        return finTransaction.extraId();
    }

    public String getExtraType() {
        return finTransaction.extraType();
    }

    public String getExtraDetail() {
        return finTransaction.extraDetail();
    }

    @Override
    public String toString() {
        return new StringJoiner(", ", getClass().getSimpleName() + "[", "]")
                .add(String.valueOf(finTransaction))
                .toString();
    }
}
