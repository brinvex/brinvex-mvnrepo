package com.brinvex.util.ibkr.api.service;

import com.brinvex.util.ibkr.api.model.Country;
import com.brinvex.util.ibkr.api.model.Currency;
import com.brinvex.util.ibkr.api.model.FinTransaction;
import com.brinvex.util.ibkr.api.extension.Holding;
import com.brinvex.util.ibkr.api.extension.Portfolio;

import java.math.BigDecimal;
import java.util.Collection;
import java.util.List;
import java.util.Set;

public interface PtfManager {

    Portfolio initPortfolio(String accountId);

    Set<Currency> getCurrencies(Portfolio ptf);

    BigDecimal getCash(Portfolio ptf, Currency ccy);

    List<Holding> getHoldings(Portfolio ptf);

    BigDecimal getHoldingQty(Portfolio ptf, Country country, String symbol);

    List<FinTransaction> getTransactions(Portfolio ptf);

    void applyTransaction(Portfolio ptf, FinTransaction tran);

    void applyTransactions(Portfolio ptf, Collection<FinTransaction> trans);

    static PtfManager create() {
        try {
            return (PtfManager) Class.forName("com.brinvex.util.ibkr.impl.PtfManagerImpl")
                    .getConstructor()
                    .newInstance();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}
