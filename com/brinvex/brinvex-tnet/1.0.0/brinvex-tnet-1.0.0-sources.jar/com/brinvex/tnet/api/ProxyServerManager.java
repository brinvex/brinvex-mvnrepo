package com.brinvex.tnet.api;

import com.brinvex.tnet.internal.DockerEngineClient;

import java.io.IOException;

public interface ProxyServerManager extends AutoCloseable {

    static ProxyServerManager dockerProxyServerManager(String dockerMngBaseurl) {
        return new DockerEngineClient(dockerMngBaseurl);
    }

    void containerRestart(String proxyServerId) throws IOException;
}
