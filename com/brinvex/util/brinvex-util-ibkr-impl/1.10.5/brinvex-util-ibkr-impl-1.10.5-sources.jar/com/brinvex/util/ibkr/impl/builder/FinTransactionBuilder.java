/*
 * Copyright © 2023 Brinvex (dev@brinvex.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.brinvex.util.ibkr.impl.builder;

import com.brinvex.util.ibkr.api.model.Country;
import com.brinvex.util.ibkr.api.model.Currency;
import com.brinvex.util.ibkr.api.model.InstrumentType;
import com.brinvex.util.ibkr.api.model.FinTransaction;
import com.brinvex.util.ibkr.api.model.FinTransactionType;
import lombok.Setter;
import lombok.experimental.Accessors;

import java.math.BigDecimal;
import java.time.LocalDate;

@Setter
@Accessors(fluent = true, chain = true)
public class FinTransactionBuilder {

    private String id;
    private LocalDate reportDate;
    private FinTransactionType type;
    private Country country;
    private String symbol;
    private String isin;
    private String figi;
    private InstrumentType instrumentType;
    private BigDecimal qty;
    private Currency currency;
    private BigDecimal price;
    private BigDecimal grossValue;
    private BigDecimal netValue;
    private BigDecimal tax;
    private BigDecimal fees;
    private LocalDate settleDate;
    private String description;
    private String extraDateTimeStr;

    public FinTransaction build() {
        return new FinTransaction(
                this.id,
                this.reportDate,
                this.type,
                this.country,
                this.symbol,
                this.isin,
                this.figi,
                this.instrumentType,
                this.qty,
                this.currency,
                this.price,
                this.grossValue,
                this.netValue,
                this.tax,
                this.fees,
                this.settleDate,
                this.description,
                this.extraDateTimeStr
        );
    }
}
