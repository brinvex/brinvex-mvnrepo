package com.brinvex.fintracker.connector.rvlt.impl;

import com.brinvex.fintracker.connector.rvlt.api.RvltModule;
import com.brinvex.fintracker.connector.rvlt.api.service.RvltDms;
import com.brinvex.fintracker.connector.rvlt.api.service.RvltFinTransactionMapper;
import com.brinvex.fintracker.connector.rvlt.api.service.RvltFinTransactionMerger;
import com.brinvex.fintracker.connector.rvlt.api.service.RvltPtfProgressProvider;
import com.brinvex.fintracker.connector.rvlt.api.service.RvltStatementParser;
import com.brinvex.fintracker.connector.rvlt.impl.service.RvltDmsImpl;
import com.brinvex.fintracker.connector.rvlt.impl.service.RvltFinTransactionMapperImpl;
import com.brinvex.fintracker.connector.rvlt.impl.service.RvltFinTransactionMergerImpl;
import com.brinvex.fintracker.connector.rvlt.impl.service.RvltPtfProgressProviderImpl;
import com.brinvex.fintracker.connector.rvlt.impl.service.parser.RvltStatementParserImpl;
import com.brinvex.fintracker.core.api.infra.FinTrackerModuleContext;
import com.brinvex.fintracker.core.api.infra.FinTrackerModuleFactory;
import com.brinvex.fintracker.core.api.infra.FinTrackerSupport;

public class RvltModuleImpl implements RvltModule {

    public static class RvltModuleFactory implements FinTrackerModuleFactory<RvltModule> {

        @Override
        public Class<RvltModule> moduleType() {
            return RvltModule.class;
        }

        @Override
        public RvltModule createModule(FinTrackerModuleContext moduleCtx) {
            return new RvltModuleImpl(moduleCtx);
        }
    }

    private final FinTrackerModuleContext moduleCtx;

    public RvltModuleImpl(FinTrackerModuleContext moduleCtx) {
        this.moduleCtx = moduleCtx;
    }

    @Override
    public FinTrackerSupport support() {
        return moduleCtx.support();
    }


    @Override
    public RvltStatementParser statementParser() {
        return moduleCtx.singletonService(RvltStatementParser.class, () -> new RvltStatementParserImpl(support().pdfReader()));
    }

    @Override
    public RvltDms dms() {
        return moduleCtx.singletonService(RvltDms.class, () -> new RvltDmsImpl(moduleCtx.dms()));
    }

    @Override
    public RvltFinTransactionMerger finTransactionMerger() {
        return moduleCtx.singletonService(RvltFinTransactionMerger.class, RvltFinTransactionMergerImpl::new);
    }

    @Override
    public RvltFinTransactionMapper finTransactionMapper() {
        return moduleCtx.singletonService(RvltFinTransactionMapper.class, RvltFinTransactionMapperImpl::new);
    }

    @Override
    public RvltPtfProgressProvider ptfProgressProvider() {
        return moduleCtx.singletonService(RvltPtfProgressProvider.class, () -> new RvltPtfProgressProviderImpl(
                dms(),
                statementParser(),
                finTransactionMerger(),
                finTransactionMapper()
        ));
    }
}
