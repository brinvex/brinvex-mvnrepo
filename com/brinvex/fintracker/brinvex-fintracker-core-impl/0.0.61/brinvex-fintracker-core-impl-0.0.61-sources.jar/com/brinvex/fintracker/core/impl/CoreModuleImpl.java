package com.brinvex.fintracker.core.impl;

import com.brinvex.fintracker.core.api.CoreModule;
import com.brinvex.fintracker.core.api.FinTrackerModuleContext;
import com.brinvex.fintracker.core.api.provider.Provider;
import com.brinvex.fintracker.core.api.provider.PtfProgressProvider;
import com.brinvex.fintracker.core.api.service.PtfService;
import com.brinvex.fintracker.core.impl.provider.ptfprogress.PtfProgressProviderImpl;
import com.brinvex.fintracker.core.impl.service.PtfServiceImpl;

import java.util.List;
import java.util.SequencedCollection;

import static java.util.Collections.emptyList;

public class CoreModuleImpl implements CoreModule {

    private final FinTrackerModuleContext moduleCtx;

    public CoreModuleImpl(FinTrackerModuleContext moduleCtx) {
        this.moduleCtx = moduleCtx;
    }

    @Override
    public SequencedCollection<Provider<?, ?>> providers(Class<? extends Provider<?, ?>> providerType) {
        if (PtfProgressProvider.class == providerType) {
            return List.of(ptfProgressProvider());
        }
        return emptyList();
    }

    private PtfProgressProvider ptfProgressProvider() {
        return moduleCtx.singletonService(PtfProgressProvider.class, () -> new PtfProgressProviderImpl(moduleCtx.dms()));
    }

    @Override
    public PtfService ptfService() {
        return moduleCtx.singletonService(PtfService.class, PtfServiceImpl::new);
    }
}
