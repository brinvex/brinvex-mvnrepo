package com.brinvex.fintracker.connector.amnd.impl;

import com.brinvex.fintracker.connector.amnd.api.AmndModule;
import com.brinvex.fintracker.connector.amnd.api.service.AmndDms;
import com.brinvex.fintracker.connector.amnd.api.service.AmndFinTransactionMapper;
import com.brinvex.fintracker.connector.amnd.api.service.AmndPtfProgressProvider;
import com.brinvex.fintracker.connector.amnd.api.service.AmndStatementParser;
import com.brinvex.fintracker.connector.amnd.impl.service.AmndDmsImpl;
import com.brinvex.fintracker.connector.amnd.impl.service.AmndFinTransactionMapperImpl;
import com.brinvex.fintracker.connector.amnd.impl.service.AmndPtfProgressProviderImpl;
import com.brinvex.fintracker.connector.amnd.impl.service.AmndStatementParserImpl;
import com.brinvex.fintracker.core.api.FinTrackerModule;
import com.brinvex.fintracker.core.api.FinTrackerModuleContext;
import com.brinvex.fintracker.core.api.FinTrackerModuleFactory;
import com.brinvex.fintracker.core.api.provider.Provider;
import com.brinvex.fintracker.core.api.provider.PtfProgressProvider;

import java.util.List;
import java.util.SequencedCollection;
import java.util.Set;

import static java.util.Collections.emptyList;

public class AmndModuleImpl implements AmndModule, FinTrackerModule {

    public static class AmndModuleFactory implements FinTrackerModuleFactory<AmndModule> {

        @Override
        public Class<AmndModule> moduleType() {
            return AmndModule.class;
        }

        @Override
        public Set<Class<? extends Provider<?, ?>>> providerTypes() {
            return Set.of(PtfProgressProvider.class);
        }

        @Override
        public AmndModule createModule(FinTrackerModuleContext moduleCtx) {
            return new AmndModuleImpl(moduleCtx);
        }
    }

    private final FinTrackerModuleContext moduleCtx;

    public AmndModuleImpl(FinTrackerModuleContext moduleCtx) {
        this.moduleCtx = moduleCtx;
    }

    @Override
    public SequencedCollection<Provider<?, ?>> providers(Class<? extends Provider<?, ?>> providerType) {
        if (providerType == PtfProgressProvider.class) {
            return List.of(ptfProgressProvider());
        }
        return emptyList();
    }

    @Override
    public AmndStatementParser statementParser() {
        return moduleCtx.singletonService(AmndStatementParser.class, () -> new AmndStatementParserImpl(moduleCtx.toolbox().pdfReader()));
    }

    @Override
    public AmndDms dms() {
        return moduleCtx.singletonService(AmndDms.class, () -> new AmndDmsImpl(moduleCtx.dms()));
    }

    @Override
    public AmndFinTransactionMapper finTransactionMapper() {
        return moduleCtx.singletonService(AmndFinTransactionMapper.class, () -> new AmndFinTransactionMapperImpl(moduleCtx));
    }

    @Override
    public AmndPtfProgressProvider ptfProgressProvider() {
        return moduleCtx.singletonService(AmndPtfProgressProvider.class, () -> new AmndPtfProgressProviderImpl(
                dms(),
                statementParser(),
                finTransactionMapper()
        ));
    }
}
