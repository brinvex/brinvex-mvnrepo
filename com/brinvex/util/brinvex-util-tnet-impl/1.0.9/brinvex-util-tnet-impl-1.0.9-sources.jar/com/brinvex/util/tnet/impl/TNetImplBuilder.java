package com.brinvex.util.tnet.impl;

import java.time.Duration;

public class TNetImplBuilder {

    private int poolSize = 2;
    private String socksProxyHost = "127.0.0.1";
    private int socksProxyBasePort = 9050;
    private int socksProxyPortOffset = 1;
    private Duration pollTimeout = Duration.ofSeconds(60);
    private String dockerEngineAddress = "http://127.0.0.1:2375";
    private String proxyServerDockerContNamePattern = null;
    private boolean healthcheckAtStartup = true;

    public TNetImplBuilder setPoolSize(int poolSize) {
        this.poolSize = poolSize;
        return this;
    }

    public TNetImplBuilder setSocksProxyBasePort(int socksProxyBasePort) {
        this.socksProxyBasePort = socksProxyBasePort;
        return this;
    }

    public TNetImplBuilder setDockerEngineAddress(String dockerEngineAddress) {
        this.dockerEngineAddress = dockerEngineAddress;
        return this;
    }

    public TNetImplBuilder setSocksProxyHost(String socksProxyHost) {
        this.socksProxyHost = socksProxyHost;
        return this;
    }

    public TNetImplBuilder setSocksProxyPortOffset(int socksProxyPortOffset) {
        this.socksProxyPortOffset = socksProxyPortOffset;
        return this;
    }

    public TNetImplBuilder setPollTimeout(Duration pollTimeout) {
        this.pollTimeout = pollTimeout;
        return this;
    }

    public TNetImplBuilder setProxyServerDockerContNamePattern(String proxyServerDockerContNamePattern) {
        this.proxyServerDockerContNamePattern = proxyServerDockerContNamePattern;
        return this;
    }

    public TNetImplBuilder setHealthcheckAtStartup(boolean healthcheckAtStartup) {
        this.healthcheckAtStartup = healthcheckAtStartup;
        return this;
    }

    public TNetImpl createTNet() {
        return new TNetImpl(
                poolSize,
                dockerEngineAddress,
                socksProxyHost,
                socksProxyBasePort,
                socksProxyPortOffset,
                pollTimeout,
                proxyServerDockerContNamePattern,
                healthcheckAtStartup
        );
    }
}