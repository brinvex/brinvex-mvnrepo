package com.brinvex.fintracker.connector.fiob.impl.service.mapper;

import com.brinvex.fintracker.connector.fiob.api.model.statement.TradingTransaction;
import com.brinvex.fintracker.connector.fiob.api.service.FiobFinTransactionMapper;
import com.brinvex.fintracker.core.api.exception.NotYetImplementedException;
import com.brinvex.fintracker.core.api.model.domain.FinTransaction;

import java.util.List;

public class FiobFinTransactionMapperImpl implements FiobFinTransactionMapper {

/*
    private final FiobTradingTransMapper fiobTradingTransMapper;

    public FiobFinTransactionMapperImpl() {
        fiobTradingTransMapper = new FiobTradingTransMapper();
    }

    @Override
    public List<FinTransaction> mapTradingTransactions(List<TradingTransaction> tradingTrans) {
        return fiobTradingTransMapper.mapTransactions(tradingTrans);
    }
*/

    @Override
    public List<FinTransaction> mapTradingTransactions(List<TradingTransaction> tradingTrans) {
        throw new NotYetImplementedException();
    }
}
