package com.brinvex.util.fiobank.api.service;

import com.brinvex.util.fiobank.api.model.Portfolio;
import com.brinvex.util.fiobank.api.model.PortfolioValue;
import com.brinvex.util.fiobank.api.model.RawBrokerTransactionList;

import java.nio.file.Path;
import java.time.LocalDate;
import java.util.Collection;
import java.util.Map;
import java.util.stream.Stream;

public interface FioBrokerService {

    RawBrokerTransactionList parseTransactionStatements(Stream<String> transactionStatementContents);

    RawBrokerTransactionList parseTransactionStatements(Collection<Path> transactionStatementFilePaths);

    Portfolio processTransactionStatements(Stream<String> transactionStatementContents);

    Portfolio processTransactionStatements(Collection<Path> transactionStatementFilePaths);

    Portfolio processTransactionStatements(Portfolio ptf, Stream<String> transactionStatementContents);

    Portfolio processTransactionStatements(Portfolio ptf, Collection<Path> transactionStatementFilePaths);

    Map<LocalDate, PortfolioValue> getPortfolioValues(Stream<String> portfolioStatementContents);

    Map<LocalDate, PortfolioValue> getPortfolioValues(Collection<PortfolioValue> oldPtfValues, Stream<String> portfolioStatementContents);

    Map<LocalDate, PortfolioValue> getPortfolioValues(Collection<Path> portfolioStatementPaths);

    Map<LocalDate, PortfolioValue> getPortfolioValues(Collection<PortfolioValue> oldPtfValues, Collection<Path> portfolioStatementPaths);

}
