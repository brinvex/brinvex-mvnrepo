package com.brinvex.util.ibkr.api.service;

import com.brinvex.util.ibkr.api.model.statement.FlexStatement.ActivityStatement;

import java.util.Collection;
import java.util.Optional;

public interface IbkrStatementMerger {

    Optional<ActivityStatement> mergeActivityStatements(Collection<ActivityStatement> flexStatements);

    static IbkrStatementMerger create() {
        try {
            return (IbkrStatementMerger) Class.forName("com.brinvex.util.ibkr.impl.IbkrStatementMergerImpl")
                    .getConstructor()
                    .newInstance();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

}
