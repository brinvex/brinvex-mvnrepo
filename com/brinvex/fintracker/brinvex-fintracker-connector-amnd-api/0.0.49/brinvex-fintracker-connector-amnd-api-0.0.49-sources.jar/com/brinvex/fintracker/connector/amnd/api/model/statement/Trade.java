package com.brinvex.fintracker.connector.amnd.api.model.statement;

import lombok.Builder;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDate;

@Builder
public record Trade(
        TradeType type,
        String accountId,
        LocalDate orderDate,
        LocalDate tradeDate,
        BigDecimal netValue,
        BigDecimal fee,
        BigDecimal qty,
        BigDecimal price,
        LocalDate priceDate,
        String ccy,
        String isin,
        String instrumentName,
        String description,
        LocalDate settleDate
) implements Serializable {
}
