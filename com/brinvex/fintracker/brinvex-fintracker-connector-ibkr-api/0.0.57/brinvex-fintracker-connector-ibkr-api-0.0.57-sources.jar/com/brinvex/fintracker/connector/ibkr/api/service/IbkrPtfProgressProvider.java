package com.brinvex.fintracker.connector.ibkr.api.service;

import com.brinvex.fintracker.connector.ibkr.api.model.IbkrAccount;
import com.brinvex.fintracker.core.api.domain.dto.PtfProgress;
import com.brinvex.fintracker.core.api.provider.PtfProgressProvider;

import java.time.Duration;
import java.time.LocalDate;

public interface IbkrPtfProgressProvider extends PtfProgressProvider {

    PtfProgress getPtfProgress(
            IbkrAccount ibkrAccount,
            LocalDate fromDateIncl,
            LocalDate toDateIncl,
            Duration staleTolerance
    );

    PtfProgress getPtfProgressOffline(
            IbkrAccount ibkrAccount,
            LocalDate fromDateIncl,
            LocalDate toDateIncl
    );
}
