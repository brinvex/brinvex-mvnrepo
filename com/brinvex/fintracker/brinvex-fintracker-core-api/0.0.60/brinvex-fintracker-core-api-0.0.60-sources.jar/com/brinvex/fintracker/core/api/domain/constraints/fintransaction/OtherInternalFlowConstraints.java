package com.brinvex.fintracker.core.api.domain.constraints.fintransaction;

import com.brinvex.fintracker.core.api.domain.dto.Asset;
import com.brinvex.fintracker.core.api.domain.dto.FinTransaction;
import jakarta.validation.constraints.Null;

public class OtherInternalFlowConstraints extends FinTransactionConstraints {

    OtherInternalFlowConstraints(FinTransaction finTransaction) {
        super(finTransaction);
    }

    @Null
    @Override
    public Asset getAsset() {
        return super.getAsset();
    }

}
