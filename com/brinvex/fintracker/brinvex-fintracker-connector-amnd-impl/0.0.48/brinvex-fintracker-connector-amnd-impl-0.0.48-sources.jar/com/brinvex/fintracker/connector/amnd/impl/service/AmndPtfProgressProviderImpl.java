package com.brinvex.fintracker.connector.amnd.impl.service;

import com.brinvex.fintracker.connector.amnd.api.model.AmndTransStatementDocKey;
import com.brinvex.fintracker.connector.amnd.api.model.statement.TransactionStatement;
import com.brinvex.fintracker.connector.amnd.api.service.AmndDms;
import com.brinvex.fintracker.connector.amnd.api.service.AmndFinTransactionMapper;
import com.brinvex.fintracker.connector.amnd.api.service.AmndPtfProgressProvider;
import com.brinvex.fintracker.connector.amnd.api.service.AmndStatementParser;
import com.brinvex.fintracker.core.api.model.domain.FinTransaction;
import com.brinvex.fintracker.core.api.model.domain.PtfProgress;
import com.brinvex.util.java.validation.Assert;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.LocalDate;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import static java.util.Collections.emptyList;
import static java.util.Comparator.comparing;
import static java.util.function.Function.identity;
import static java.util.stream.Collectors.toMap;

public class AmndPtfProgressProviderImpl implements AmndPtfProgressProvider {

    private final AmndDms dms;

    private final AmndStatementParser statementParser;

    private final AmndFinTransactionMapper finTransactionMapper;

    public AmndPtfProgressProviderImpl(
            AmndDms dms,
            AmndStatementParser statementParser,
            AmndFinTransactionMapper finTransactionMapper
    ) {
        this.dms = dms;
        this.statementParser = statementParser;
        this.finTransactionMapper = finTransactionMapper;
    }

    @Override
    public boolean supports(PtfProgressReq ptfProgressReq) {
        return ptfProgressReq.ptfProgressProvider().equals("amnd");
    }

    @Override
    public PtfProgress process(PtfProgressReq ptfProgressReq) {
        Assert.isTrue(supports(ptfProgressReq));
        Map<String, String> ptfProps = ptfProgressReq.ptfProps();

        String accountId = ptfProps.get("accountId");
        LocalDate reqFromDateIncl = ptfProgressReq.fromDateIncl();
        LocalDate reqToDateIncl = ptfProgressReq.toDateIncl();

        return getPtfProgress(accountId, reqFromDateIncl, reqToDateIncl);
    }

    @Override
    public PtfProgress getPtfProgress(String accountId, LocalDate fromDateIncl, LocalDate toDateIncl) {
        LOG.debug("getPtfProgress({}, {}-{})", accountId, fromDateIncl, toDateIncl);

        if (fromDateIncl.isAfter(toDateIncl)) {
            return new PtfProgress(emptyList(), emptyList(), null);
        }

        AmndTransStatementDocKey docKey = dms.getTradingAccountStatementDocKey(accountId);
        byte[] statementContent = dms.getStatementContent(docKey);

        TransactionStatement transStatement = statementParser.parseTrades(statementContent);
        Assert.isTrue(transStatement.accountId().equals(accountId));

        List<FinTransaction> finTrans = transStatement.trades()
                .stream()
                .filter(t -> !t.orderDate().isBefore(fromDateIncl) && (toDateIncl == null || !t.orderDate().isAfter(toDateIncl)))
                .map(finTransactionMapper::mapTradeToFinTransactionPair)
                .flatMap(Collection::stream)
                .sorted(comparing(FinTransaction::date))
                .collect(toMap(FinTransaction::extraId, identity(), (u, v) -> {
                    throw new IllegalStateException("ExtraID conflict: %s, %s".formatted(u, v));
                }, LinkedHashMap::new))
                .values()
                .stream()
                .toList();

        return new PtfProgress(finTrans, null, null);
    }

    private static final Logger LOG = LoggerFactory.getLogger(AmndPtfProgressProviderImpl.class);
}
