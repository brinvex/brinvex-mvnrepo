package com.brinvex.fintracker.core.api.util;

public class CountryUtil {

    public static String countryCcy(String country) {
        return switch (country) {
            case "US" -> "USD";
            case "DE" -> "EUR";
            case "CZ" -> "CZK";
            case null -> null;
            default -> throw new IllegalStateException("Unexpected value: " + country);
        };
    }
}
