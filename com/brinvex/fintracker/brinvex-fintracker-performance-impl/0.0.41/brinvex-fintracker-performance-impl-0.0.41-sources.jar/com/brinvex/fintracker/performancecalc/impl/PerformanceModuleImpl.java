package com.brinvex.fintracker.performancecalc.impl;

import com.brinvex.fintracker.core.api.internal.FinTrackerModule;
import com.brinvex.fintracker.core.api.internal.FinTrackerModuleContext;
import com.brinvex.fintracker.core.api.internal.FinTrackerModuleFactory;
import com.brinvex.fintracker.core.api.internal.FinTrackerSupport;
import com.brinvex.fintracker.performancecalc.api.PerformanceModule;
import com.brinvex.fintracker.performancecalc.api.service.PerformanceAnalyzer;
import com.brinvex.fintracker.performancecalc.api.service.PerformanceCalculator.MwrCalculator;
import com.brinvex.fintracker.performancecalc.api.service.PerformanceCalculator.TwrCalculator;
import com.brinvex.fintracker.performancecalc.impl.service.LinkedModifiedDietzTwrCalculatorImpl;
import com.brinvex.fintracker.performancecalc.impl.service.ModifiedDietzMwrCalculatorImpl;
import com.brinvex.fintracker.performancecalc.impl.service.PerformanceAnalyzerImpl;
import com.brinvex.fintracker.performancecalc.impl.service.SimpleReturnCalculatorImpl;
import com.brinvex.fintracker.performancecalc.impl.service.TrueTwrCalculatorImpl;

import static com.brinvex.fintracker.performancecalc.api.service.PerformanceCalculator.LinkedModifiedDietzTwrCalculator;
import static com.brinvex.fintracker.performancecalc.api.service.PerformanceCalculator.ModifiedDietzMwrCalculator;
import static com.brinvex.fintracker.performancecalc.api.service.PerformanceCalculator.SimpleReturnCalculator;
import static com.brinvex.fintracker.performancecalc.api.service.PerformanceCalculator.TrueTwrCalculator;

public class PerformanceModuleImpl implements PerformanceModule, FinTrackerModule {

    public static class PerformanceModuleFactory implements FinTrackerModuleFactory<PerformanceModule> {

        @Override
        public Class<PerformanceModule> moduleType() {
            return PerformanceModule.class;
        }

        @Override
        public PerformanceModule createModule(FinTrackerModuleContext finTrackerCtx) {
            return new PerformanceModuleImpl(finTrackerCtx);
        }
    }

    private final FinTrackerModuleContext moduleCtx;

    public PerformanceModuleImpl(FinTrackerModuleContext moduleCtx) {
        this.moduleCtx = moduleCtx;
    }

    @Override
    public FinTrackerSupport support() {
        return moduleCtx.support();
    }

    @Override
    public TrueTwrCalculator trueTwrCalculator() {
        return moduleCtx.singletonService(TrueTwrCalculator.class, TrueTwrCalculatorImpl::new);
    }

    @Override
    public LinkedModifiedDietzTwrCalculator linkedModifiedDietzTwrCalculator() {
        return moduleCtx.singletonService(LinkedModifiedDietzTwrCalculator.class,
                () -> new LinkedModifiedDietzTwrCalculatorImpl(modifiedDietzMwrCalculator()));
    }

    @Override
    public ModifiedDietzMwrCalculator modifiedDietzMwrCalculator() {
        return moduleCtx.singletonService(ModifiedDietzMwrCalculator.class, ModifiedDietzMwrCalculatorImpl::new);
    }

    @Override
    public SimpleReturnCalculator simpleReturnCalculator() {
        return moduleCtx.singletonService(SimpleReturnCalculator.class, SimpleReturnCalculatorImpl::new);
    }

    @Override
    public TwrCalculator twrCalculator() {
        return linkedModifiedDietzTwrCalculator();
    }

    @Override
    public MwrCalculator mwrCalculator() {
        return modifiedDietzMwrCalculator();
    }

    @Override
    public <CALCULATOR extends TwrCalculator> CALCULATOR twrCalculator(Class<CALCULATOR> twrCalculatorType) {
        TwrCalculator uncheckedCalculatorInstance;
        if (twrCalculatorType == LinkedModifiedDietzTwrCalculator.class) {
            uncheckedCalculatorInstance = linkedModifiedDietzTwrCalculator();
        } else if (twrCalculatorType == TrueTwrCalculator.class) {
            uncheckedCalculatorInstance = trueTwrCalculator();
        } else if (twrCalculatorType == TwrCalculator.class) {
            uncheckedCalculatorInstance = twrCalculator();
        } else {
            uncheckedCalculatorInstance = moduleCtx.singletonService(twrCalculatorType, () -> {
                throw new IllegalArgumentException("No TwrCalculator registered for type: %s ".formatted(twrCalculatorType));
            });
        }
        @SuppressWarnings("unchecked")
        CALCULATOR typedCalculatorInstance = (CALCULATOR) uncheckedCalculatorInstance;
        return typedCalculatorInstance;
    }

    @Override
    public <CALCULATOR extends MwrCalculator> CALCULATOR mwrCalculator(Class<CALCULATOR> mwrCalculatorType) {
        MwrCalculator uncheckedCalculatorInstance;
        if (mwrCalculatorType == ModifiedDietzMwrCalculator.class) {
            uncheckedCalculatorInstance = modifiedDietzMwrCalculator();
        } else if (mwrCalculatorType == MwrCalculator.class) {
            uncheckedCalculatorInstance = mwrCalculator();
        } else {
            uncheckedCalculatorInstance = moduleCtx.singletonService(mwrCalculatorType, () -> {
                throw new IllegalArgumentException("No MwrCalculator registered for type: %s ".formatted(mwrCalculatorType));
            });
        }
        @SuppressWarnings("unchecked")
        CALCULATOR typedCalculatorInstance = (CALCULATOR) uncheckedCalculatorInstance;
        return typedCalculatorInstance;
    }

    @Override
    public PerformanceAnalyzer performanceAnalyzer() {
        return moduleCtx.singletonService(PerformanceAnalyzer.class, () ->
                new PerformanceAnalyzerImpl(this::twrCalculator, this::mwrCalculator));
    }
}
