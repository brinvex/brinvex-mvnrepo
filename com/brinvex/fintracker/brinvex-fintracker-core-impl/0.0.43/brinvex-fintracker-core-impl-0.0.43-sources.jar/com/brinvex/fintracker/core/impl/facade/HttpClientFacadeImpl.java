/*
package com.brinvex.fintracker.core.impl.facade;


import com.brinvex.fintracker.core.api.exception.NotYetImplementedException;

import java.io.IOException;
import java.io.InputStream;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse.BodyHandlers;
import java.nio.charset.Charset;
import java.util.Map;

public class HttpClientFacadeImpl implements HttpClientFacade {

    private static final class Lazy {
        private static final HttpClient httpClient = HttpClient.newBuilder()
                .followRedirects(HttpClient.Redirect.NORMAL)
                .build();
    }

    @Override
    public StringHttpResponse doGet(URI uri, Map<String, Object> headers, Charset respCharset) throws IOException {
        HttpRequest req = prepareRequest(uri, headers)
                .build();
        return sendRequest(uri, respCharset, req, StringHttpResponse.class);
    }

    @Override
    public BytesHttpResponse doGet(URI uri, Map<String, Object> headers) throws IOException {
        HttpRequest req = prepareRequest(uri, headers)
                .build();
        return sendRequest(uri, null, req, BytesHttpResponse.class);
    }

    @Override
    public StringHttpResponse doPost(URI uri, Map<String, Object> headers, String payload, Charset respCharset) throws IOException {
        HttpRequest req = prepareRequest(uri, headers)
                .POST(HttpRequest.BodyPublishers.ofString(payload))
                .build();
        return sendRequest(uri, respCharset, req, StringHttpResponse.class);
    }

    @Override
    public BytesHttpResponse doPost(URI uri, Map<String, Object> headers, String payload) throws IOException {
        HttpRequest req = prepareRequest(uri, headers)
                .POST(HttpRequest.BodyPublishers.ofString(payload))
                .build();
        return sendRequest(uri, null, req, BytesHttpResponse.class);
    }

    private HttpRequest.Builder prepareRequest(URI uri, Map<String, Object> headers) {
        HttpRequest.Builder reqBuilder = HttpRequest.newBuilder(uri);
        if (headers != null && !headers.isEmpty()) {
            for (Map.Entry<String, Object> e : headers.entrySet()) {
                String headerKey = e.getKey();
                Object headerValue = e.getValue();
                if (headerValue instanceof String stringHeaderValue) {
                    reqBuilder.setHeader(headerKey, stringHeaderValue);
                } else {
                    //Don't forget to properly handle headers having collection values
                    throw new NotYetImplementedException("Support for non-String headers is not yet implemented");
                }
            }
        }
        return reqBuilder;
    }

    @SuppressWarnings("unchecked")
    private <RESPONSE extends HttpResponse<?>> RESPONSE sendRequest(URI uri, Charset respCharset, HttpRequest req, Class<RESPONSE> responseType) throws IOException {
        HttpClient httpClient = Lazy.httpClient;
        try {
            if (StringHttpResponse.class.isAssignableFrom(responseType)) {
                java.net.http.HttpResponse<String> resp = httpClient.send(req, BodyHandlers.ofString(respCharset));
                return (RESPONSE) new StringHttpResponse(resp.statusCode(), resp.body());
            } else if (BytesHttpResponse.class.isAssignableFrom(responseType)) {
                java.net.http.HttpResponse<InputStream> resp = httpClient.send(req, BodyHandlers.ofInputStream());
                try (InputStream body = resp.body()) {
                    return (RESPONSE) new BytesHttpResponse(resp.statusCode(), body.readAllBytes());
                }
            } else {
                throw new IllegalStateException("Unreachable");
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new IOException("Thread was interrupted while fetching %s".formatted(uri), e);
        }
    }
}
*/
