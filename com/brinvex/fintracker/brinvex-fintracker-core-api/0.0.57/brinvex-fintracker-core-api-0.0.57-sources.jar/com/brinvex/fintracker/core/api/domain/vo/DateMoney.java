package com.brinvex.fintracker.core.api.domain.vo;

import com.brinvex.fintracker.core.api.domain.enu.Currency;

import java.math.BigDecimal;
import java.time.LocalDate;

import static java.util.Objects.requireNonNull;

public record DateMoney(
        LocalDate date,
        Money money
) {
    public DateMoney {
        requireNonNull(date);
        requireNonNull(money);
    }

    public DateMoney(LocalDate date, Currency ccy, BigDecimal amount) {
        this(date, new Money(ccy, amount));
    }

    public DateMoney(LocalDate date, String ccy, BigDecimal amount) {
        this(date, new Money(ccy, amount));
    }

    public DateAmount toDateAmount() {
        return new DateAmount(date, money.amount());
    }
}
