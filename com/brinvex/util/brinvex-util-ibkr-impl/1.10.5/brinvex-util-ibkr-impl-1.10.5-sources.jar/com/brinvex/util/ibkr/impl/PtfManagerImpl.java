/*
 * Copyright © 2023 Brinvex (dev@brinvex.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.brinvex.util.ibkr.impl;

import com.brinvex.util.ibkr.api.model.Country;
import com.brinvex.util.ibkr.api.model.Currency;
import com.brinvex.util.ibkr.api.model.FinTransaction;
import com.brinvex.util.ibkr.api.model.FinTransactionType;
import com.brinvex.util.ibkr.api.extension.Holding;
import com.brinvex.util.ibkr.api.extension.Portfolio;
import com.brinvex.util.ibkr.api.service.PtfManager;

import java.math.BigDecimal;
import java.util.Collection;
import java.util.List;
import java.util.Set;

import static java.lang.String.format;
import static java.math.BigDecimal.ZERO;
import static java.util.Objects.requireNonNull;

public class PtfManagerImpl implements PtfManager {

    @Override
    public Portfolio initPortfolio(String accountId) {
        return new Portfolio(accountId);
    }

    @Override
    public Set<Currency> getCurrencies(Portfolio ptf) {
        return ptf.getWallets().keySet();
    }

    @Override
    public BigDecimal getCash(Portfolio ptf, Currency ccy) {
        return ptf.getWallets().getOrDefault(ccy, ZERO);
    }

    @Override
    public List<Holding> getHoldings(Portfolio ptf) {
        return ptf.getHoldings();
    }

    @Override
    public BigDecimal getHoldingQty(Portfolio ptf, Country country, String symbol) {
        Holding holding = getHolding(ptf, country, symbol);
        return holding == null ? null : holding.getQty();
    }

    @Override
    public List<FinTransaction> getTransactions(Portfolio ptf) {
        return ptf.getTransactions();
    }

    @Override
    public void applyTransaction(Portfolio ptf, FinTransaction tran) {
        String tranId = tran.id();
        FinTransaction duplTran = ptf.getTransactions()
                .stream()
                .filter(t -> t == tran || tranId.equals(t.id()))
                .findAny()
                .orElse(null);
        if (duplTran != null) {
            throw new IllegalArgumentException("Transaction already applied: newTran=%s, duplTran=%s".formatted(tran, duplTran));
        }

        FinTransactionType tranType = tran.type();
        Country country = tran.country();
        String symbol = tran.symbol();
        Currency ccy = tran.currency();
        BigDecimal netValue = tran.netValue();
        BigDecimal qty = tran.qty();

        if (netValue != null && netValue.compareTo(ZERO) != 0) {
            updateCash(ptf, ccy, netValue);
        }

        if (qty.compareTo(ZERO) != 0) {
            if (tranType.equals(FinTransactionType.FX_BUY) || tranType.equals(FinTransactionType.FX_SELL)) {
                updateCash(ptf, Currency.valueOf(symbol), qty);
            } else {
                Holding holding = updateHolding(ptf, country, symbol, qty);
                holding.getTransactions().add(tran);
            }
        }
        ptf.getTransactions().add(tran);
    }

    @Override
    public void applyTransactions(Portfolio ptf, Collection<FinTransaction> trans) {
        for (FinTransaction tran : trans) {
            applyTransaction(ptf, tran);
        }
    }

    private Holding getHolding(Portfolio ptf, Country country, String symbol) {
        requireNonNull(ptf);
        requireNonNull(country);
        requireNonNull(symbol);
        return ptf.getHoldings()
                .stream()
                .filter(p -> country.equals(p.getCountry()))
                .filter(p -> symbol.equals(p.getSymbol()))
                .reduce((p1, p2) -> {
                    throw new IllegalStateException(format("Duplicate holding: %s, %s", p1, p2));
                })
                .orElse(null);
    }

    private Holding updateHolding(Portfolio ptf, Country country, String symbol, BigDecimal qtyToAdd) {
        requireNonNull(qtyToAdd);
        Holding holding = getHolding(ptf, country, symbol);
        if (holding == null) {
            holding = new Holding();
            holding.setCountry(country);
            holding.setSymbol(symbol);
            holding.setQty(qtyToAdd);
            ptf.getHoldings().add(holding);
        } else {
            holding.setQty(holding.getQty().add(qtyToAdd));
        }
        return holding;
    }

    private void updateCash(Portfolio ptf, Currency ccy, BigDecimal moneyToAdd) {
        requireNonNull(ptf);
        requireNonNull(ccy);
        requireNonNull(moneyToAdd);
        ptf.getWallets().merge(ccy, moneyToAdd, BigDecimal::add);
    }


}
