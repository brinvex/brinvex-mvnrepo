package com.brinvex.fintracker.core.api.infra;

public interface FinTrackerModuleFactory<MODULE extends FinTrackerModule> {

    Class<MODULE> moduleType();

    MODULE createModule(FinTrackerModuleContext moduleCtx);

}
