package com.brinvex.fintypes.vo;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Map;
import java.util.function.BiFunction;
import java.util.function.Function;

public record DatePrice(
        LocalDate date,
        BigDecimal price
) implements Serializable {

    public DatePrice {
        if (date == null) {
            throw new IllegalArgumentException("date must not be null, price=%s".formatted(price));
        }
        if (price == null) {
            throw new IllegalArgumentException("price must not be null, date=%s".formatted(date));
        }
    }

    public DatePrice(String date, String amount) {
        this(LocalDate.parse(date), new BigDecimal(amount));
    }

    public DatePrice(Map.Entry<LocalDate, BigDecimal> mapEntry) {
        this(mapEntry.getKey(), mapEntry.getValue());
    }

    public boolean isBefore(LocalDate date) {
        return this.date.isBefore(date);
    }

    public boolean isAfter(LocalDate date) {
        return this.date.isAfter(date);
    }

    public DatePrice combine(DatePrice other, BiFunction<BigDecimal, BigDecimal, BigDecimal> rateOperation) {
        if (!date.isEqual(other.date())) {
            throw new IllegalArgumentException(
                    "Add operation not allowed for different dates: %s, %s.".formatted(this, other)
            );
        }
        return new DatePrice(date, rateOperation.apply(price, other.price));
    }

    public DateAmount with(Function<BigDecimal, BigDecimal> rateOperation) {
        return new DateAmount(date, rateOperation.apply(price));
    }

    @Override
    public String toString() {
        return "DatePrice{%s/%s}".formatted(date, price.toPlainString());
    }
}
