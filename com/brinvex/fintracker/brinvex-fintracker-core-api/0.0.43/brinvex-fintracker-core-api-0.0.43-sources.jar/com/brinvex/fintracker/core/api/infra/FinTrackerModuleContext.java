package com.brinvex.fintracker.core.api.infra;

import com.brinvex.util.dms.api.Dms;

import java.util.Map;
import java.util.function.Supplier;

public interface FinTrackerModuleContext {

    <SERVICE> SERVICE singletonService(Class<SERVICE> type, Supplier<SERVICE> serviceSupplier);

    default String getProperty(String propKey) {
        return getProperty(propKey, null);
    }

    String getProperty(String propKey, String defaultValue);

    Map<String, String> getProperties(String propPrefix);

    Dms dms();

    FinTrackerSupport support();

}
