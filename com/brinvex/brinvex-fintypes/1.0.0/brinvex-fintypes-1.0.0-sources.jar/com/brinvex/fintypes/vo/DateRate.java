package com.brinvex.fintypes.vo;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Map;
import java.util.function.BiFunction;
import java.util.function.Function;

public record DateRate(
        LocalDate date,
        BigDecimal rate
) implements Serializable {

    public DateRate {
        if (date == null) {
            throw new IllegalArgumentException("date must not be null, rate=%s".formatted(rate));
        }
        if (rate == null) {
            throw new IllegalArgumentException("rate must not be null, date=%s".formatted(date));
        }
    }

    public DateRate(String date, String amount) {
        this(LocalDate.parse(date), new BigDecimal(amount));
    }

    public DateRate(Map.Entry<LocalDate, BigDecimal> mapEntry) {
        this(mapEntry.getKey(), mapEntry.getValue());
    }

    public boolean isBefore(LocalDate date) {
        return this.date.isBefore(date);
    }

    public boolean isAfter(LocalDate date) {
        return this.date.isAfter(date);
    }

    public DateRate combine(DateRate other, BiFunction<BigDecimal, BigDecimal, BigDecimal> rateOperation) {
        if (!date.isEqual(other.date())) {
            throw new IllegalArgumentException(
                    "Add operation not allowed for different dates: %s, %s.".formatted(this, other)
            );
        }
        return new DateRate(date, rateOperation.apply(rate, other.rate));
    }

    public DateAmount with(Function<BigDecimal, BigDecimal> rateOperation) {
        return new DateAmount(date, rateOperation.apply(rate));
    }

    @Override
    public String toString() {
        return "DateRate[%s/%s]".formatted(date, rate.toPlainString());
    }
}
