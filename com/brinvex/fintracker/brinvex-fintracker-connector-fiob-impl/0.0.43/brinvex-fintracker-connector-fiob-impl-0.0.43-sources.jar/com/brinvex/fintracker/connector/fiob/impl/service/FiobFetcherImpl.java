package com.brinvex.fintracker.connector.fiob.impl.service;

import com.brinvex.fintracker.connector.fiob.api.model.FiobAccount;
import com.brinvex.fintracker.connector.fiob.api.model.statement.Statement;
import com.brinvex.fintracker.connector.fiob.api.service.FiobFetcher;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.UncheckedIOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.http.HttpResponse.BodyHandlers;
import java.time.LocalDate;

public class FiobFetcherImpl implements FiobFetcher {

    private static final Logger LOG = LoggerFactory.getLogger(FiobFetcherImpl.class);

    private final HttpClient httpClient;

    public FiobFetcherImpl() {
        httpClient = HttpClient.newBuilder()
                .followRedirects(HttpClient.Redirect.NORMAL)
                .build();
    }

    @Override
    public String fetchStatement(Class<? extends Statement> statementType, FiobAccount account, LocalDate fromDateIncl, LocalDate toDateIncl) {
        LOG.debug("fetchStatement({}, {}/{}, {}-{})", statementType.getSimpleName(), account.accountId(), account.accountName(), fromDateIncl, toDateIncl);

        if (statementType != Statement.SavingTransStatement.class) {
            throw new IllegalArgumentException("Fetching not supported for statement type: %s"
                    .formatted(statementType));
        }

        String url = String.format(Lazy.FIOB_BANK_API_URL_FMT, account.credentials(), fromDateIncl, toDateIncl);
        try {
            HttpRequest req = HttpRequest.newBuilder(URI.create(url)).build();
            HttpResponse<String> resp = httpClient.send(req, BodyHandlers.ofString());
            return resp.body();
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new UncheckedIOException(e);
        }
    }

    private static class Lazy {
        private static final String FIOB_BANK_API_URL_FMT = "https://www.fio.cz/ib_api/rest/periods/%s/%s/%s/transactions.xml";
    }

}
