/*
 * Copyright © 2023 Brinvex (dev@brinvex.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.brinvex.util.ibkr.impl;

import java.math.BigDecimal;
import java.util.function.Function;
import java.util.function.Supplier;

import static java.math.BigDecimal.ZERO;

class Util {

    public static void assertTrue(boolean test) {
        if (!test) {
            throw new IllegalStateException("Validated expression is false");
        }
    }

    public static void assertTrue(boolean test, Supplier<String> msgSupplier) {
        if (!test) {
            throw new IllegalStateException(msgSupplier.get());
        }
    }

    public static void assertTrue(boolean test, Supplier<String> msgSupplier, Object... msgArgs) {
        if (!test) {
            throw new IllegalStateException(String.format(msgSupplier.get(), msgArgs));
        }
    }

    public static void assertIsNegative(BigDecimal number) {
        assertTrue(number.compareTo(ZERO) < 0, () -> "Expected negative number but got: %s", number);
    }

    public static <I, O> O nullSafe(I input, Function<I, O> mapFnc) {
        return input == null ? null : mapFnc.apply(input);
    }

    public static <I, T1, O> O nullSafe(
            I input,
            Function<I, T1> mapFnc1,
            Function<T1, O> mapFnc2
    ) {
        if (input == null) {
            return null;
        }
        T1 o1 = mapFnc1.apply(input);
        if (o1 == null) {
            return null;
        }
        return mapFnc2.apply(o1);
    }

    public static String stripToNull(String str) {
        return str == null || str.isBlank() ? null : str.trim();
    }
}
