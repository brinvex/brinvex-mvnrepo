package com.brinvex.fintracker.api.model.validator;

import com.brinvex.fintracker.api.model.domain.Asset;
import com.brinvex.fintracker.api.model.domain.FinTransaction;
import com.brinvex.fintracker.api.model.domain.FinTransactionType;
import com.brinvex.fintracker.api.util.Regex;

import java.math.BigDecimal;

import static java.math.BigDecimal.ZERO;

public class FinTransactionValidator {

    private static final BigDecimal GROSS_VALUE_DEVIATION_TOLERANCE = new BigDecimal("0.001");

    @SuppressWarnings("DuplicatedCode")
    public static void validate(FinTransaction finTran) {
        if (finTran == null) {
            throw new IllegalArgumentException("finTransaction must not be null.");
        }
        if (finTran.date() == null) {
            throw new IllegalArgumentException("date must not be null - %s".formatted(finTran));
        }

        FinTransactionType type = finTran.type();
        String externalId = finTran.extraId();
        String ccy = finTran.ccy();
        BigDecimal netValue = finTran.netValue();
        BigDecimal grossValue = finTran.grossValue();
        BigDecimal qty = finTran.qty();
        Asset asset = finTran.asset();
        String symbol = (null == asset) ? null : asset.symbol();
        String country = (asset == null) ? null : asset.country();
        BigDecimal price = finTran.price();
        BigDecimal fee = finTran.fee();
        BigDecimal tax = finTran.tax();

        if (type == null) {
            throw new IllegalArgumentException("type must not be null - %s".formatted(finTran));
        }
        if (externalId == null || externalId.isBlank()) {
            throw new IllegalArgumentException("extraId cannot be null or blank.");
        }
        if (netValue == null) {
            throw new IllegalArgumentException("netValue must not be null - %s".formatted(finTran));
        }
        if (grossValue == null) {
            throw new IllegalArgumentException("grossValue must not be null - %s".formatted(finTran));
        }
        if (fee == null) {
            throw new IllegalArgumentException("fee must not be null - %s".formatted(finTran));
        }
        if (ccy == null || !Regex.Pattern.CCY.matches(ccy)) {
            throw new IllegalArgumentException("ccy must not be null and must match %s".formatted(Regex.Pattern.CCY.pattern()));
        }
        if (price != null && price.compareTo(ZERO) <= 0) {
            throw new IllegalArgumentException("price must be positive - %s".formatted(finTran));
        }
        if (qty == null) {
            throw new IllegalArgumentException("qty must not be null - %s".formatted(finTran));
        }
        if (qty.compareTo(ZERO) != 0 && asset == null) {
            throw new IllegalArgumentException("asset must not be null if qty is not zero - %s".formatted(finTran));
        }

        {
            BigDecimal calcGrossValue = netValue.subtract(fee).subtract(tax == null ? ZERO : tax);
            BigDecimal grossValueDeviation = calcGrossValue.subtract(grossValue).abs();
            if (grossValueDeviation.compareTo(GROSS_VALUE_DEVIATION_TOLERANCE) > 0) {
                throw new IllegalArgumentException("grossValue deviation exceeds tolerance - grossValue=%s, calculated grossValue=%s, deviation=%s, tolerance=%s, finTran=%s"
                        .formatted(grossValue, calcGrossValue, grossValueDeviation, GROSS_VALUE_DEVIATION_TOLERANCE, finTran));
            }
        }

        switch (type) {
            case DEPOSIT -> {
                if (finTran.settleDate() == null) {
                    throw new IllegalArgumentException("settleDate must not be null - %s".formatted(finTran));
                }
                if (netValue.compareTo(ZERO) <= 0) {
                    throw new IllegalArgumentException("netValue must be positive - %s".formatted(finTran));
                }
                if (grossValue.compareTo(ZERO) <= 0) {
                    throw new IllegalArgumentException("grossValue must be positive - %s".formatted(finTran));
                }
                if (asset != null) {
                    throw new IllegalArgumentException("asset must be null - %s".formatted(finTran));
                }
                if (qty.compareTo(ZERO) != 0) {
                    throw new IllegalArgumentException("qty must be zero - %s".formatted(finTran));
                }
                if (price != null) {
                    throw new IllegalArgumentException("price must be null - %s".formatted(finTran));
                }
                if (fee.compareTo(ZERO) > 0) {
                    throw new IllegalArgumentException("fee must be less than or equal to zero - %s".formatted(finTran));
                }
                if (tax != null && tax.compareTo(ZERO) != 0) {
                    throw new IllegalArgumentException("tax must be null or zero - %s".formatted(finTran));
                }
            }
            case WITHDRAWAL -> {
                if (finTran.settleDate() == null) {
                    throw new IllegalArgumentException("settleDate must not be null - %s".formatted(finTran));
                }
                if (netValue.compareTo(ZERO) >= 0) {
                    throw new IllegalArgumentException("netValue must be negative - %s".formatted(finTran));
                }
                if (grossValue.compareTo(ZERO) >= 0) {
                    throw new IllegalArgumentException("grossValue must be negative - %s".formatted(finTran));
                }
                if (asset != null) {
                    throw new IllegalArgumentException("asset must be null - %s".formatted(finTran));
                }
                if (qty.compareTo(ZERO) != 0) {
                    throw new IllegalArgumentException("qty must be zero - %s".formatted(finTran));
                }
                if (price != null) {
                    throw new IllegalArgumentException("price must be null - %s".formatted(finTran));
                }
                if (fee.compareTo(ZERO) > 0) {
                    throw new IllegalArgumentException("fee must be less than or equal to zero - %s".formatted(finTran));
                }
                if (tax != null && tax.compareTo(ZERO) != 0) {
                    throw new IllegalArgumentException("tax must be null or zero - %s".formatted(finTran));
                }
            }
            case BUY -> {
                if (finTran.settleDate() == null) {
                    throw new IllegalArgumentException("settleDate must not be null - %s".formatted(finTran));
                }
                if (netValue.compareTo(ZERO) >= 0) {
                    throw new IllegalArgumentException("netValue must be negative - %s".formatted(finTran));
                }
                if (grossValue.compareTo(ZERO) >= 0) {
                    throw new IllegalArgumentException("grossValue must be negative - %s".formatted(finTran));
                }
                if (symbol == null) {
                    throw new IllegalArgumentException("symbol must not be null - %s".formatted(finTran));
                }
                if (country == null) {
                    throw new IllegalArgumentException("country must not be null - %s".formatted(finTran));
                }
                if (qty.compareTo(ZERO) <= 0) {
                    throw new IllegalArgumentException("qty must be positive - %s".formatted(finTran));
                }
                if (price == null) {
                    throw new IllegalArgumentException("price must not be null - %s".formatted(finTran));
                }
                if (fee.compareTo(ZERO) > 0) {
                    throw new IllegalArgumentException("fee must be less than or equal to zero - %s".formatted(finTran));
                }
                if (tax != null && tax.compareTo(ZERO) != 0) {
                    throw new IllegalArgumentException("tax must be null or zero - %s".formatted(finTran));
                }
            }
            case SELL -> {
                if (finTran.settleDate() == null) {
                    throw new IllegalArgumentException("settleDate must not be null - %s".formatted(finTran));
                }
                if (grossValue.compareTo(ZERO) <= 0) {
                    throw new IllegalArgumentException("grossValue must be positive - %s".formatted(finTran));
                }
                if (symbol == null) {
                    throw new IllegalArgumentException("symbol must not be null - %s".formatted(finTran));
                }
                if (country == null) {
                    throw new IllegalArgumentException("country must not be null - %s".formatted(finTran));
                }
                if (qty.compareTo(ZERO) >= 0) {
                    throw new IllegalArgumentException("qty must be negative - %s".formatted(finTran));
                }
                if (price == null) {
                    throw new IllegalArgumentException("price must not be null - %s".formatted(finTran));
                }
                if (fee.compareTo(ZERO) > 0) {
                    throw new IllegalArgumentException("fee must be less than or equal to zero - %s".formatted(finTran));
                }
                if (tax != null && tax.compareTo(ZERO) != 0) {
                    throw new IllegalArgumentException("tax must be null or zero - %s".formatted(finTran));
                }
            }
            case FX_BUY -> {
                if (finTran.settleDate() == null) {
                    throw new IllegalArgumentException("settleDate must not be null - %s".formatted(finTran));
                }
                if (netValue.compareTo(ZERO) >= 0) {
                    throw new IllegalArgumentException("netValue must be negative - %s".formatted(finTran));
                }
                if (grossValue.compareTo(ZERO) >= 0) {
                    throw new IllegalArgumentException("grossValue must be negative - %s".formatted(finTran));
                }
                if (symbol == null) {
                    throw new IllegalArgumentException("symbol must not be null - %s".formatted(finTran));
                }
                if (country != null) {
                    throw new IllegalArgumentException("country must be null - %s".formatted(finTran));
                }
                if (qty.compareTo(ZERO) <= 0) {
                    throw new IllegalArgumentException("qty must be positive - %s".formatted(finTran));
                }
                if (price == null) {
                    throw new IllegalArgumentException("price must not be null - %s".formatted(finTran));
                }
                if (fee.compareTo(ZERO) > 0) {
                    throw new IllegalArgumentException("fee must be less than or equal to zero - %s".formatted(finTran));
                }
                if (tax != null && tax.compareTo(ZERO) != 0) {
                    throw new IllegalArgumentException("tax must be null or zero - %s".formatted(finTran));
                }
            }
            case FX_SELL -> {
                if (finTran.settleDate() == null) {
                    throw new IllegalArgumentException("settleDate must not be null - %s".formatted(finTran));
                }
                if (grossValue.compareTo(ZERO) <= 0) {
                    throw new IllegalArgumentException("grossValue must be positive - %s".formatted(finTran));
                }
                if (symbol == null) {
                    throw new IllegalArgumentException("symbol must not be null - %s".formatted(finTran));
                }
                if (country != null) {
                    throw new IllegalArgumentException("country must be null - %s".formatted(finTran));
                }
                if (qty.compareTo(ZERO) >= 0) {
                    throw new IllegalArgumentException("qty must be negative - %s".formatted(finTran));
                }
                if (price == null) {
                    throw new IllegalArgumentException("price must not be null - %s".formatted(finTran));
                }
                if (fee.compareTo(ZERO) > 0) {
                    throw new IllegalArgumentException("fee must be less than or equal to zero - %s".formatted(finTran));
                }
                if (tax != null && tax.compareTo(ZERO) != 0) {
                    throw new IllegalArgumentException("tax must be null or zero - %s".formatted(finTran));
                }
            }
            case CASH_DIVIDEND, INTEREST -> {
                if (finTran.settleDate() == null) {
                    throw new IllegalArgumentException("settleDate must not be null - %s".formatted(finTran));
                }
                if (grossValue.compareTo(ZERO) <= 0) {
                    throw new IllegalArgumentException("grossValue must be positive - %s".formatted(finTran));
                }
                if (symbol == null) {
                    throw new IllegalArgumentException("symbol must not be null - %s".formatted(finTran));
                }
                if (country == null) {
                    throw new IllegalArgumentException("country must not be null - %s".formatted(finTran));
                }
                if (qty.compareTo(ZERO) != 0) {
                    throw new IllegalArgumentException("qty must be zero - %s".formatted(finTran));
                }
                if (price != null) {
                    throw new IllegalArgumentException("price must be null - %s".formatted(finTran));
                }
                if (fee.compareTo(ZERO) > 0) {
                    throw new IllegalArgumentException("fee must be less than or equal to zero - %s".formatted(finTran));
                }
                if (tax != null && tax.compareTo(ZERO) > 0) {
                    throw new IllegalArgumentException("tax must be null or non-positive - %s".formatted(finTran));
                }
            }
            case STOCK_DIVIDEND -> {
                if (finTran.settleDate() == null) {
                    throw new IllegalArgumentException("settleDate must not be null - %s".formatted(finTran));
                }
                if (grossValue.compareTo(ZERO) == 0) {
                    throw new IllegalArgumentException("grossValue must be zero - %s".formatted(finTran));
                }
                if (symbol == null) {
                    throw new IllegalArgumentException("symbol must not be null - %s".formatted(finTran));
                }
                if (country == null) {
                    throw new IllegalArgumentException("country must not be null - %s".formatted(finTran));
                }
                if (qty.compareTo(ZERO) <= 0) {
                    throw new IllegalArgumentException("qty must be positive - %s".formatted(finTran));
                }
                if (price != null) {
                    throw new IllegalArgumentException("price must be null - %s".formatted(finTran));
                }
                if (fee.compareTo(ZERO) > 0) {
                    throw new IllegalArgumentException("fee must be less than or equal to zero - %s".formatted(finTran));
                }
                if (tax != null && tax.compareTo(ZERO) > 0) {
                    throw new IllegalArgumentException("tax must be null or non-positive - %s".formatted(finTran));
                }
            }
            case FEE -> {
                if (finTran.settleDate() == null) {
                    throw new IllegalArgumentException("settleDate must not be null - %s".formatted(finTran));
                }
                if (qty.compareTo(ZERO) != 0) {
                    throw new IllegalArgumentException("qty must be zero - %s".formatted(finTran));
                }
                if (price != null) {
                    throw new IllegalArgumentException("price must be null - %s".formatted(finTran));
                }
                if (fee.compareTo(ZERO) == 0) {
                    throw new IllegalArgumentException("fee must not be zero - %s".formatted(finTran));
                }
                if (tax != null && tax.compareTo(ZERO) != 0) {
                    throw new IllegalArgumentException("tax must be null or zero - %s".formatted(finTran));
                }
            }
            case TAX -> {
                if (finTran.settleDate() == null) {
                    throw new IllegalArgumentException("settleDate must not be null - %s".formatted(finTran));
                }
                if (qty.compareTo(ZERO) != 0) {
                    throw new IllegalArgumentException("qty must be zero - %s".formatted(finTran));
                }
                if (price != null) {
                    throw new IllegalArgumentException("price must be null - %s".formatted(finTran));
                }
                if (fee.compareTo(ZERO) > 0) {
                    throw new IllegalArgumentException("fee must be less than or equal to zero - %s".formatted(finTran));
                }
                if (tax == null || tax.compareTo(ZERO) == 0) {
                    throw new IllegalArgumentException("tax must not be null and must not be zero - %s".formatted(finTran));
                }
            }
            case TRANSFORMATION -> {
                if (symbol == null) {
                    throw new IllegalArgumentException("symbol must not be null - %s".formatted(finTran));
                }
                if (country == null) {
                    throw new IllegalArgumentException("country must not be null - %s".formatted(finTran));
                }
                if (price != null && price.compareTo(ZERO) < 0) {
                    throw new IllegalArgumentException("price must be null or positive - %s".formatted(finTran));
                }
                if (fee.compareTo(ZERO) != 0) {
                    throw new IllegalArgumentException("fee must not be zero - %s".formatted(finTran));
                }
                if (tax != null && tax.compareTo(ZERO) > 0) {
                    throw new IllegalArgumentException("tax must be null or non-positive - %s".formatted(finTran));
                }
            }
            case OTHER_INTERNAL_FLOW -> {
                if (qty.compareTo(ZERO) < 0) {
                    throw new IllegalArgumentException("qty must be zero or positive - %s".formatted(finTran));
                }
                if (price != null) {
                    throw new IllegalArgumentException("price must be null - %s".formatted(finTran));
                }
            }
            default -> throw new IllegalStateException("Unexpected value: %s, %s".formatted(type, finTran));
        }
    }

}
