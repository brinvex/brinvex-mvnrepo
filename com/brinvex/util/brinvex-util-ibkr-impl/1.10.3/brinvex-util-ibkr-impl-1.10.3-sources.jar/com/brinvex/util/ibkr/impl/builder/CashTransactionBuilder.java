package com.brinvex.util.ibkr.impl.builder;

import com.brinvex.util.ibkr.api.model.Currency;
import com.brinvex.util.ibkr.api.model.statement.AssetCategory;
import com.brinvex.util.ibkr.api.model.statement.AssetSubCategory;
import com.brinvex.util.ibkr.api.model.statement.CashTransaction;
import com.brinvex.util.ibkr.api.model.statement.CashTransactionType;
import com.brinvex.util.ibkr.api.model.statement.SecurityIDType;
import lombok.Setter;
import lombok.experimental.Accessors;

import java.math.BigDecimal;
import java.time.LocalDate;

@Setter
@Accessors(fluent = true, chain = true)
public class CashTransactionBuilder {

    private LocalDate reportDate;
    private Currency currency;
    private AssetCategory assetCategory;
    private AssetSubCategory assetSubCategory;
    private String symbol;
    private String description;
    private String securityID;
    private SecurityIDType securityIDType;
    private String figi;
    private String isin;
    private String listingExchange;
    private CashTransactionType type;
    private String transactionID;
    private String actionID;
    private LocalDate settleDate;
    private BigDecimal amount;
    private String extraDateTimeStr;


    public CashTransaction build() {
        return new CashTransaction(
                this.reportDate,
                this.currency,
                this.assetCategory,
                this.assetSubCategory,
                this.symbol,
                this.description,
                this.securityID,
                this.securityIDType,
                this.figi,
                this.isin,
                this.listingExchange,
                this.type,
                this.transactionID,
                this.actionID,
                this.settleDate,
                this.amount,
                this.extraDateTimeStr
        );
    }
}
