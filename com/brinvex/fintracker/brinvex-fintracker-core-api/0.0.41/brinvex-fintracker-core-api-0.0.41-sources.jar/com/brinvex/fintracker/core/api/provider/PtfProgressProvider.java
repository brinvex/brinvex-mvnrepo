package com.brinvex.fintracker.core.api.provider;

import com.brinvex.fintracker.core.api.model.domain.PtfProgress;

import java.time.Duration;
import java.time.LocalDate;
import java.util.Map;

public interface PtfProgressProvider extends Provider<PtfProgressProvider.PtfProgressReq, PtfProgress> {

    /**
     * @param institution    financial institution that provides services as intermediary for financial transactions.
     * @param ptfProps
     * @param fromDateIncl
     * @param toDateIncl
     * @param staleTolerance
     */
    record PtfProgressReq(
            String institution,
            Map<String, String> ptfProps,
            LocalDate fromDateIncl,
            LocalDate toDateIncl,
            Duration staleTolerance
    ) {
    }

}
