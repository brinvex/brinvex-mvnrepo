package com.brinvex.util.spreadsheet.impl;

import com.brinvex.util.spreadsheet.api.ExcelXlsxReader;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.IOException;
import java.io.InputStream;
import java.io.UncheckedIOException;
import java.util.List;
import java.util.Map;

@SuppressWarnings("SameParameterValue")
public class XlsxReaderImplPoi extends AbstractReaderImplPoi implements ExcelXlsxReader {

    @Override
    public List<Map<String, Object>> readColumns(
            InputStream is,
            Map<String, Class<?>> columnNamesAndTypes,
            int rowsToSkip
    ) {
        throw new RuntimeException("Not yet implemented");
    }

    @Override
    public List<Map<String, Object>> readCompactTable(InputStream is, Map<String, Class<?>> headerNamesAndTypes) {
        XSSFWorkbook workbook;
        try {
            workbook = new XSSFWorkbook(is);
        } catch (IOException e) {
            throw new UncheckedIOException(e);
        }
        XSSFSheet sheet = workbook.getSheetAt(0);

        return readTable(headerNamesAndTypes, sheet, true);
    }

}
