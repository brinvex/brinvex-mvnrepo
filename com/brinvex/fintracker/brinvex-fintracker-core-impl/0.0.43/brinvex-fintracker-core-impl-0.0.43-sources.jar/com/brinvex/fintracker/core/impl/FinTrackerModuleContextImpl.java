package com.brinvex.fintracker.core.impl;

import com.brinvex.fintracker.core.api.FinTrackerConfig;
import com.brinvex.fintracker.core.api.infra.FinTrackerModule;
import com.brinvex.fintracker.core.api.infra.FinTrackerModuleContext;
import com.brinvex.fintracker.core.api.infra.FinTrackerSupport;
import com.brinvex.util.dms.api.Dms;
import com.brinvex.util.java.validation.Assert;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.function.Supplier;

@SuppressWarnings("unused")
public class FinTrackerModuleContextImpl implements FinTrackerModuleContext {

    private static final Logger LOG = LoggerFactory.getLogger(FinTrackerModuleContextImpl.class);

    private final FinTrackerSupportImpl support;

    private final Class<? extends FinTrackerModule> moduleType;

    private final String moduleName;

    private volatile Dms dms;

    private final Map<Class<?>, Object> singletons = new LinkedHashMap<>();

    private final FinTrackerConfig config;

    public FinTrackerModuleContextImpl(
            FinTrackerSupportImpl support,
            FinTrackerConfig config,
            Class<? extends FinTrackerModule> moduleType
    ) {
        this.support = support;
        this.config = config;
        this.moduleType = moduleType;
        this.moduleName = moduleType.getSimpleName().replace("Module", "");
    }

    @Override
    public <SERVICE> SERVICE singletonService(Class<SERVICE> svcType, Supplier<SERVICE> serviceSupplier) {
        Object uncheckedSvcInstance = singletons.get(svcType);
        if (uncheckedSvcInstance == null) {
            synchronized (singletons) {
                uncheckedSvcInstance = singletons.get(svcType);
                if (uncheckedSvcInstance == null) {
                    String customSvcPropKey = FinTrackerModule.PropKey.customService.apply(svcType);
                    String customSvcFqn = getProperty(customSvcPropKey);
                    if (customSvcFqn != null) {
                        try {
                            uncheckedSvcInstance = newCustomService(customSvcFqn, serviceSupplier);
                        } catch (Exception e) {
                            String errMsg = "CustomService instantiation failed - %s, svcType=%s, %s"
                                    .formatted(customSvcFqn, svcType, e.getMessage());
                            throw new IllegalStateException(errMsg, e);
                        }
                        LOG.info("Instantiated customService={}", uncheckedSvcInstance);
                    } else {
                        uncheckedSvcInstance = serviceSupplier.get();
                    }
                    Assert.notNull(uncheckedSvcInstance);
                    singletons.put(svcType, uncheckedSvcInstance);
                }
            }
        }
        @SuppressWarnings("unchecked")
        SERVICE typedSvcInstance = (SERVICE) uncheckedSvcInstance;
        return typedSvcInstance;
    }

    @Override
    public String getProperty(String propKey, String defaultValue) {
        return config.getModuleProperty(moduleType, propKey, defaultValue);
    }

    @Override
    public Map<String, String> getProperties(String propPrefix) {
        return config.getModuleProperties(moduleType, propPrefix);
    }

    @Override
    public Dms dms() {
        if (dms == null) {
            synchronized (this) {
                if (dms == null) {
                    String dmsWorkspace = getProperty(FinTrackerModule.PropKey.dmsWorkspace, moduleName + "-dms");
                    dms = support.dmsFactory().getDms(dmsWorkspace);
                }
            }
        }
        return dms;
    }

    @Override
    public FinTrackerSupport support() {
        return support;
    }

    private <SERVICE> SERVICE newCustomService(String customSvcFqn, Supplier<SERVICE> defaultService) {
        try {
            @SuppressWarnings("unchecked")
            Constructor<SERVICE> constructor = (Constructor<SERVICE>) Class.forName(customSvcFqn)
                    .getConstructor(FinTrackerModuleContext.class, Supplier.class);
            return constructor.newInstance(this, defaultService);
        } catch (ClassNotFoundException
                 | IllegalAccessException
                 | InstantiationException
                 | NoSuchMethodException
                 | InvocationTargetException e
        ) {
            throw new IllegalStateException("Failed to instantiate %s, %s".formatted(customSvcFqn, e), e);
        }
    }
}
