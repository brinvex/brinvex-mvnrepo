package com.brinvex.fintracker.connector.rvlt.impl;

import com.brinvex.fintracker.connector.rvlt.api.RvltModule;
import com.brinvex.fintracker.connector.rvlt.api.service.RvltDms;
import com.brinvex.fintracker.connector.rvlt.api.service.RvltFinTransactionMapper;
import com.brinvex.fintracker.connector.rvlt.api.service.RvltFinTransactionMerger;
import com.brinvex.fintracker.connector.rvlt.api.service.RvltPtfProgressProvider;
import com.brinvex.fintracker.connector.rvlt.api.service.RvltStatementParser;
import com.brinvex.fintracker.connector.rvlt.impl.service.RvltDmsImpl;
import com.brinvex.fintracker.connector.rvlt.impl.service.RvltFinTransactionMapperImpl;
import com.brinvex.fintracker.connector.rvlt.impl.service.RvltFinTransactionMergerImpl;
import com.brinvex.fintracker.connector.rvlt.impl.service.RvltPtfProgressProviderImpl;
import com.brinvex.fintracker.connector.rvlt.impl.service.parser.RvltStatementParserImpl;
import com.brinvex.fintracker.core.api.FinTrackerModule;
import com.brinvex.fintracker.core.api.FinTrackerModuleContext;
import com.brinvex.fintracker.core.api.FinTrackerModuleFactory;
import com.brinvex.fintracker.core.api.provider.Provider;
import com.brinvex.fintracker.core.api.provider.PtfProgressProvider;

import java.util.List;
import java.util.SequencedCollection;
import java.util.Set;

import static java.util.Collections.emptyList;

public class RvltModuleImpl implements RvltModule, FinTrackerModule {

    public static class RvltModuleFactory implements FinTrackerModuleFactory<RvltModule> {

        @Override
        public Class<RvltModule> moduleType() {
            return RvltModule.class;
        }

        @Override
        public Set<Class<? extends Provider<?, ?>>> providerTypes() {
            return Set.of(PtfProgressProvider.class);
        }

        @Override
        public RvltModule createModule(FinTrackerModuleContext moduleCtx) {
            return new RvltModuleImpl(moduleCtx);
        }
    }

    private final FinTrackerModuleContext moduleCtx;

    public RvltModuleImpl(FinTrackerModuleContext moduleCtx) {
        this.moduleCtx = moduleCtx;
    }

    @Override
    public SequencedCollection<Provider<?, ?>> providers(Class<? extends Provider<?, ?>> providerType) {
        if (providerType == PtfProgressProvider.class) {
            return List.of(ptfProgressProvider());
        }
        return emptyList();
    }

    @Override
    public RvltStatementParser statementParser() {
        return moduleCtx.singletonService(RvltStatementParser.class, () -> new RvltStatementParserImpl(moduleCtx.toolbox().pdfReader()));
    }

    @Override
    public RvltDms dms() {
        return moduleCtx.singletonService(RvltDms.class, () -> new RvltDmsImpl(moduleCtx.dms()));
    }

    @Override
    public RvltFinTransactionMerger finTransactionMerger() {
        return moduleCtx.singletonService(RvltFinTransactionMerger.class, RvltFinTransactionMergerImpl::new);
    }

    @Override
    public RvltFinTransactionMapper finTransactionMapper() {
        return moduleCtx.singletonService(RvltFinTransactionMapper.class, RvltFinTransactionMapperImpl::new);
    }

    @Override
    public RvltPtfProgressProvider ptfProgressProvider() {
        return moduleCtx.singletonService(RvltPtfProgressProvider.class, () -> new RvltPtfProgressProviderImpl(
                dms(),
                statementParser(),
                finTransactionMerger(),
                finTransactionMapper()
        ));
    }
}
