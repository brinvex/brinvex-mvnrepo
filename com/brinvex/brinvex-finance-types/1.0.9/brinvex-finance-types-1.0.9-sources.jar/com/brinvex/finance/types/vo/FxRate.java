package com.brinvex.finance.types.vo;

import com.brinvex.finance.types.enu.Currency;

import java.io.Serializable;
import java.time.LocalDate;

public record FxRate(
        Currency baseCcy,
        Currency quoteCcy,
        LocalDate fromDateIncl,
        LocalDate toDateIncl,
        double rate
) implements Serializable {

    public FxRate {
        if (baseCcy == null) {
            throw new IllegalArgumentException("baseCcy must not be null");
        }
        if (quoteCcy == null) {
            throw new IllegalArgumentException("quoteCcy must not be null");
        }
        if (fromDateIncl != null && toDateIncl != null) {
            if (fromDateIncl.isAfter(toDateIncl)) {
                throw new IllegalArgumentException("fromDateIncl must not be after toDateIncl, %s, %s".formatted(fromDateIncl, toDateIncl));
            }
        }
    }

    public FxRate(Currency baseCcy, Currency quoteCcy, double rate) {
        this(baseCcy, quoteCcy, null, null, rate);
    }

    public FxRate(Currency baseCcy, Currency quoteCcy, LocalDate fromDateIncl, double rate) {
        this(baseCcy, quoteCcy, fromDateIncl, fromDateIncl, rate);
    }

    public FxRate(CurrencyPair ccyPair, LocalDate fromDateIncl, LocalDate toDateIncl, double rate) {
        this(ccyPair.baseCcy(), ccyPair.quoteCcy(), fromDateIncl, toDateIncl, rate);
    }

    public FxRate(CurrencyPair ccyPair, LocalDate fromDateIncl, double rate) {
        this(ccyPair.baseCcy(), ccyPair.quoteCcy(), fromDateIncl, fromDateIncl, rate);
    }

    public FxRate inverse() {
        return new FxRate(quoteCcy, baseCcy, fromDateIncl, toDateIncl, 1.0 / rate);
    }

    @Override
    public String toString() {
        return "%s/%s,%s,%s,%s".formatted(baseCcy, quoteCcy, fromDateIncl, toDateIncl, rate);
    }
}
