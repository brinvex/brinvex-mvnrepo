package com.brinvex.tool.tnet.impl;

import org.apache.hc.client5.http.classic.methods.HttpPost;
import org.apache.hc.client5.http.impl.classic.CloseableHttpClient;
import org.apache.hc.client5.http.impl.classic.HttpClients;
import org.apache.hc.core5.http.HttpEntity;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;

import static java.nio.charset.StandardCharsets.UTF_8;

@SuppressWarnings("JavadocLinkAsPlainText")
public class DockerEngineClient implements AutoCloseable {

    private static final Logger LOG = LoggerFactory.getLogger(DockerEngineClient.class);

    private final String baseUrl;

    private final CloseableHttpClient dockerEngineHttpClient;

    public DockerEngineClient(String baseUrl) {
        this.baseUrl = baseUrl;
        dockerEngineHttpClient = HttpClients.createDefault();
    }

    /**
     * https://docs.docker.com/engine/api/v1.41/#tag/Container/operation/ContainerRestart
     */
    public void containerRestart(String containerIdOrName) throws IOException {
        String url = baseUrl + "/containers/%s/restart".formatted(containerIdOrName);
        LOG.debug("containerRestart - POST {}", url);
        dockerEngineHttpClient.execute(new HttpPost(url), resp -> {
            int respCode = resp.getCode();
            if (respCode != 204) {
                HttpEntity entity = resp.getEntity();
                String body = entity == null ? null : new String(entity.getContent().readAllBytes(), UTF_8);
                throw new IllegalStateException("containerRestart failed - respCode=%s, body=%s"
                        .formatted(respCode, body));
            }
            return null;
        });
    }

    @Override
    public void close() throws Exception {
        dockerEngineHttpClient.close();
    }

}
