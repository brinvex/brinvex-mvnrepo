package com.brinvex.fintracker.core.api;

import com.brinvex.fintracker.core.api.facade.PdfReaderFacade;
import com.brinvex.fintracker.core.api.facade.ValidatorFacade;
import com.brinvex.util.dms.api.DmsFactory;

public interface ToolboxModule extends FinTrackerModule {

    DmsFactory dmsFactory();

    ValidatorFacade validator();

    PdfReaderFacade pdfReader();
}
