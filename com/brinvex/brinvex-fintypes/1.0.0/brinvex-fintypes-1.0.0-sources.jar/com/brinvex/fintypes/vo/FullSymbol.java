package com.brinvex.fintypes.vo;

import com.brinvex.fintypes.enu.Country;

import java.io.Serializable;

import static java.util.Objects.requireNonNull;

/// Cited from <a href="https://en.wikipedia.org/wiki/Ticker_symbol">Wikipedia: Ticker Symbol</a>:
///
/// > A ticker symbol, or stock symbol, is an abbreviation used to uniquely identify
///   publicly traded shares of a specific stock or security on a stock exchange.
/// >
/// > To fully qualify a stock, both the ticker and the exchange or country of listing needs to be known.
/// On many systems both must be specified to uniquely identify the security.
/// This is often done by appending the location or exchange code to the ticker. </cite>
///
/// This implementation **qualifies the stock by its symbol, along with the country of listing**.
public record FullSymbol(
        String symbol,
        Country country
) implements Serializable {

    public static final char DEFAULT_SEPARATOR = '.';

    public FullSymbol {
        requireNonNull(symbol, () -> "symbol must not be null; country=%s".formatted(country));
        requireNonNull(country, () -> "country must not be null; symbol=%s".formatted(symbol));
    }

    /// Works like {@link #of(String, char)} with the separator defaulting to `'.'`.
    public static FullSymbol of(String str) {
        return of(str, DEFAULT_SEPARATOR);
    }

    /// Creates a [FullSymbol] from a string representation of a financial instrument symbol
    /// and its country of listing. The input string should be in the format of
    /// `<symbol><separator><country>`, where the country is represented by a two-letter country code.
    /// If `<separator><country>` part is not present in the given string, the default country is set to US.
    ///
    /// @param str       The string representing the stock symbol and its country of listing.
    /// @param separator The character used to separate the stock symbol from the country code.
    public static FullSymbol of(String str, char separator) {
        String symbol;
        Country country;
        int length = str.length();
        if (length >= 3 && str.charAt(length - 3) == separator) {
            symbol = str.substring(0, length - 3);
            country = Country.valueOf(str.substring(length - 2));
        } else {
            symbol = str;
            country = Country.US;
        }
        return new FullSymbol(symbol, country);
    }

    public String format() {
        return format(symbol, country, DEFAULT_SEPARATOR);
    }

    public String format(char separator) {
        return format(symbol, country, separator);
    }

    public static String format(String symbol, Country country) {
        return format(symbol, country, DEFAULT_SEPARATOR);
    }

    public static String format(String symbol, Country country, char separator) {
        return "%s%s%s".formatted(symbol, separator, country);
    }

    @Override
    public String toString() {
        return format();
    }

}
