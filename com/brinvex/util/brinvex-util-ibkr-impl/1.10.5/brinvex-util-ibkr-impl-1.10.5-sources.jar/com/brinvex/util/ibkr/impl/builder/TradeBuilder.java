/*
 * Copyright © 2023 Brinvex (dev@brinvex.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.brinvex.util.ibkr.impl.builder;

import com.brinvex.util.ibkr.api.model.Currency;
import com.brinvex.util.ibkr.api.model.statement.AssetCategory;
import com.brinvex.util.ibkr.api.model.statement.AssetSubCategory;
import com.brinvex.util.ibkr.api.model.statement.BuySell;
import com.brinvex.util.ibkr.api.model.statement.SecurityIDType;
import com.brinvex.util.ibkr.api.model.statement.Trade;
import com.brinvex.util.ibkr.api.model.statement.TradeType;
import lombok.Setter;
import lombok.experimental.Accessors;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.ZonedDateTime;

@Setter
@Accessors(fluent = true, chain = true)
public class TradeBuilder {
    private Currency currency;
    private AssetCategory assetCategory;
    private AssetSubCategory assetSubCategory;
    private String symbol;
    private String description;
    private String securityID;
    private SecurityIDType securityIDType;
    private String figi;
    private String isin;
    private String listingExchange;
    private String tradeID;
    private LocalDate reportDate;
    private LocalDate tradeDate;
    private LocalDate settleDateTarget;
    private TradeType transactionType;
    private String exchange;
    private BigDecimal quantity;
    private BigDecimal tradePrice;
    private BigDecimal tradeMoney;
    private BigDecimal proceeds;
    private BigDecimal taxes;
    private BigDecimal ibCommission;
    private Currency ibCommissionCurrency;
    private BigDecimal netCash;
    private BigDecimal cost;
    private BuySell buySell;
    private String transactionID;
    private String ibOrderID;
    private String extraDateTimeStr;
    private ZonedDateTime orderTime;

    public Trade build() {
        return new Trade(
                this.currency,
                this.assetCategory,
                this.assetSubCategory,
                this.symbol,
                this.description,
                this.securityID,
                this.securityIDType,
                this.figi,
                this.isin,
                this.listingExchange,
                this.tradeID,
                this.reportDate,
                this.tradeDate,
                this.settleDateTarget,
                this.transactionType,
                this.exchange,
                this.quantity,
                this.tradePrice,
                this.tradeMoney,
                this.proceeds,
                this.taxes,
                this.ibCommission,
                this.ibCommissionCurrency,
                this.netCash,
                this.cost,
                this.buySell,
                this.transactionID,
                this.ibOrderID,
                this.extraDateTimeStr,
                this.orderTime
        );
    }
}
