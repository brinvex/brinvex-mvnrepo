package com.brinvex.fintracker.connector.ibkr.api.model;

import com.brinvex.fintracker.core.api.domain.enu.Currency;
import com.brinvex.fintracker.core.api.domain.vo.Account;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.StringJoiner;

import static java.util.Collections.emptyList;
import static java.util.Collections.unmodifiableMap;
import static java.util.Comparator.comparing;
import static java.util.Optional.ofNullable;
import static java.util.function.Predicate.not;

/**
 * On August 1, 2024, Interactive Brokers Ireland Limited (IBIE) and
 * Interactive Brokers Central Europe Zrt. (IBCE) merged into a single entity,
 * with all former IBCE clients now serviced by IBIE.
 * As a result, former IBCE clients got new Account IDs under IBIE.
 */
public record IbkrAccount(
        String id,
        Currency ccy,
        LocalDate openDate,
        LocalDate closeDate,
        Credentials credentials,
        LocalDate idValidFromIncl,
        List<MigratedAccount> migratedAccounts
) {

    public record MigratedAccount(
            String id,
            Credentials credentials,
            LocalDate idValidFromIncl,
            LocalDate idValidToIncl
    ) {
        public MigratedAccount {
            if (id == null || id.isBlank()) {
                throw new IllegalArgumentException("id must not be null or blank");
            }
            if (idValidFromIncl == null) {
                throw new IllegalArgumentException("idValidFromIncl must not be null");
            }
            if (idValidToIncl == null) {
                throw new IllegalArgumentException("idValidToIncl must not be null");
            }
            if (idValidToIncl.isBefore(idValidFromIncl)) {
                throw new IllegalArgumentException("idValidToIncl must not be before idValidFromIncl, given: %s %s".formatted(idValidToIncl, idValidFromIncl));
            }
        }
    }

    public record Credentials(
            String token,
            String activityFlexQueryId,
            String tradeConfirmFlexQueryId
    ) {
        public Credentials {
            if (token == null || token.isBlank()) {
                throw new IllegalArgumentException("token must not be null or blank");
            }
            if (activityFlexQueryId == null || activityFlexQueryId.isBlank()) {
                throw new IllegalArgumentException("activityFlexQueryId must not be null or blank");
            }
            if (tradeConfirmFlexQueryId != null && tradeConfirmFlexQueryId.isBlank()) {
                tradeConfirmFlexQueryId = null;
            }
        }

        @Override
        public String toString() {
            return new StringJoiner(", ", "Credentials[", "]")
                    .add("actFlexQueryId=***%s".formatted(activityFlexQueryId == null ? null : activityFlexQueryId.substring(activityFlexQueryId.length() - 2)))
                    .add("tcFlexQueryId=***%s".formatted(tradeConfirmFlexQueryId == null ? null : tradeConfirmFlexQueryId.substring(tradeConfirmFlexQueryId.length() - 2)))
                    .toString();
        }
    }

    public IbkrAccount {
        if (id == null) {
            throw new IllegalArgumentException("id must not be null");
        }
        if (ccy == null) {
            throw new IllegalArgumentException("ccy must not be null");
        }
        if (openDate == null) {
            throw new IllegalArgumentException("openDate must not be null");
        }
        if (closeDate != null && openDate.isAfter(closeDate)) {
            throw new IllegalArgumentException("openDate must not be after closeDate, given: %s, %s".formatted(openDate, closeDate));
        }
        if (idValidFromIncl == null) {
            idValidFromIncl = openDate;
        } else {
            if (idValidFromIncl.isBefore(openDate) || (closeDate != null && idValidFromIncl.isAfter(closeDate))) {
                throw new IllegalArgumentException("idValidFromIncl must be between openDate and closeDate, given: %s, %s, %s"
                        .formatted(idValidFromIncl, openDate, closeDate));
            }
        }
        if (migratedAccounts == null) {
            migratedAccounts = emptyList();
        } else {
            for (MigratedAccount migratedAccount : migratedAccounts) {
                if (migratedAccount.idValidFromIncl.isBefore(openDate)) {
                    throw new IllegalArgumentException("migratedAccount.idValidFromIncl must not be before openDate, given: %s, %s"
                            .formatted(migratedAccount.idValidFromIncl, openDate));
                }
                if (closeDate != null && migratedAccount.idValidToIncl.isAfter(closeDate)) {
                    throw new IllegalArgumentException("migratedAccount.idValidToIncl must not be after closeDate, given: %s, %s"
                            .formatted(migratedAccount.idValidToIncl, closeDate));
                }
            }
        }
    }

    public static IbkrAccount of(Account account) {
        Map<String, String> extraProps = new LinkedHashMap<>(account.extraProps());
        LocalDate idValidFrom = ofNullable(extraProps.remove("idValidFromIncl")).filter(not(String::isBlank)).map(LocalDate::parse).orElse(null);
        String actFlexQueryId = ofNullable(extraProps.remove("activityFlexQueryId")).filter(not(String::isBlank)).orElse(null);
        String tcFlexQueryId = ofNullable(extraProps.remove("tradeConfirmFlexQueryId")).filter(not(String::isBlank)).orElse(null);
        Credentials credentials = account.credentials() == null ? null : new Credentials(account.credentials(), actFlexQueryId, tcFlexQueryId);

        List<MigratedAccount> migrAccounts = new ArrayList<>();
        for (int migrIdx = 1; ; migrIdx++) {
            String migratedId = extraProps.remove("migrated%s.id".formatted(migrIdx));
            if (migratedId == null || migratedId.isEmpty()) {
                break;
            }
            String migrToken = extraProps.remove("migrated%s.credentials".formatted(migrIdx));
            LocalDate migrIdValidFromIncl = ofNullable(extraProps.remove("migrated%s.idValidFromIncl".formatted(migrIdx))).filter(not(String::isBlank)).map(LocalDate::parse).orElse(null);
            LocalDate migrIdValidToIncl = ofNullable(extraProps.remove("migrated%s.idValidToIncl".formatted(migrIdx))).filter(not(String::isBlank)).map(LocalDate::parse).orElse(null);
            Credentials migrCredentials;
            if (migrToken != null && !migrToken.isEmpty()) {
                String migrActivityFlexQueryId = ofNullable(extraProps.remove("migrated%s.activityFlexQueryId".formatted(migrIdx))).filter(not(String::isBlank)).orElse(null);
                String migrTradeConfirmFlexQueryId = ofNullable(extraProps.remove("migrated%s.tradeConfirmFlexQueryId".formatted(migrIdx))).filter(not(String::isBlank)).orElse(null);
                migrCredentials = new Credentials(migrToken, migrActivityFlexQueryId, migrTradeConfirmFlexQueryId);
            } else {
                migrCredentials = null;
            }
            MigratedAccount oldAccount = new MigratedAccount(
                    migratedId,
                    migrCredentials,
                    migrIdValidFromIncl,
                    migrIdValidToIncl
            );
            migrAccounts.add(oldAccount);
        }
        List<MigratedAccount> sortedMigrAccounts = migrAccounts.stream()
                .sorted(comparing(MigratedAccount::idValidFromIncl).thenComparing(MigratedAccount::idValidToIncl))
                .toList();
        if (!migrAccounts.equals(sortedMigrAccounts)) {
            throw new IllegalArgumentException("migratedAccounts must be sorted");
        }
        if (!extraProps.isEmpty()) {
            throw new IllegalArgumentException("Unexpected extraProps: %s".formatted(extraProps.keySet()));
        }

        return new IbkrAccount(
                account.id(),
                account.ccy(),
                account.openDate(),
                account.closeDate(),
                credentials,
                idValidFrom,
                migrAccounts
        );
    }

    public static IbkrAccount of(Map<String, String> props) {
        Account account = Account.of(props);
        return account == null ? null : IbkrAccount.of(account);
    }

    public Account toBaseAccount() {
        LinkedHashMap<String, String> extraProps = new LinkedHashMap<>();
        for (int migrIdx = 1, migratedAccountsSize = migratedAccounts.size(); migrIdx <= migratedAccountsSize; migrIdx++) {
            MigratedAccount migrAccount = migratedAccounts.get(migrIdx - 1);
            extraProps.put("migrated%s.id".formatted(migrIdx), migrAccount.id());
            extraProps.put("migrated%s.idValidFromIncl".formatted(migrIdx), migrAccount.idValidFromIncl().toString());
            extraProps.put("migrated%s.idValidToIncl".formatted(migrIdx), migrAccount.idValidToIncl().toString());
            Credentials migrCredentials = migrAccount.credentials;
            if (migrCredentials != null) {
                extraProps.put("migrated%s.credentials".formatted(migrIdx), migrCredentials.token);
                extraProps.put("migrated%s.activityFlexQueryId".formatted(migrIdx), migrCredentials.activityFlexQueryId);
                if (migrCredentials.tradeConfirmFlexQueryId != null) {
                    extraProps.put("migrated%s.tradeConfirmFlexQueryId".formatted(migrIdx), migrCredentials.tradeConfirmFlexQueryId);
                }
            }
        }
        return new Account(
                id,
                null,
                null,
                ccy,
                openDate,
                closeDate,
                credentials == null ? null : credentials.token,
                unmodifiableMap(extraProps)
        );
    }
}
