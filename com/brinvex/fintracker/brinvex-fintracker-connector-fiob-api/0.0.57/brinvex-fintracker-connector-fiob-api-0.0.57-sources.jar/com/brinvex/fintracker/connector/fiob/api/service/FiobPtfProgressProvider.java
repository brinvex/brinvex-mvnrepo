package com.brinvex.fintracker.connector.fiob.api.service;

import com.brinvex.fintracker.connector.fiob.api.model.FiobAccount;
import com.brinvex.fintracker.core.api.domain.dto.PtfProgress;
import com.brinvex.fintracker.core.api.provider.PtfProgressProvider;

import java.time.Duration;
import java.time.LocalDate;

public interface FiobPtfProgressProvider extends PtfProgressProvider {

    PtfProgress getPtfProgress(
            FiobAccount fiobAccount,
            LocalDate fromDateIncl,
            LocalDate toDateIncl,
            Duration staleTolerance
    );

    PtfProgress getPtfProgressOffline(
            FiobAccount fiobAccount,
            LocalDate fromDateIncl,
            LocalDate toDateIncl
    );

}
