package com.brinvex.fintracker.connector.fiob.api.service;

import com.brinvex.fintracker.connector.fiob.api.model.statement.TradingTransaction;
import com.brinvex.fintracker.core.api.model.domain.FinTransaction;

import java.util.List;

public interface FiobFinTransactionMapper {

    List<FinTransaction> mapTradingTransactions(List<TradingTransaction> tradingTrans);

}
