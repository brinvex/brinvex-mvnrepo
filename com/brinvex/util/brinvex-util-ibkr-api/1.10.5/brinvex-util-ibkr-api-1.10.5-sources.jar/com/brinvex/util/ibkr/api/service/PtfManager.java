/*
 * Copyright © 2023 Brinvex (dev@brinvex.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.brinvex.util.ibkr.api.service;

import com.brinvex.util.ibkr.api.model.Country;
import com.brinvex.util.ibkr.api.model.Currency;
import com.brinvex.util.ibkr.api.model.FinTransaction;
import com.brinvex.util.ibkr.api.extension.Holding;
import com.brinvex.util.ibkr.api.extension.Portfolio;

import java.math.BigDecimal;
import java.util.Collection;
import java.util.List;
import java.util.Set;

public interface PtfManager {

    Portfolio initPortfolio(String accountId);

    Set<Currency> getCurrencies(Portfolio ptf);

    BigDecimal getCash(Portfolio ptf, Currency ccy);

    List<Holding> getHoldings(Portfolio ptf);

    BigDecimal getHoldingQty(Portfolio ptf, Country country, String symbol);

    List<FinTransaction> getTransactions(Portfolio ptf);

    void applyTransaction(Portfolio ptf, FinTransaction tran);

    void applyTransactions(Portfolio ptf, Collection<FinTransaction> trans);

    static PtfManager create() {
        try {
            return (PtfManager) Class.forName("com.brinvex.util.ibkr.impl.PtfManagerImpl")
                    .getConstructor()
                    .newInstance();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}
