package com.brinvex.util.ibkr.api.model;

import com.brinvex.util.ibkr.api.model.statement.AssetCategory;
import com.brinvex.util.ibkr.api.model.statement.AssetSubCategory;

public enum InstrumentType {

    STK_COMMON,
    STK_ADR,
    STK_REIT,
    ETF,
    CASH;

    public static InstrumentType fromAssetCategory(AssetCategory assetCategory) {
        return fromAssetCategory(assetCategory, null);
    }

    public static InstrumentType fromAssetCategory(AssetCategory assetCategory, AssetSubCategory assetSubCategory) {
        return switch (assetCategory) {
            case null -> null;
            case STK -> switch (assetSubCategory) {
                case COMMON -> STK_COMMON;
                case ADR -> STK_ADR;
                case REIT -> STK_REIT;
                case ETF -> ETF;
            };
            case CASH -> CASH;
        };
    }

}
