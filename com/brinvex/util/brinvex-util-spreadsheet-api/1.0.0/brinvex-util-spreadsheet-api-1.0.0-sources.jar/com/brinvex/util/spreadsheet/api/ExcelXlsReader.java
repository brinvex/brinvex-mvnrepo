package com.brinvex.util.spreadsheet.api;

public interface ExcelXlsReader extends ExcelReader{
}
