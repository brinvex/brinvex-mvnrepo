package com.brinvex.fintracker.connector.rvlt.api;

import com.brinvex.fintracker.connector.rvlt.api.service.RvltFinTransactionMapper;
import com.brinvex.fintracker.connector.rvlt.api.service.RvltDms;
import com.brinvex.fintracker.connector.rvlt.api.service.RvltFinTransactionMerger;
import com.brinvex.fintracker.connector.rvlt.api.service.RvltPtfProgressProvider;
import com.brinvex.fintracker.connector.rvlt.api.service.RvltStatementParser;
import com.brinvex.fintracker.core.api.infra.FinTrackerModule;

public interface RvltModule extends FinTrackerModule {

    RvltStatementParser statementParser();

    RvltDms dms();

    RvltFinTransactionMerger finTransactionMerger();

    RvltFinTransactionMapper finTransactionMapper();

    RvltPtfProgressProvider ptfProgressProvider();

}
