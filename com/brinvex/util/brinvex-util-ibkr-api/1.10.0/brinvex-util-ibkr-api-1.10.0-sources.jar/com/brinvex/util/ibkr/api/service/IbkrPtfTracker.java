package com.brinvex.util.ibkr.api.service;

import com.brinvex.util.ibkr.api.model.Credentials;
import com.brinvex.util.ibkr.api.model.PtfProgress;

import java.time.Duration;
import java.time.LocalDate;

public interface IbkrPtfTracker {

    PtfProgress getPortfolioProgressOffline(
            String accountId,
            LocalDate fromDayIncl,
            LocalDate toDayIncl
    );

    PtfProgress getPortfolioProgressOnline(
            String accountId,
            Credentials credential,
            LocalDate fromDayIncl,
            LocalDate toDayIncl,
            Duration staleTolerance
    );

    static IbkrPtfTracker create(com.brinvex.util.dms.api.Dms dms) {
        return create(
                IbkrDms.create(dms),
                IbkrStatementParser.create(),
                IbkrFetcher.create(),
                IbkrStatementMerger.create(),
                IbkrTransactionMapper.create()
        );
    }

    static IbkrPtfTracker create(IbkrDms dms, IbkrStatementParser parser, IbkrFetcher fetcher, IbkrStatementMerger statementMerger, IbkrTransactionMapper transMapper) {
        try {
            return (IbkrPtfTracker) Class.forName("com.brinvex.util.ibkr.impl.IbkrPtfTrackerImpl")
                    .getConstructor(IbkrDms.class, IbkrStatementParser.class, IbkrFetcher.class, IbkrStatementMerger.class, IbkrTransactionMapper.class)
                    .newInstance(dms, parser, fetcher, statementMerger, transMapper);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}
