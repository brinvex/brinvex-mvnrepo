package com.brinvex.fintracker.core.api.model.domain;

import static com.brinvex.fintracker.core.api.model.domain.FinTransactionFlowType.EXTERNAL;
import static com.brinvex.fintracker.core.api.model.domain.FinTransactionFlowType.INTERNAL;

public enum FinTransactionType {

    DEPOSIT(EXTERNAL),

    WITHDRAWAL(EXTERNAL),

    BUY(INTERNAL),

    SELL(INTERNAL),

    FX_BUY(INTERNAL),

    FX_SELL(INTERNAL),

    DIVIDEND(INTERNAL),

    INTEREST(INTERNAL),

    FEE(INTERNAL),

    TAX(INTERNAL),

    TRANSFORMATION(INTERNAL),

    OTHER_INTERNAL_FLOW(INTERNAL);

    private final FinTransactionFlowType flowType;

    FinTransactionType(FinTransactionFlowType flowType) {
        this.flowType = flowType;
    }

    public FinTransactionFlowType flowType() {
        return flowType;
    }
}
