package com.brinvex.util.tnet.impl;

import com.brinvex.util.tnet.api.TNetException;
import com.brinvex.util.tnet.api.TNet;
import com.brinvex.util.tnet.api.TNetRequest;
import com.brinvex.util.tnet.api.TNetResponse;
import com.brinvex.util.tnet.impl.ResourcePool.ResourceReturnPlacement;
import org.apache.hc.client5.http.classic.methods.HttpGet;
import org.apache.hc.client5.http.classic.methods.HttpPost;
import org.apache.hc.client5.http.impl.classic.CloseableHttpClient;
import org.apache.hc.client5.http.impl.classic.HttpClientBuilder;
import org.apache.hc.client5.http.impl.classic.HttpClients;
import org.apache.hc.client5.http.impl.io.PoolingHttpClientConnectionManager;
import org.apache.hc.client5.http.impl.io.PoolingHttpClientConnectionManagerBuilder;
import org.apache.hc.client5.http.ssl.SSLConnectionSocketFactory;
import org.apache.hc.core5.http.ClassicHttpRequest;
import org.apache.hc.core5.http.ClassicHttpResponse;
import org.apache.hc.core5.http.Header;
import org.apache.hc.core5.http.HttpEntity;
import org.apache.hc.core5.http.NoHttpResponseException;
import org.apache.hc.core5.http.io.entity.StringEntity;
import org.apache.hc.core5.http.protocol.HttpContext;
import org.apache.hc.core5.io.CloseMode;
import org.apache.hc.core5.ssl.SSLContexts;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.net.ssl.SSLContext;
import java.io.IOException;
import java.io.UncheckedIOException;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.Socket;
import java.net.SocketException;
import java.net.URI;
import java.nio.charset.Charset;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.StringJoiner;
import java.util.concurrent.ThreadLocalRandom;
import java.util.concurrent.TimeoutException;
import java.util.regex.Pattern;

import static com.brinvex.util.tnet.impl.TNetImpl.LazyHolder.LOG;
import static com.brinvex.util.tnet.impl.TNetImpl.LazyHolder.READINESS_PROBE_BODY_PATTERN;
import static java.lang.String.format;
import static java.nio.charset.StandardCharsets.UTF_8;
import static java.util.Objects.requireNonNull;
import static java.util.stream.Collectors.groupingBy;
import static java.util.stream.Collectors.mapping;
import static java.util.stream.Collectors.toList;

/**
 * <br>https://stackoverflow.com/questions/70011046/how-to-use-a-socks-proxy-with-java-jdk-httpclient
 * <br>https://bugs.openjdk.java.net/browse/JDK-8214516,
 * <br>https://www.baeldung.com/java-connect-via-proxy-server
 * <br>https://www.baeldung.com/java-http-request
 */
@SuppressWarnings("JavadocLinkAsPlainText")
public class TNetImpl implements TNet {

    protected final String socksProxyHost;

    protected final int proxyBasePort;

    protected final int proxyPortOffset;

    protected final int numHttpClients;

    protected final ResourcePool<CloseableHttpClient> tHttpClientPool;

    protected final ResourcePool<CloseableHttpClient> rawHttpClientPool;

    protected final DockerEngineClient dockerEngineClient;

    protected final CloseableHttpClient proxyProbeHttpClient;

    protected final String proxyServerDockerContNamePattern;

    protected static class LazyHolder {
        static final Logger LOG = LoggerFactory.getLogger(TNetImpl.class);

        static final Pattern READINESS_PROBE_BODY_PATTERN = Pattern.compile(
                "^<html>\\s+<head>\\s+<title>This is a SOCKS Proxy, Not An HTTP Proxy</title>.*", Pattern.DOTALL);
    }

    protected static class Socks5ProxySSLConnectionSocketFactory extends SSLConnectionSocketFactory {

        private final Proxy socksProxy;

        public Socks5ProxySSLConnectionSocketFactory(SSLContext sslContext, InetSocketAddress socksProxyAddress) {
            super(sslContext);
            socksProxy = new Proxy(Proxy.Type.SOCKS, requireNonNull(socksProxyAddress));
        }

        @Override
        public Socket createSocket(HttpContext context) {
            LazyHolder.LOG.trace("createSocket - socksProxy={}", socksProxy);
            return new Socket(socksProxy);
        }

        @Override
        public Socket createSocket(Proxy proxy, HttpContext context) {
            if (proxy != null) {
                throw new UnsupportedOperationException(
                        "Could not use socksProxy and some other proxy at the same time - socksProxy=%s, otherProxy=%s"
                                .formatted(socksProxy, proxy));
            }
            LazyHolder.LOG.trace("createSocket - socksProxy={}", socksProxy);
            return new Socket(socksProxy);
        }
    }


    public TNetImpl(int numHttpClients1, String proxyServerDockerContNamePattern) {
        this(numHttpClients1, 9050, proxyServerDockerContNamePattern);
    }

    public TNetImpl(int numHttpClients, int proxyBasePort, String proxyServerDockerContNamePattern) {
        this(
                numHttpClients,
                "http://127.0.0.1:2375",
                "127.0.0.1",
                proxyBasePort,
                1,
                Duration.ofSeconds(60),
                proxyServerDockerContNamePattern
        );
    }

    public TNetImpl(
            int numHttpClients,
            String dockerEngineAddress,
            String socksProxyHost,
            int socksProxyBasePort,
            int socksProxyPortOffset,
            Duration pollTimeout,
            String proxyServerDockerContNamePattern
    ) {
        LOG.debug("construct - numHttpClients={}, socksProxyHost={}, socksProxyBasePort={}, socksProxyPortOffset={}, pollTimeout={}, dockerEngineAddress={}, this={}",
                numHttpClients, socksProxyHost, socksProxyBasePort, socksProxyPortOffset, pollTimeout, dockerEngineAddress, this);
        this.numHttpClients = numHttpClients;
        this.socksProxyHost = socksProxyHost;
        this.proxyBasePort = socksProxyBasePort;
        this.proxyPortOffset = socksProxyPortOffset;
        this.tHttpClientPool = new ResourcePool<>(numHttpClients, pollTimeout, this::initTHttpClient);
        this.rawHttpClientPool = new ResourcePool<>(numHttpClients, pollTimeout, this::initRawHttpClient);
        this.dockerEngineClient = new DockerEngineClient(dockerEngineAddress);
        this.proxyProbeHttpClient = HttpClients.createDefault();
        this.proxyServerDockerContNamePattern = proxyServerDockerContNamePattern;

        try {
            LOG.debug("TNetImpl - eagerly initializing 1 httpClient {}", this);
            tHttpClientPool.execute(ResourceReturnPlacement.HEAD, (index, httpClient, restartNotifier) -> null);
        } catch (TimeoutException e) {
            LOG.warn("TNetImpl - TimeoutException while initializing workerHttpClientPool %s".formatted(this), e);
        } catch (InterruptedException e) {
            LOG.warn("TNetImpl - interrupted while initializing workerHttpClientPool {}", this);
            Thread.currentThread().interrupt();
        }
    }

    @Override
    public void close() throws Exception {
        LOG.debug("Closing this={}", this);
        dockerEngineClient.close();
        proxyProbeHttpClient.close();
        tHttpClientPool.close();
    }

    protected CloseableHttpClient initTHttpClient(int httpClientIndex, CloseableHttpClient oldHttpClient) {
        LOG.debug("initTHttpClient - index={}, oldHttpClient={}", httpClientIndex, oldHttpClient);
        int proxyPort = proxyBasePort + httpClientIndex * proxyPortOffset;

        if (oldHttpClient != null) {
            oldHttpClient.close(CloseMode.GRACEFUL);
        }
        try {
            initProxyServer(socksProxyHost, proxyPort);
        } catch (IOException e) {
            throw new UncheckedIOException("Exception while initializing proxy server - index=%s, proxyHost=%s, proxyPort=%s"
                    .formatted(httpClientIndex, socksProxyHost, proxyPort), e);
        }
        {
            InetSocketAddress proxyAddress = InetSocketAddress.createUnresolved(socksProxyHost, proxyPort);
            PoolingHttpClientConnectionManager cm = PoolingHttpClientConnectionManagerBuilder.create()
                    .setSSLSocketFactory(new Socks5ProxySSLConnectionSocketFactory(SSLContexts.createSystemDefault(), proxyAddress))
                    .build();
            HttpClientBuilder httpClientBuilder = HttpClientBuilder.create().setConnectionManager(cm);
            CloseableHttpClient newHttpClient = httpClientBuilder.build();
            LOG.trace("initTNet - ok - index={}, oldHttpClient={}, newHttpClient={}", httpClientIndex, oldHttpClient, newHttpClient);
            return newHttpClient;
        }
    }

    protected CloseableHttpClient initRawHttpClient(int httpClientIndex, CloseableHttpClient oldHttpClient) {
        LOG.debug("initRawHttpClient - index={}, oldHttpClient={}", httpClientIndex, oldHttpClient);

        if (oldHttpClient != null) {
            try {
                oldHttpClient.close();
            } catch (IOException e) {
                throw new UncheckedIOException("Exception while closing oldHttpClient=%s, index=%s"
                        .formatted(oldHttpClient, httpClientIndex), e);
            }
        }
        {
            HttpClientBuilder httpClientBuilder = HttpClientBuilder.create();
            CloseableHttpClient newHttpClient = httpClientBuilder.build();
            LOG.trace("initTNet - ok - index={}, oldHttpClient={}, newHttpClient={}", httpClientIndex, oldHttpClient, newHttpClient);
            return newHttpClient;
        }
    }

    @SuppressWarnings("HttpUrlsUsage")
    protected void initProxyServer(String proxyHost, int proxyPort) throws IOException {
        {
            String proxyServerDockerContName = proxyServerDockerContNamePattern.formatted(proxyPort);
            dockerEngineClient.containerRestart(proxyServerDockerContName);
        }
        {
            HttpGet httpGet = new HttpGet("http://%s:%s".formatted(proxyHost, proxyPort));
            int sleepTimeout = 0;
            int nTries = 10;
            for (int i = 1; i <= nTries; i++) {
                int fi = i;
                sleepTimeout += 100;
                try {
                    Thread.sleep(sleepTimeout);
                } catch (InterruptedException e) {
                    LOG.warn("initProxyServer - interrupted while sleeping before readiness check - i={}/{}, proxyHost={}, proxyPort={}",
                            i, nTries, proxyHost, proxyPort);
                    Thread.currentThread().interrupt();
                    break;
                }
                try {
                    proxyProbeHttpClient.execute(httpGet, resp -> {
                        int respCode = resp.getCode();
                        HttpEntity entity = resp.getEntity();
                        String body = entity == null ? null : new String(entity.getContent().readAllBytes(), UTF_8);
                        if (respCode != 501 || body == null || !READINESS_PROBE_BODY_PATTERN.matcher(body).matches()) {
                            throw new IllegalStateException("Proxy server readiness check failed - i=%s/%s, proxyHost=%s, proxyPort=%s, respCode=%s, body=%s"
                                    .formatted(fi, nTries, proxyHost, proxyPort, respCode, body));
                        }
                        return null;
                    });
                    break;
                } catch (NoHttpResponseException | SocketException e) {
                    if (i < nTries) {
                        LOG.debug("initProxyServer - proxy server readiness check failed (retrying..) - proxyHost=%s, proxyPort=%s, i=%s/%s, exception=%s"
                                .formatted(proxyHost, proxyPort, i, nTries, e.getMessage()));
                    } else {
                        LOG.warn("initProxyServer - proxy server readiness check failed - proxyHost=%s, proxyPort=%s, i=%s/%s, exception=%s"
                                .formatted(proxyHost, proxyPort, i, nTries, e.getMessage()));
                        throw e;
                    }
                }
            }
        }
    }

    @Override
    public <REQ_BODY, RESP_BODY> TNetResponse<RESP_BODY> execute(TNetRequest<REQ_BODY, RESP_BODY> req) throws TNetException {
        return execute(req, ResourceReturnPlacement.TAIL);
    }

    protected <REQ_BODY, RESP_BODY> TNetResponse<RESP_BODY> execute(
            TNetRequest<REQ_BODY, RESP_BODY> req,
            ResourceReturnPlacement resourceReturnPlacement
    ) throws TNetException {
        int repeatCount = req.getRepeatCount();
        Set<Integer> toleratedErrStatusCodes = req.getToleratedErrStatusCodes();
        float circuitRestartProbability = req.getCircuitRestartProbability();
        boolean tolerateEmptyRespBody = req.isTolerateEmptyRespBody();
        Set<REQ_BODY> errorRespBodies = req.getErrorRespBodies();

        ClassicHttpRequest httpGet = constructHttpRequest(req);

        ResourcePool<CloseableHttpClient> httpPool = req.isUseT() ? tHttpClientPool : rawHttpClientPool;

        List<TNetException> exceptions = new ArrayList<>();
        for (int i = 1; i <= repeatCount; i++) {
            int fi = i;
            TNetResponse<RESP_BODY> mainResp = null;
            try {
                mainResp = httpPool.execute(resourceReturnPlacement, (httpClientIndex, httpClient, restartNotifier) -> {
                            try {
                                TNetResponse<RESP_BODY> resp = httpClient.execute(httpGet, httpResp -> consumeHttpResponse(req, httpResp));
                                int respCode = resp.getStatusCode();
                                if (respCode >= 400 && respCode <= 599) {
                                    if (!toleratedErrStatusCodes.contains(respCode)) {
                                        throw new TNetException(format("Received error respCode=%s, req=%s, i=%s/%s",
                                                respCode, req, fi, repeatCount), req, resp);
                                    }
                                }
                                if (!tolerateEmptyRespBody) {
                                    if (resp.getBodySize() == 0) {
                                        throw new TNetException(format("Received empty response body respCode=%s, req=%s, i=%s/%s",
                                                respCode, req, fi, repeatCount), req, resp);
                                    }
                                }
                                if (errorRespBodies != null) {
                                    for (REQ_BODY errorRespBody : errorRespBodies) {
                                        RESP_BODY respBody = resp.getBody();
                                        if (Objects.equals(errorRespBody, respBody)) {
                                            throw new TNetException(format("Received error response body respCode=%s, req=%s, i=%s/%s, respBody=%s",
                                                    respCode, req, fi, repeatCount, respBody), req, resp);
                                        }
                                    }
                                }
                                if (circuitRestartProbability >= 0)
                                    if (circuitRestartProbability >= 1) {
                                        restartNotifier.accept(true);
                                    } else if (ThreadLocalRandom.current().nextFloat() < circuitRestartProbability) {
                                        restartNotifier.accept(true);
                                    }
                                return resp;
                            } catch (IOException e) {
                                restartNotifier.accept(true);
                                if (fi < repeatCount - 1) {
                                    LOG.trace("execute - request failed (repeating..) - i={}/{}, req={} - {}, {}", fi, repeatCount, req, e.getClass(), e.getMessage());
                                } else {
                                    LOG.debug("execute - request failed - i={}/{}, req={} - {}, {}", fi, repeatCount, req, e.getClass(), e.getMessage());
                                }
                                if (e instanceof TNetException tNetException) {
                                    exceptions.add(tNetException);
                                } else {
                                    exceptions.add(new TNetException(e.getMessage(), e, req, null));
                                }
                            } catch (Exception e) {
                                restartNotifier.accept(true);
                                LOG.warn("execute - request failed - i={}/{}, req={} - {}, {}", fi, repeatCount, req, e.getClass(), e.getMessage());
                                throw e;
                            }
                            return null;
                        }
                );
            } catch (TimeoutException e) {
                if (fi < repeatCount - 1) {
                    LOG.trace("execute - timeout (repeating..) - i={}/{}, req={} - {}, {}", fi, repeatCount, req, e.getClass(), e.getMessage());
                } else {
                    LOG.debug("execute - timeout - i={}/{}, req={} - {}, {}", fi, repeatCount, req, e.getClass(), e.getMessage());
                }
                exceptions.add(new TNetException("", e, req, null));
            } catch (InterruptedException e) {
                LOG.warn("execute - interrupted - i={}/{}, req={} - {}, {}", fi, repeatCount, req, e.getClass(), e.getMessage());
                exceptions.add(new TNetException("", e, req, null));
            }
            if (mainResp != null) {
                LOG.trace("execute - ok - i={}/{}, req={}", fi, repeatCount, req);
                return mainResp;
            }
        }
        throw ExceptionUtil.getLastExceptionAndSuppressOthers(exceptions);
    }

    @Override
    public boolean healthcheck() throws TNetException {
        long startTimeMillis = System.currentTimeMillis();
        TNetResponse<String> resp = execute(TNetRequest.createGet(URI.create("https://check.torproject.org/api/ip")), ResourceReturnPlacement.HEAD);
        long endTimeMillis = System.currentTimeMillis();
        Duration duration = Duration.ofMillis(endTimeMillis - startTimeMillis);
        int statusCode = resp.getStatusCode();
        String body = resp.getBody();
        boolean isOk = statusCode == 200 && body.contains("\"IsTor\":true");
        LOG.debug("healthcheck - isOk={}, respBody={}, duration={}", isOk, body, duration);
        return isOk;
    }

    protected ClassicHttpRequest constructHttpRequest(TNetRequest<?, ?> req) {
        TNetRequest.Method method = req.getMethod();
        ClassicHttpRequest httpRequest;
        switch (method) {
            case GET -> httpRequest = new HttpGet(req.getUri());
            case POST -> {
                httpRequest = new HttpPost(req.getUri());
                Object body = req.getBody();
                if (body != null) {
                    if (body instanceof String stringBody) {
                        httpRequest.setEntity(new StringEntity(stringBody));
                    } else {
                        throw new UnsupportedOperationException("not yet implemented - body=" + body);
                    }
                }
            }
            default -> throw new IllegalStateException("Unexpected value: " + method);
        }
        for (Map.Entry<String, Collection<Object>> he : req.getHeaders().entrySet()) {
            String headerKey = he.getKey();
            Collection<Object> headerValues = he.getValue();
            for (Object headerValue : headerValues) {
                httpRequest.addHeader(headerKey, headerValue);
            }
        }
        return httpRequest;
    }

    protected <RESP_BODY> TNetResponse<RESP_BODY> consumeHttpResponse(
            TNetRequest<?, RESP_BODY> req, ClassicHttpResponse httpResp
    ) throws IOException {
        Charset respCharset = req.getRespCharset();

        int respCode = httpResp.getCode();
        Class<RESP_BODY> respBodyType = req.getRespBodyType();

        Map<String, List<String>> respHeaders;
        if (req.isExtractRespHeaders()) {
            respHeaders = Arrays.stream(httpResp.getHeaders())
                    .collect(groupingBy(Header::getName, mapping(Header::getValue, toList())));
        } else {
            respHeaders = null;
        }

        TNetResponse<?> resp;
        if (String.class.isAssignableFrom(respBodyType)) {
            String respBody = new String(httpResp.getEntity().getContent().readAllBytes(), respCharset);
            resp = TNetResponse.create(respCode, respBody, respBody.length(), respHeaders);
        } else if (byte[].class.isAssignableFrom(respBodyType)) {
            byte[] respBody = httpResp.getEntity().getContent().readAllBytes();
            resp = TNetResponse.create(respCode, respBody, respBody.length, respHeaders);
        } else {
            throw new UnsupportedOperationException("not yet implemented - respBodyType=" + respBodyType);
        }

        @SuppressWarnings("unchecked")
        TNetResponse<RESP_BODY> typedResp = (TNetResponse<RESP_BODY>) resp;
        return typedResp;

    }

    @Override
    public String toString() {
        return new StringJoiner(", ", TNetImpl.class.getSimpleName() + "@" + Integer.toHexString(hashCode()) + "[", "]")
                .add("socksProxyHost='" + socksProxyHost + "'")
                .add("proxyBasePort=" + proxyBasePort)
                .add("proxyPortOffset=" + proxyPortOffset)
                .add("numHttpClients=" + numHttpClients)
                .add("workerHttpClientPool=" + tHttpClientPool)
                .add("dockerEngineClient=" + dockerEngineClient)
                .add("proxyProbeHttpClient=" + proxyProbeHttpClient)
                .toString();
    }
}
