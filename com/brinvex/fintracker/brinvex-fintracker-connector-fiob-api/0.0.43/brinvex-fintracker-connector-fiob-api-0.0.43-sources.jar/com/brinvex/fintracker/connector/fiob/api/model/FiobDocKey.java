package com.brinvex.fintracker.connector.fiob.api.model;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.Comparator;

import static java.util.Comparator.comparing;

public sealed interface FiobDocKey extends Serializable {

    String accountId();

    record TradingTransDocKey(
            @Override
            String accountId,
            LocalDate fromDateIncl,
            LocalDate toDateIncl
    ) implements FiobDocKey, Comparable<TradingTransDocKey>, Serializable {

        private static final Comparator<TradingTransDocKey> COMPARATOR =
                comparing(TradingTransDocKey::accountId)
                        .thenComparing(TradingTransDocKey::fromDateIncl)
                        .thenComparing(TradingTransDocKey::toDateIncl);

        @Override
        public int compareTo(TradingTransDocKey other) {
            return COMPARATOR.compare(this, other);
        }
    }

}
