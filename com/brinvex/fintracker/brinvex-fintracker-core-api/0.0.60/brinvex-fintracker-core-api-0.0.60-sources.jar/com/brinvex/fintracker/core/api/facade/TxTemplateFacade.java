package com.brinvex.fintracker.core.api.facade;

import java.util.function.Supplier;

public interface TxTemplateFacade {

    <T> T execute(Supplier<T> action);

}
