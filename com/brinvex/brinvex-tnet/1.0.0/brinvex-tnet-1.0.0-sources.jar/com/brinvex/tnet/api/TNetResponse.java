package com.brinvex.tnet.api;

import java.io.Serializable;
import java.util.List;
import java.util.Map;
import java.util.StringJoiner;

public class TNetResponse<BODY> implements Serializable {

    private final int statusCode;

    private final BODY body;

    private final int bodySize;

    private final Map<String, List<String>> respHeaders;

    public static TNetResponse<String> create(
            int statusCode,
            String body,
            int bodySize,
            Map<String, List<String>> respHeaders
    ) {
        return new TNetResponse<>(statusCode, body, bodySize, respHeaders);
    }

    public static TNetResponse<byte[]> create(
            int statusCode,
            byte[] body,
            int bodySize,
            Map<String, List<String>> respHeaders
    ) {
        return new TNetResponse<>(statusCode, body, bodySize, respHeaders);
    }

    protected TNetResponse(int statusCode, BODY body, int bodySize, Map<String, List<String>> respHeaders) {
        this.statusCode = statusCode;
        this.body = body;
        this.bodySize = bodySize;
        this.respHeaders = respHeaders;
    }

    public int getStatusCode() {
        return statusCode;
    }

    public BODY getBody() {
        return body;
    }

    public int getBodySize() {
        return bodySize;
    }

    public Map<String, List<String>> getRespHeaders() {
        return respHeaders;
    }

    @Override
    public String toString() {
        return new StringJoiner(", ", TNetResponse.class.getSimpleName() + "[", "]")
                .add("statusCode=" + statusCode)
                .add("bodySize=" + bodySize)
                .add("respHeaders=" + respHeaders)
                .add("body=" + body)
                .toString();
    }
}
