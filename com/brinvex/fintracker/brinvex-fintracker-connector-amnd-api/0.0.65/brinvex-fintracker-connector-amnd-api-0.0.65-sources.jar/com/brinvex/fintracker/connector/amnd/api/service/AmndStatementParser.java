package com.brinvex.fintracker.connector.amnd.api.service;

import com.brinvex.fintracker.connector.amnd.api.model.statement.TransactionStatement;

public interface AmndStatementParser {

    TransactionStatement parseTrades(byte[] statementPdfContent);
}
