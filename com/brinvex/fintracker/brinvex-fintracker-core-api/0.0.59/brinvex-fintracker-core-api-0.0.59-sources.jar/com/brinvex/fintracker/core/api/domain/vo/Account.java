package com.brinvex.fintracker.core.api.domain.vo;

import com.brinvex.fintracker.core.api.domain.enu.Currency;

import java.time.LocalDate;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.StringJoiner;

import static java.util.Collections.unmodifiableMap;
import static java.util.Objects.requireNonNullElse;
import static java.util.Optional.ofNullable;
import static java.util.function.Predicate.not;

public record Account(
        String id,
        String name,
        String type,
        Currency ccy,
        LocalDate openDate,
        LocalDate closeDate,
        String credentials,
        Map<String, String> extraProps
) {
    public Account {
        if (id == null) {
            throw new IllegalArgumentException("id must not be null");
        }
        if (name != null && name.isBlank()) {
            throw new IllegalArgumentException("name must not be blank");
        }
        if (type != null && type.isBlank()) {
            throw new IllegalArgumentException("type must not be blank");
        }
        if (ccy == null) {
            throw new IllegalArgumentException("ccy must not be null");
        }
        if (openDate == null) {
            throw new IllegalArgumentException("openDate must not be null");
        }
        if (closeDate != null && !openDate.isBefore(closeDate)) {
            throw new IllegalArgumentException("openDate must be before closeDate, given: %s, %s".formatted(openDate, closeDate));
        }
        if (credentials != null && credentials.isBlank()) {
            throw new IllegalArgumentException("credentials must not be blank");
        }
        extraProps = extraProps == null ? Map.of() : Map.copyOf(extraProps);
    }

    @Override
    public String toString() {
        return new StringJoiner(", ", Account.class.getSimpleName() + "[", "]")
                .add("id=" + id)
                .add("name=" + name)
                .add("type=" + type)
                .add("ccy=" + ccy)
                .add("openDate=" + openDate)
                .add("closeDate=" + closeDate)
                .add("credentials=***")
                .add("extraProps=" + extraProps)
                .toString();
    }

    public static Account of(Map<String, String> props) {
        props = new LinkedHashMap<>(props);

        String id = props.remove("id");
        if (id == null || id.isEmpty()) {
            return null;
        }
        String name = ofNullable(props.remove("name")).filter(not(String::isBlank)).orElse(null);
        String type = ofNullable(props.remove("type")).filter(not(String::isBlank)).orElse(null);
        Currency ccy = ofNullable(props.remove("ccy")).filter(not(String::isBlank)).map(Currency::valueOf).orElse(null);
        LocalDate openDate = ofNullable(props.remove("openDate")).filter(not(String::isBlank)).map(LocalDate::parse).orElse(null);
        LocalDate closeDate = ofNullable(props.remove("closeDate")).filter(not(String::isBlank)).map(LocalDate::parse).orElse(null);
        String credentials = ofNullable(props.remove("credentials")).filter(not(String::isBlank)).orElse(null);

        return new Account(
                id,
                name,
                type,
                ccy,
                openDate,
                closeDate,
                credentials,
                props
        );
    }

    public Map<String, String> toProps() {
        LinkedHashMap<String, String> props = new LinkedHashMap<>(extraProps);
        props.put("id", id);
        props.put("name", name);
        props.put("type", type);
        props.put("ccy", ccy.name());
        props.put("openDate", requireNonNullElse(openDate, "").toString());
        props.put("closeDate", requireNonNullElse(closeDate, "").toString());
        props.put("credentials", requireNonNullElse(credentials, ""));
        extraProps.forEach(props::putIfAbsent);
        return unmodifiableMap(props);
    }

    public Account withExtraProp(String key, String value) {
        LinkedHashMap<String, String> modifiedExtraProps = new LinkedHashMap<>(extraProps);
        if (value == null) {
            modifiedExtraProps.remove(key);
        } else {
            modifiedExtraProps.put(key, value);
        }
        return new Account(id, name, type, ccy, openDate, closeDate, credentials, modifiedExtraProps);
    }
}
