package com.brinvex.util.tnet.impl;

import com.brinvex.util.tnet.api.TNetException;

import java.time.Duration;

public class TNetBuilder {

    private int poolSize = 2;
    private String socksProxyHost = "127.0.0.1";
    private int socksProxyBasePort = 9050;
    private int socksProxyPortOffset = 1;
    private Duration pollTimeout = Duration.ofSeconds(60);
    private String dockerEngineAddress = "http://127.0.0.1:2375";
    private String proxyServerDockerContNamePattern = null;
    private boolean healthcheckAtStartup = true;

    public TNetBuilder setPoolSize(int poolSize) {
        this.poolSize = poolSize;
        return this;
    }

    public TNetBuilder setSocksProxyBasePort(int socksProxyBasePort) {
        this.socksProxyBasePort = socksProxyBasePort;
        return this;
    }

    public TNetBuilder setDockerEngineAddress(String dockerEngineAddress) {
        this.dockerEngineAddress = dockerEngineAddress;
        return this;
    }

    public TNetBuilder setSocksProxyHost(String socksProxyHost) {
        this.socksProxyHost = socksProxyHost;
        return this;
    }

    public TNetBuilder setSocksProxyPortOffset(int socksProxyPortOffset) {
        this.socksProxyPortOffset = socksProxyPortOffset;
        return this;
    }

    public TNetBuilder setPollTimeout(Duration pollTimeout) {
        this.pollTimeout = pollTimeout;
        return this;
    }

    public TNetBuilder setProxyServerDockerContNamePattern(String proxyServerDockerContNamePattern) {
        this.proxyServerDockerContNamePattern = proxyServerDockerContNamePattern;
        return this;
    }

    public TNetBuilder setHealthcheckAtStartup(boolean healthcheckAtStartup) {
        this.healthcheckAtStartup = healthcheckAtStartup;
        return this;
    }

    public TNetImpl build() throws TNetException {
        return new TNetImpl(
                poolSize,
                dockerEngineAddress,
                socksProxyHost,
                socksProxyBasePort,
                socksProxyPortOffset,
                pollTimeout,
                proxyServerDockerContNamePattern,
                healthcheckAtStartup
        );
    }
}