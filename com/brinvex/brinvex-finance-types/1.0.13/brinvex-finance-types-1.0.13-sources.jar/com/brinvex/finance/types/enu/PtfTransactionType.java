package com.brinvex.finance.types.enu;

public enum PtfTransactionType {

    DEPOSIT,

    WITHDRAWAL,

    BUY,

    SELL,

    FX_BUY,

    FX_SELL,

    DIVIDEND,

    INTEREST,

    FEE,

    TAX,

    TRANSFORMATION,

    OTHER_INTERNAL_FLOW;

}
