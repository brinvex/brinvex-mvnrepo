package com.brinvex.fintracker.core.api;

import com.brinvex.fintracker.core.api.service.PtfService;

public interface CoreModule extends FinTrackerModule {

    PtfService ptfService();
}
