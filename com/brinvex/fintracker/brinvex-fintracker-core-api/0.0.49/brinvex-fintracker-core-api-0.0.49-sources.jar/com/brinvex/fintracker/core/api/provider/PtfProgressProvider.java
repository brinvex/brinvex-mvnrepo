package com.brinvex.fintracker.core.api.provider;

import com.brinvex.fintracker.core.api.model.domain.PtfProgress;

import java.time.Duration;
import java.time.LocalDate;
import java.util.Map;

public interface PtfProgressProvider extends Provider<PtfProgressProvider.PtfProgressReq, PtfProgress> {

    /**
     * @param ptfProgressProvider
     * @param ptfProps
     * @param fromDateIncl
     * @param toDateIncl
     * @param staleTolerance
     */
    record PtfProgressReq(
            String ptfProgressProvider,
            Map<String, String> ptfProps,
            LocalDate fromDateIncl,
            LocalDate toDateIncl,
            Duration staleTolerance
    ) {
    }

}
