package com.brinvex.util.ibkr.api.model;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Comparator;

public sealed interface DocKey extends Serializable {

    String accountId();

    record ActivityDocKey(
            @Override
            String accountId,
            LocalDate fromDayIncl,
            LocalDate toDayIncl
    ) implements DocKey, Comparable<ActivityDocKey>, Serializable {

        private static final Comparator<ActivityDocKey> COMPARATOR =
                Comparator.comparing(ActivityDocKey::accountId)
                        .thenComparing(ActivityDocKey::fromDayIncl)
                        .thenComparing(ActivityDocKey::toDayIncl);

        public ActivityDocKey {
            if (accountId == null || accountId.isEmpty()) {
                throw new IllegalArgumentException("accountId cannot be null or empty");
            }
            if (fromDayIncl == null) {
                throw new IllegalArgumentException("fromDayIncl cannot be null");
            }
            if (toDayIncl == null) {
                throw new IllegalArgumentException("toDayIncl cannot be null");
            }
            if (fromDayIncl.isAfter(toDayIncl)) {
                throw new IllegalArgumentException("fromDayIncl cannot be after toDayIncl");
            }
        }

        @Override
        public int compareTo(ActivityDocKey other) {
            return COMPARATOR.compare(this, other);
        }
    }

    record TradeConfirmDocKey(
            @Override
            String accountId,
            LocalDate day,
            LocalTime whenGenerated
    ) implements DocKey, Comparable<TradeConfirmDocKey>, Serializable {

        private static final Comparator<TradeConfirmDocKey> COMPARATOR =
                Comparator.comparing(TradeConfirmDocKey::accountId)
                        .thenComparing(TradeConfirmDocKey::day)
                        .thenComparing(TradeConfirmDocKey::whenGenerated);

        public TradeConfirmDocKey {
            if (accountId == null || accountId.isEmpty()) {
                throw new IllegalArgumentException("accountId cannot be null or empty");
            }
            if (day == null) {
                throw new IllegalArgumentException("day cannot be null");
            }
            if (whenGenerated == null) {
                throw new IllegalArgumentException("whenGenerated cannot be null");
            }
        }

        @Override
        public int compareTo(TradeConfirmDocKey other) {
            return COMPARATOR.compare(this, other);
        }
    }
}
