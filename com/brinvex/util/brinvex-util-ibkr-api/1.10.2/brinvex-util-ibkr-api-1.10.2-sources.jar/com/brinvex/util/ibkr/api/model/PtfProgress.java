package com.brinvex.util.ibkr.api.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.SequencedMap;

public record PtfProgress(
        List<FinTransaction> transactions,
        SequencedMap<LocalDate, BigDecimal> netAssetValues
) implements Serializable {
}
