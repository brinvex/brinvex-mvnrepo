package com.brinvex.finance.types.vo;

import com.brinvex.finance.types.enu.Currency;

/**
 * Currency pair BASE/QUOTE reveals how much of the QUOTE currency is needed to buy one unit of the BASE currency.
 * <br/> Example:
 * <br/> EUR/USD = 1.15
 * <br/> EUR is the base currency (sometimes referred as a transaction currency)
 * <br/> USD is the quote currency (sometimes referred as a settlement currency)
 * <br/> If one wants to buy 1 EUR, it will cost him 1.15 USD.
 */
public record CurrencyPair(
        Currency baseCcy,
        Currency quoteCcy
) {

    public static String format(Currency baseCcy, Currency quoteCcy) {
        return "%s/%s".formatted(baseCcy, quoteCcy);
    }

    public static CurrencyPair of(String s) {
        if (s.charAt(3) == '/') {
            String baseCcyStr = s.substring(0, 3);
            String quoteCcyStr = s.substring(4);
            Currency baseCcy = Currency.valueOf(baseCcyStr);
            Currency quoteCcy = Currency.valueOf(quoteCcyStr);
            return new CurrencyPair(baseCcy, quoteCcy);
        }
        throw new IllegalArgumentException("Unexpected: " + s);
    }

    @Override
    public String toString() {
        return format(baseCcy, quoteCcy);
    }
}
