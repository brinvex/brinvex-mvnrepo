package com.brinvex.fintypes.vo;

import java.math.BigDecimal;

import static java.util.Objects.requireNonNull;

public record AddendumAndTotal(BigDecimal addendum, BigDecimal total) {

    public AddendumAndTotal {
        requireNonNull(addendum);
        requireNonNull(total);
    }

    @Override
    public String toString() {
        return "AddendumAndTotal{%s,%s}".formatted(addendum, total);
    }
}
