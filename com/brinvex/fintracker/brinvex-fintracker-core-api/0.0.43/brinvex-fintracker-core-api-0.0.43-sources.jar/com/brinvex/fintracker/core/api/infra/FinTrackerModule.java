package com.brinvex.fintracker.core.api.infra;

import java.util.function.Function;

public interface FinTrackerModule {

    interface PropKey {
        Function<Class<?>, String> customService = serviceType -> "customService.%s".formatted(serviceType.getSimpleName());
        String dmsWorkspace = "dmsWorkspace";
    }

    FinTrackerSupport support();
}
