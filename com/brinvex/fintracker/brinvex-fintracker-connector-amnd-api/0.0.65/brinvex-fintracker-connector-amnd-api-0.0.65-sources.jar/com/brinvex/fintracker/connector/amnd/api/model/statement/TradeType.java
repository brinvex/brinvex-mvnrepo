package com.brinvex.fintracker.connector.amnd.api.model.statement;

public enum TradeType {

    BUY,

    SELL,

}
