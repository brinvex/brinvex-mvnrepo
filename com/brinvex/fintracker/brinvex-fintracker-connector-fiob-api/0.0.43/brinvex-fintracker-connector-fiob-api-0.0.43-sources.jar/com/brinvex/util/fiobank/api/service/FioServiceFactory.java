package com.brinvex.util.fiobank.api.service;

import java.util.ServiceLoader;

/**
 * A factory for {@link FioBrokerService} and {@link FioBankService} based on Java SPI.
 */
public enum FioServiceFactory {

    INSTANCE;

    private FioBrokerService brokerService;

    private FioBankService bankService;

    public FioBrokerService getBrokerService() {
        if (brokerService == null) {
            ServiceLoader<FioBrokerService> loader = ServiceLoader.load(FioBrokerService.class);
            for (FioBrokerService provider : loader) {
                this.brokerService = provider;
                break;
            }
        }
        if (brokerService == null) {
            throw new IllegalStateException(String.format("Not found any implementation of '%s'", FioBrokerService.class));
        }
        return brokerService;
    }

    public FioBankService getBankService() {
        if (bankService == null) {
            ServiceLoader<FioBankService> loader = ServiceLoader.load(FioBankService.class);
            for (FioBankService provider : loader) {
                this.bankService = provider;
                break;
            }
        }
        if (bankService == null) {
            throw new IllegalStateException(String.format("Not found any implementation of '%s'", FioBankService.class));
        }
        return bankService;
    }
}
