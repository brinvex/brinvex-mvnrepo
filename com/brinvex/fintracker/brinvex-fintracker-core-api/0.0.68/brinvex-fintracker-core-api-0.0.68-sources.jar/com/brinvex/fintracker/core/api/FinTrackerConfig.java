package com.brinvex.fintracker.core.api;

import com.brinvex.fintracker.core.api.facade.CacheFactory;
import com.brinvex.fintracker.core.api.facade.JsonMapperFacade;
import com.brinvex.fintracker.core.api.facade.PdfReaderFacade;
import com.brinvex.fintracker.core.api.facade.TxTemplateFactory;
import com.brinvex.dms.api.DmsFactory;
import jakarta.persistence.EntityManager;
import jakarta.validation.Validator;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.function.BiFunction;
import java.util.function.Supplier;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


/// ###### Property Naming Convention
/// ```
/// fintracker.core.abc=value1
/// fintracker.ibkr.x.y.z1=value2
///```
/// - *FULL_PROP_KEY*
///   The complete property key including the application prefix.
///   Example: `fintracker.core.abc`, `fintracker.ibkr.x.y.z1`
///
/// - *COMPACT_PROP_KEY*
///   The property key without the application prefix.
///   Example: `core.key1`, `ibkr.x.y.z1`
///
/// - *MODULE_PROP_KEY_PART*
///   The part of the key that identifies the module, represented as its compact name {@link FinTrackerModule#compactName(Class)}.
///   Example: `core`, `ibkr`
///
/// - *MAIN_KEY*
///   The primary name of the property.
///   Example: `key1`, `x.y.z1`
public final class FinTrackerConfig {

    public static final String FULL_PROP_KEY_PREFIX = "fintracker.";

    private static final Pattern FULL_PROP_KEY_PATTERN = Pattern.compile("fintracker\\.(?<Module>[a-z]\\w+)\\.(?<MainKey>[\\w.]+)");

    private static final BiFunction<String, String, String> COMPACT_PROP_KEY_FORMATTER = "%s.%s"::formatted;

    public static final BiFunction<Class<? extends FinTrackerModule>, String, String> FULL_PROP_KEY_FORMATTER =
            (moduleType, key) -> "fintracker.%s.%s".formatted(FinTrackerModule.compactName(moduleType), key);

    private final Map<String, String> properties;

    private final Supplier<CacheFactory> cacheFactory;
    private final Supplier<DmsFactory> dmsFactory;
    private final Supplier<EntityManager> entityManager;
    private final Supplier<JsonMapperFacade> jsonMapper;
    private final Supplier<PdfReaderFacade> pdfReader;
    private final Supplier<TxTemplateFactory> txTemplateFactory;
    private final Supplier<Validator> validator;

    private FinTrackerConfig(
            Map<String, String> properties,
            Supplier<CacheFactory> cacheFactory,
            Supplier<DmsFactory> dmsFactory,
            Supplier<EntityManager> entityManager,
            Supplier<JsonMapperFacade> jsonMapper,
            Supplier<PdfReaderFacade> pdfReader,
            Supplier<TxTemplateFactory> txTemplateFactory,
            Supplier<Validator> validator
    ) {
        this.properties = Map.copyOf(properties);
        this.cacheFactory = cacheFactory;
        this.dmsFactory = dmsFactory;
        this.entityManager = entityManager;
        this.jsonMapper = jsonMapper;
        this.pdfReader = pdfReader;
        this.txTemplateFactory = txTemplateFactory;
        this.validator = validator;
    }

    public static FinTrackerConfigBuilder builder() {
        return new FinTrackerConfigBuilder();
    }

    public String getProperty(String moduleCompactName, String mainKey, String defaultValue) {
        return properties.getOrDefault(COMPACT_PROP_KEY_FORMATTER.apply(moduleCompactName, mainKey), defaultValue);
    }

    public Supplier<CacheFactory> cacheFactory() {
        return cacheFactory;
    }

    public Supplier<DmsFactory> dmsFactory() {
        return dmsFactory;
    }

    public Supplier<EntityManager> entityManager() {
        return entityManager;
    }

    public Supplier<JsonMapperFacade> jsonMapper() {
        return jsonMapper;
    }

    public Supplier<PdfReaderFacade> pdfReader() {
        return pdfReader;
    }

    public Supplier<TxTemplateFactory> txTemplateFactory() {
        return txTemplateFactory;
    }

    public Supplier<Validator> validator() {
        return validator;
    }

    @SuppressWarnings("UnusedReturnValue")
    public static class FinTrackerConfigBuilder {

        private final Map<String, String> properties = new LinkedHashMap<>();
        private Supplier<CacheFactory> cacheFactory;
        private Supplier<DmsFactory> dmsFactory;
        private Supplier<EntityManager> entityManager;
        private Supplier<JsonMapperFacade> jsonMapper;
        private Supplier<PdfReaderFacade> pdfReader;
        private Supplier<TxTemplateFactory> txTemplateFactory;
        private Supplier<Validator> validator;

        private FinTrackerConfigBuilder() {
        }

        public FinTrackerConfig build() {
            return new FinTrackerConfig(
                    properties,
                    cacheFactory,
                    dmsFactory,
                    entityManager,
                    jsonMapper,
                    pdfReader,
                    txTemplateFactory,
                    validator
            );
        }

        public FinTrackerConfigBuilder setProperties(Map<String, String> fullKeyProperties) {
            for (Map.Entry<String, String> e : fullKeyProperties.entrySet()) {
                setProperty(e.getKey(), e.getValue());
            }
            return this;
        }

        public FinTrackerConfigBuilder setProperty(String fullKey, String value) {
            Matcher m = FULL_PROP_KEY_PATTERN.matcher(fullKey);
            if (m.matches()) {
                setProperty(m.group("Module"), m.group("MainKey"), value);
            } else {
                throw new IllegalArgumentException("Invalid property key: '%s'".formatted(fullKey));
            }
            return this;
        }

        public FinTrackerConfigBuilder setProperty(Class<? extends FinTrackerModule> moduleType, String mainKey, String value) {
            return setProperty(FinTrackerModule.compactName(moduleType), mainKey, value);
        }

        private FinTrackerConfigBuilder setProperty(String moduleKeyPart, String mainKey, String value) {
            if (propKeyIsInvalid(mainKey)) {
                throw new IllegalArgumentException("Invalid property mainKey: '%s'".formatted(mainKey));
            }
            properties.put(COMPACT_PROP_KEY_FORMATTER.apply(moduleKeyPart, mainKey), value);
            return this;
        }

        private boolean propKeyIsInvalid(String key) {
            return key == null
                   || key.isBlank()
                   || key.charAt(0) == '.'
                   || key.charAt(key.length() - 1) == '.'
                   || !key.trim().equals(key);
        }

        public FinTrackerConfigBuilder cacheFactory(Supplier<CacheFactory> cacheFactory) {
            this.cacheFactory = cacheFactory;
            return this;
        }

        public FinTrackerConfigBuilder dmsFactory(Supplier<DmsFactory> dmsFactory) {
            this.dmsFactory = dmsFactory;
            return this;
        }

        public FinTrackerConfigBuilder entityManager(Supplier<EntityManager> entityManager) {
            this.entityManager = entityManager;
            return this;
        }

        public FinTrackerConfigBuilder jsonMapper(Supplier<JsonMapperFacade> jsonMapper) {
            this.jsonMapper = jsonMapper;
            return this;
        }

        public FinTrackerConfigBuilder pdfReader(Supplier<PdfReaderFacade> pdfReader) {
            this.pdfReader = pdfReader;
            return this;
        }

        public FinTrackerConfigBuilder txTemplateFactory(Supplier<TxTemplateFactory> txTemplateFactory) {
            this.txTemplateFactory = txTemplateFactory;
            return this;
        }

        public FinTrackerConfigBuilder validator(Supplier<Validator> validator) {
            this.validator = validator;
            return this;
        }
    }
}
