package com.brinvex.finance.types.enu;

public enum InflationRateType {

    /// EU - Harmonised Index of Consumer Prices
    ///
    /// <a href="https://data.ecb.europa.eu/data/datasets/ICP/ICP.M.U2.N.000000.4.INX">https://data.ecb.europa.eu/data/datasets/ICP/ICP.M.U2.N.000000.4.INX</a>
    ///
    /// Time series dimensions:
    /// - Frequency - Monthly \[M\]
    /// - Reference area - Euro area (changing composition) \[U2\]
    /// - Adjustment indicator - Neither seasonally nor working day adjusted \[N\]
    /// - Classification - ICP context - HICP - Overall index \[000000\]
    /// - Institution originating the data flow - Eurostat \[4\]
    /// - Series variation - ICP context - Index \[INX\]
    EU_HICP,

}
