package com.brinvex.fintracker.connector.fiob.api.model.statement;

import lombok.Builder;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Builder
public record TradingTransaction(
        LocalDateTime tradeDate,
        TradingTransactionDirection direction,
        String symbol,
        String rawSymbol,
        BigDecimal price,
        BigDecimal shares,
        String ccy,
        BigDecimal volumeCzk,
        BigDecimal feesCzk,
        BigDecimal volumeUsd,
        BigDecimal feesUsd,
        BigDecimal volumeEur,
        BigDecimal feesEur,
        String market,
        String instrumentName,
        LocalDate settleDate,
        String status,
        String orderId,
        String text,
        String userComments,
        int rowNumberOverStatementLine,
        int statementLineHash
) {

}