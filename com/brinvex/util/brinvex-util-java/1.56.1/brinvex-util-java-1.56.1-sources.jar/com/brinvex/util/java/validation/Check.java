package com.brinvex.util.java.validation;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.function.Supplier;
import java.util.regex.Pattern;

import static java.math.BigDecimal.ZERO;

/**
 * <ul>
 *   <li>{@code Check} - If the condition is satisfied, returns {@code null}; otherwise, returns a message describing the condition violation.</li>
 *   <li>{@code Assert} - If the condition is satisfied, does nothing; otherwise, throws an {@code IllegalStateException} with a message describing the condition violation.</li>
 *   <li>{@code Validate} - If the condition is satisfied, does nothing; otherwise, throws an {@code IllegalArgumentException} with a message describing the condition violation.</li>
 * </ul>
 */
@SuppressWarnings({"SameParameterValue", "unused"})
public class Check {

    private static String format(Object o) {
        return (o instanceof String ? "'%s'" : "%s").formatted(o);
    }

    private static String nullSafeGet(Supplier<String> msgSupplier) {
        return msgSupplier == null ? null : msgSupplier.get();
    }

    /********************************************************************
     * BOOLEAN
     ********************************************************************/

    public static String isTrue(boolean expression) {
        return isTrue(expression, () -> "The validated expression is false");
    }

    public static String isTrue(boolean expression, Supplier<String> msg) {
        if (!expression) {
            return nullSafeGet(msg);
        }
        return null;
    }

    public static String isFalse(boolean expression) {
        return isFalse(expression, () -> "The validated expression is true");
    }

    public static String isFalse(boolean expression, Supplier<String> msg) {
        if (expression) {
            return nullSafeGet(msg);
        }
        return null;
    }

    /********************************************************************
     * OBJECT
     ********************************************************************/

    public static String notNull(Object input) {
        if (input == null) {
            return "Object is null";
        }
        return null;
    }

    public static String notNull(Object input, Supplier<String> msg) {
        if (input == null) {
            return nullSafeGet(msg);
        }
        return null;
    }

    public static String isNull(Object input) {
        return isNull(input, () -> "Object is not null: %s".formatted(format(input)));
    }

    public static String isNull(Object input, Supplier<String> msg) {
        if (input != null) {
            return nullSafeGet(msg);
        }
        return null;
    }

    public static String equal(Object input1, Object input2) {
        return equal(input1, input2, () -> "The object %s is not equal to the object %s, or some of them are null".formatted(format(input1), format(input2)));
    }

    public static String equal(Object input1, Object input2, Supplier<String> msg) {
        String m1 = notNull(input1, msg);
        if (m1 != null) {
            return m1;
        }
        String m2 = notNull(input2, msg);
        if (m2 != null) {
            return m2;
        }
        if (!input1.equals(input2)) {
            return nullSafeGet(msg);
        }
        return null;
    }

    /********************************************************************
     * STRING
     ********************************************************************/

    public static String blank(String input) {
        return blank(input, () -> "The string is either null or not blank: %s".formatted(format(input)));
    }

    public static String blank(String input, Supplier<String> msg) {
        String m1 = notNull(input, msg);
        if (m1 != null) {
            return m1;
        }
        if (!input.isBlank()) {
            return nullSafeGet(msg);
        }
        return null;
    }

    public static String empty(String input) {
        return empty(input, () -> "The string is either null or not empty: %s".formatted(format(input)));
    }

    public static String empty(String input, Supplier<String> msg) {
        String m1 = notNull(input, msg);
        if (m1 != null) {
            return m1;
        }
        if (!input.isEmpty()) {
            return nullSafeGet(msg);
        }
        return null;
    }

    public static String contains(String haystack, String needle) {
        return contains(haystack, needle, () -> "The haystack %s does not contain the needle %s, or some of them are null.".formatted(format(haystack), format(needle)));
    }

    public static String contains(String haystack, String needle, Supplier<String> msg) {
        String m1 = notNull(haystack, msg);
        if (m1 != null) {
            return m1;
        }
        String m2 = notNull(needle, msg);
        if (m2 != null) {
            return m2;
        }
        if (!haystack.contains(needle)) {
            return nullSafeGet(msg);
        }
        return null;
    }

    public static String notNullNotBlank(String input) {
        return notNullNotBlank(input, () -> "The string is either null or blank: %s".formatted(format(input)));
    }

    public static String notNullNotBlank(String input, Supplier<String> msg) {
        String m1 = notNull(input, msg);
        if (m1 != null) {
            return m1;
        }
        if (input.isBlank()) {
            return nullSafeGet(msg);
        }
        return null;
    }

    public static String nullOrNotBlank(String input) {
        return nullOrNotBlank(input, () -> "The string is blank: %s".formatted(format(input)));
    }

    public static String nullOrNotBlank(String input, Supplier<String> msg) {
        if (input != null && input.isBlank()) {
            return nullSafeGet(msg);
        }
        return null;
    }

    /********************************************************************
     * NUMBER
     ********************************************************************/

    public static String zero(BigDecimal number) {
        return zero(number, () -> "The number is either null or not zero: %s".formatted(number));
    }

    public static String zero(BigDecimal number, Supplier<String> msg) {
        String m1 = notNull(number, msg);
        if (m1 != null) {
            return m1;
        }
        if (number.compareTo(ZERO) != 0) {
            return nullSafeGet(msg);
        }
        return null;
    }

    public static String nullOrZero(BigDecimal number) {
        return nullOrZero(number, () -> "The number is not zero: %s".formatted(number));
    }

    public static String nullOrZero(BigDecimal number, Supplier<String> msg) {
        if (number != null && number.compareTo(ZERO) != 0) {
            return nullSafeGet(msg);
        }
        return null;
    }

    public static String positive(BigDecimal number) {
        return positive(number, () -> "The number is either null or not positive: %s".formatted(number));
    }

    public static String positive(BigDecimal number, Supplier<String> msg) {
        String m1 = notNull(number, msg);
        if (m1 != null) {
            return m1;
        }
        if (number.compareTo(ZERO) <= 0) {
            return nullSafeGet(msg);
        }
        return null;
    }

    public static String nullOrPositive(BigDecimal number) {
        return nullOrPositive(number, () -> "The number is not positive: %s".formatted(number));
    }

    public static String nullOrPositive(BigDecimal number, Supplier<String> msg) {
        if (number != null && number.compareTo(ZERO) <= 0) {
            return nullSafeGet(msg);
        }
        return null;
    }

    public static String negative(BigDecimal number) {
        return negative(number, () -> "The number is either null or not negative: %s".formatted(number));
    }

    public static String negative(BigDecimal number, Supplier<String> msg) {
        String m1 = notNull(number, msg);
        if (m1 != null) {
            return m1;
        }
        if (number.compareTo(ZERO) >= 0) {
            return nullSafeGet(msg);
        }
        return null;
    }

    public static String nullOrNegative(BigDecimal number) {
        return nullOrNegative(number, () -> "The number is not negative: %s".formatted(number));
    }

    public static String nullOrNegative(BigDecimal number, Supplier<String> msg) {
        if (number != null && number.compareTo(ZERO) >= 0) {
            return nullSafeGet(msg);
        }
        return null;
    }

    public static String equal(BigDecimal number1, BigDecimal number2) {
        return equal(number1, number2, () -> "The number %s is not equal to the number %s, or some of them are null".formatted(number1, number2));
    }

    public static String equal(BigDecimal number1, BigDecimal number2, Supplier<String> msg) {
        String m1 = notNull(number1, msg);
        if (m1 != null) {
            return m1;
        }
        String m2 = notNull(number2, msg);
        if (m2 != null) {
            return m2;
        }
        if (number1.compareTo(number2) != 0) {
            return nullSafeGet(msg);
        }
        return null;
    }

    public static String greaterThan(BigDecimal number1, BigDecimal number2) {
        return equal(number1, number2, () -> "The number %s is not greater than the number %s, or some of them are null".formatted(number1, number2));
    }

    public static String greaterThan(BigDecimal number1, BigDecimal number2, Supplier<String> msg) {
        String m1 = notNull(number1, msg);
        if (m1 != null) {
            return m1;
        }
        String m2 = notNull(number2, msg);
        if (m2 != null) {
            return m2;
        }
        if (number1.compareTo(number2) <= 0) {
            return nullSafeGet(msg);
        }
        return null;
    }

    public static String equalOrGreaterThan(BigDecimal number1, BigDecimal number2) {
        return equal(number1, number2, () -> "The number %s is neither equal to nor greater than %s, or some of them are null".formatted(number1, number2));
    }

    public static String equalOrGreaterThan(BigDecimal number1, BigDecimal number2, Supplier<String> msg) {
        String m1 = notNull(number1, msg);
        if (m1 != null) {
            return m1;
        }
        String m2 = notNull(number2, msg);
        if (m2 != null) {
            return m2;
        }
        if (number1.compareTo(number2) < 0) {
            return nullSafeGet(msg);
        }
        return null;
    }

    public static String lessThan(BigDecimal number1, BigDecimal number2) {
        return equal(number1, number2, () -> "The number %s is not less than the number %s, or some of them are null".formatted(number1, number2));
    }

    public static String lessThan(BigDecimal number1, BigDecimal number2, Supplier<String> msg) {
        String m1 = notNull(number1, msg);
        if (m1 != null) {
            return m1;
        }
        String m2 = notNull(number2, msg);
        if (m2 != null) {
            return m2;
        }
        if (number1.compareTo(number2) >= 0) {
            return nullSafeGet(msg);
        }
        return null;
    }

    public static String equalOrLessThan(BigDecimal number1, BigDecimal number2) {
        return equal(number1, number2, () -> "The number %s is neither equal to nor less than %s, or some of them are null".formatted(number1, number2));
    }

    public static String equalOrLessThan(BigDecimal number1, BigDecimal number2, Supplier<String> msg) {
        String m1 = notNull(number1, msg);
        if (m1 != null) {
            return m1;
        }
        String m2 = notNull(number2, msg);
        if (m2 != null) {
            return m2;
        }
        if (number1.compareTo(number2) > 0) {
            return nullSafeGet(msg);
        }
        return null;
    }

    public static String opposite(BigDecimal number1, BigDecimal number2) {
        return opposite(number1, number2, () -> "The number %s is not opposite to the number %s, or some of them are null".formatted(number1, number2));
    }

    public static String opposite(BigDecimal number1, BigDecimal number2, Supplier<String> msg) {
        String m1 = notNull(number1, msg);
        if (m1 != null) {
            return m1;
        }
        String m2 = notNull(number2, msg);
        if (m2 != null) {
            return m2;
        }
        if (number1.compareTo(number2.negate()) != 0) {
            return nullSafeGet(msg);
        }
        return null;
    }

    /********************************************************************
     * DATE
     ********************************************************************/

    public static String before(LocalDate leftDate, LocalDate rightDate) {
        return before(leftDate, rightDate, () -> "The date %s is not before the date %s, or some of them are null".formatted(leftDate, rightDate));
    }

    public static String before(LocalDate leftDate, LocalDate rightDate, Supplier<String> msg) {
        String m1 = notNull(leftDate, msg);
        if (m1 != null) {
            return m1;
        }
        String m2 = notNull(rightDate, msg);
        if (m2 != null) {
            return m2;
        }
        if (!leftDate.isBefore(rightDate)) {
            return nullSafeGet(msg);
        }
        return null;
    }

    public static String equalOrAfter(LocalDate leftDate, LocalDate rightDate) {
        return before(leftDate, rightDate, () -> "The date %s is before the date %s, or some of them are null".formatted(leftDate, rightDate));
    }

    public static String equalOrAfter(LocalDate leftDate, LocalDate rightDate, Supplier<String> msg) {
        String m1 = notNull(leftDate, msg);
        if (m1 != null) {
            return m1;
        }
        String m2 = notNull(rightDate, msg);
        if (m2 != null) {
            return m2;
        }
        if (leftDate.isBefore(rightDate)) {
            return nullSafeGet(msg);
        }
        return null;
    }

    /********************************************************************
     * REGEX
     ********************************************************************/


    public static String matches(String input, Pattern pattern) {
        return matches(input, pattern, () -> "The string %s is either null or does not match the pattern='%s'"
                .formatted(format(input), pattern));
    }

    public static String matches(String input, Pattern pattern, Supplier<String> msg) {
        String m1 = notNull(input, msg);
        if (m1 != null) {
            return m1;
        }
        boolean matches = pattern.matcher(input).matches();
        if (!matches) {
            return nullSafeGet(msg);
        }
        return null;
    }

    public static String emptyOrMatches(String input, Pattern pattern) {
        return emptyOrMatches(input, pattern, () -> "The string %s is either null or it is not-empty and does not match the pattern='%s'"
                .formatted(format(input), pattern));
    }

    public static String emptyOrMatches(String input, Pattern pattern, Supplier<String> msg) {
        String m1 = notNull(input, msg);
        if (m1 != null) {
            return m1;
        }
        if (!input.isEmpty()) {
            boolean matches = pattern.matcher(input).matches();
            if (!matches) {
                return nullSafeGet(msg);
            }
        }
        return null;
    }

    public static String nullOrEmptyOrMatches(String input, Pattern pattern) {
        return emptyOrMatches(input, pattern, () -> "The string %s is not-null and not-empty and does not match the pattern='%s'"
                .formatted(format(input), pattern));
    }

    public static String nullOrEmptyOrMatches(String input, Pattern pattern, Supplier<String> msg) {
        if (input != null) {
            if (!input.isEmpty()) {
                boolean matches = pattern.matcher(input).matches();
                if (!matches) {
                    return nullSafeGet(msg);
                }
            }
        }
        return null;
    }

    public static String nullOrMatches(String input, Pattern pattern) {
        return nullOrMatches(input, pattern, () -> "The string %s is not-null and does not match the pattern='%s'"
                .formatted(format(input), pattern));
    }

    public static String nullOrMatches(String input, Pattern pattern, Supplier<String> msg) {
        if (input != null) {
            boolean matches = pattern.matcher(input).matches();
            if (!matches) {
                return nullSafeGet(msg);
            }
        }
        return null;
    }
}
