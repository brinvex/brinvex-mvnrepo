package com.brinvex.finance.types.enu;

public enum FinancialStatus {

    NORMAL,

    DEFICIENT,

    DELINQUENT,

    BANKRUPT,

}
