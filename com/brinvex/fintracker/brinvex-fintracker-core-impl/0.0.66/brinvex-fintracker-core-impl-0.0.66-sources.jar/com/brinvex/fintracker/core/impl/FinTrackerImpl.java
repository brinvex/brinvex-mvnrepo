package com.brinvex.fintracker.core.impl;

import com.brinvex.fintracker.core.api.CoreModule;
import com.brinvex.fintracker.core.api.FinTracker;
import com.brinvex.fintracker.core.api.FinTrackerConfig;
import com.brinvex.fintracker.core.api.FinTrackerModule;
import com.brinvex.fintracker.core.api.FinTrackerModuleFactory;
import com.brinvex.fintracker.core.api.ToolboxModule;
import com.brinvex.fintracker.core.api.provider.Provider;
import com.brinvex.util.java.validation.Assert;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.SequencedCollection;
import java.util.ServiceLoader;

import static com.brinvex.util.java.collection.CollectionUtil.getFirstThrowIfMore;
import static java.util.function.Function.identity;
import static java.util.stream.Collectors.toMap;

@SuppressWarnings("unused")
public class FinTrackerImpl implements FinTracker {

    private final Map<Class<?>, FinTrackerModuleFactory<?>> moduleFactories;

    private final Map<Class<?>, FinTrackerModule> modules = new LinkedHashMap<>();

    private final Map<Class<?>, List<Provider<?, ?>>> extensionProviders = new LinkedHashMap<>();

    private final Map<Class<?>, Provider<?, ?>> coreProviders = new LinkedHashMap<>();

    private final FinTrackerConfig config;

    private volatile ToolboxModule toolbox;

    private volatile CoreModule core;

    public FinTrackerImpl(FinTrackerConfig config) {
        LOG.debug("Instantiating FinTrackerApplicationImpl: {}", config);
        this.config = config;
        this.moduleFactories = loadModuleFactories();
    }

    @SuppressWarnings("unchecked")
    @Override
    public <MODULE extends FinTrackerModule> MODULE get(Class<MODULE> moduleType) {
        FinTrackerModule module = modules.get(moduleType);
        if (module == null) {
            if (moduleType == CoreModule.class) {
                return (MODULE) getCoreModule();
            } else if (moduleType == ToolboxModule.class) {
                return (MODULE) getToolboxModule();
            }
            synchronized (modules) {
                module = modules.get(moduleType);
                if (module == null) {
                    FinTrackerModuleFactory<?> moduleFactory = moduleFactories.get(moduleType);
                    if (moduleFactory == null) {
                        throw new IllegalStateException("Module factory not found: " + moduleType);
                    }
                    module = moduleFactory.createModule(new FinTrackerModuleContextImpl(this, config, getToolboxModule(), moduleType));
                    Assert.notNull(module);
                    modules.put(moduleType, module);
                }
            }
        }
        return (MODULE) module;
    }

    @SuppressWarnings("unchecked")
    @Override
    public <REQUEST, PROVIDER extends Provider<REQUEST, ?>> PROVIDER get(Class<PROVIDER> providerType, REQUEST request) {
        List<Provider<?, ?>> extensionProvidersForType = extensionProviders.get(providerType);
        if (extensionProvidersForType == null) {
            synchronized (extensionProviders) {
                extensionProvidersForType = extensionProviders.get(providerType);
                if (extensionProvidersForType == null) {
                    extensionProvidersForType = new ArrayList<>();
                    for (Entry<Class<?>, FinTrackerModuleFactory<?>> e : moduleFactories.entrySet()) {
                        Class<FinTrackerModule> moduleType = (Class<FinTrackerModule>) e.getKey();
                        FinTrackerModuleFactory<?> moduleFactory = e.getValue();
                        if (moduleFactory.providerTypes().contains(providerType)) {
                            FinTrackerModule module = get(moduleType);
                            SequencedCollection<Provider<?, ?>> moduleProviders = module.providers(providerType);
                            extensionProvidersForType.addAll(moduleProviders);
                        }
                    }
                    LOG.debug("Assigning extension providers: {} -> {}", providerType, extensionProvidersForType);
                    extensionProviders.put(providerType, extensionProvidersForType);
                }
            }
        }
        PROVIDER resultProvider = null;
        for (Provider<?, ?> provider : extensionProvidersForType) {
            PROVIDER typedProvider = (PROVIDER) provider;
            if (typedProvider.supports(request)) {
                if (resultProvider == null) {
                    resultProvider = typedProvider;
                } else {
                    throw new IllegalStateException("Multiple providers found: %s, %s, %s, %s".formatted(providerType, request, resultProvider, typedProvider));
                }
            }
        }
        if (resultProvider == null) {
            PROVIDER coreProvider = (PROVIDER) coreProviders.get(providerType);
            if (coreProvider == null) {
                synchronized (coreProviders) {
                    coreProvider = (PROVIDER) coreProviders.get(providerType);
                    if (coreProvider == null) {
                        coreProvider = (PROVIDER) getFirstThrowIfMore(getCoreModule().providers(providerType));
                        if (coreProvider != null) {
                            coreProviders.put(providerType, coreProvider);
                            LOG.debug("Assigning core provider: {} -> {}", providerType, coreProvider);
                        }
                    }
                }
            }
            if (coreProvider != null) {
                if (coreProvider.supports(request)) {
                    resultProvider = coreProvider;
                }
            }
        }
        if (resultProvider == null) {
            throw new IllegalStateException("Provider not found: %s, %s".formatted(providerType, request));
        }
        return resultProvider;
    }

    private static Map<Class<?>, FinTrackerModuleFactory<?>> loadModuleFactories() {
        @SuppressWarnings({"unchecked", "rawtypes"})
        ServiceLoader<FinTrackerModuleFactory<?>> serviceLoader = (ServiceLoader) ServiceLoader.load(FinTrackerModuleFactory.class);
        Map<Class<?>, FinTrackerModuleFactory<?>> moduleFactories = serviceLoader
                .stream()
                .map(ServiceLoader.Provider::get)
                .collect(toMap(FinTrackerModuleFactory::moduleType, identity()));
        if (moduleFactories.isEmpty()) {
            LOG.warn("""
                    No module factories were loaded using SPI. This may indicate an issue with classloading or concurrent access to the ServiceLoader, such as through parallel streams or similar mechanisms.
                    """);
        }
        return moduleFactories;
    }

    private ToolboxModule getToolboxModule() {
        if (toolbox == null) {
            synchronized (modules) {
                if (toolbox == null) {
                    toolbox = new ToolboxModuleImpl(config);
                }
            }
        }
        return toolbox;
    }

    private CoreModule getCoreModule() {
        if (core == null) {
            synchronized (modules) {
                if (core == null) {
                    core = new CoreModuleImpl(new FinTrackerModuleContextImpl(this, config, getToolboxModule(), CoreModule.class));
                }
            }
        }
        return core;
    }

    private static final Logger LOG = LoggerFactory.getLogger(FinTrackerImpl.class);

}
