package com.brinvex.fintracker.core.api.model.domain;

import java.math.BigDecimal;

import static java.util.Objects.requireNonNull;

public record Money(
        String ccy,
        BigDecimal amount
) {
    public Money {
        requireNonNull(ccy);
        requireNonNull(amount);
    }
}
