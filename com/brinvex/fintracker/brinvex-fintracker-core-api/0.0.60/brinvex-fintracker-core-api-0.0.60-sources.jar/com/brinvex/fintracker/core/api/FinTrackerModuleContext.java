package com.brinvex.fintracker.core.api;

import com.brinvex.util.dms.api.Dms;

import java.util.function.Supplier;

public interface FinTrackerModuleContext {

    <SERVICE> SERVICE singletonService(Class<SERVICE> type, Supplier<SERVICE> serviceSupplier);

    default String getProperty(String propKey) {
        return getProperty(propKey, null);
    }

    String getProperty(String propKey, String defaultValue);

    Dms dms();

    FinTracker finTracker();

    ToolboxModule toolbox();

}
