package com.brinvex.util.fiobank.api.model;

public enum TransactionType {

    BUY,
    SELL,
    DEPOSIT,
    WITHDRAWAL,
    CASH_DIVIDEND,
    CAPITAL_DIVIDEND,
    STOCK_DIVIDEND,
    DIVIDEND_REVERSAL,
    INTEREST,
    FX_BUY,
    FX_SELL,
    FEE,
    TAX,
    TAX_REFUND,
    RECLAMATION,
    INSTRUMENT_CHANGE_PARENT,
    INSTRUMENT_CHANGE_CHILD,
    SPINOFF_PARENT,
    SPINOFF_CHILD,
    SPINOFF_VALUE,
    SPLIT,
    LIQUIDATION,
    MERGER_PARENT,
    MERGER_CHILD;

}
