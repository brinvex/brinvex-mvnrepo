package com.brinvex.fintracker.core.api.service;

import com.brinvex.fintracker.core.api.domain.active.PtfRuntime;

public interface PtfService {

    PtfRuntime newPtfRuntime();

}
