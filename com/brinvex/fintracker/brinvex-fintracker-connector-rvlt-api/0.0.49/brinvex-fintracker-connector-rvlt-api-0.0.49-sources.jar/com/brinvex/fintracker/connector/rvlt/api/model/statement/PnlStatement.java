package com.brinvex.fintracker.connector.rvlt.api.model.statement;

import java.time.LocalDate;
import java.util.List;

public record PnlStatement(
        String accountName,
        String accountNumber,
        LocalDate periodStartIncl,
        LocalDate periodEndIncl,
        String ccy,
        List<Transaction> transactions
) {
}
