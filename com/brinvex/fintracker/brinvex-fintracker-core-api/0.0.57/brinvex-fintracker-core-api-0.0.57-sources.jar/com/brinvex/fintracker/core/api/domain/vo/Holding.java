package com.brinvex.fintracker.core.api.domain.vo;

public record Holding() {
}
