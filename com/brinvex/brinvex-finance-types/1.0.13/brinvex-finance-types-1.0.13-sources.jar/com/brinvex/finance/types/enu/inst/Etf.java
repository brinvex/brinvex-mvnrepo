package com.brinvex.finance.types.enu.inst;

import com.brinvex.finance.types.enu.Country;
import com.brinvex.finance.types.vo.FullSymbol;

public enum Etf {
    /**
     * iShares Core S&P 500 UCITS ETF USD (Acc)
     */
    SXR8_DE("SXR8", Country.DE);

    private final FullSymbol fullSymbol;

    Etf(String symbol, Country country) {
        this.fullSymbol = new FullSymbol(symbol, country);
    }

    public FullSymbol fullSymbol() {
        return fullSymbol;
    }

    public String symbol() {
        return fullSymbol.symbol();
    }

    public Country country() {
        return fullSymbol.country();
    }

}
