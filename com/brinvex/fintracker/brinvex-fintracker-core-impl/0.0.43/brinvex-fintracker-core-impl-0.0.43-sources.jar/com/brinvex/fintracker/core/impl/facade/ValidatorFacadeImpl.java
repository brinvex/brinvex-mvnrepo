package com.brinvex.fintracker.core.impl.facade;

import com.brinvex.fintracker.core.api.facade.ValidatorFacade;
import com.brinvex.fintracker.core.api.model.general.Validatable;
import jakarta.validation.ConstraintViolation;
import jakarta.validation.ConstraintViolationException;

import java.util.Collection;
import java.util.Set;
import java.util.function.Function;

public class ValidatorFacadeImpl implements ValidatorFacade {

    private final jakarta.validation.Validator jakartaValidator;

    public ValidatorFacadeImpl(jakarta.validation.Validator jakartaValidator) {
        this.jakartaValidator = jakartaValidator;
    }

    @Override
    public <T extends Validatable> Set<ConstraintViolation<T>> validate(T validatable) {
        return jakartaValidator.validate(validatable);
    }

}
