package com.brinvex.fintracker.connector.fiob.api.service;

import com.brinvex.fintracker.core.api.domain.dto.Account;
import com.brinvex.fintracker.core.api.provider.PtfProgressProvider;

import java.time.Duration;
import java.time.LocalDate;

public interface FiobPtfProgressProvider extends PtfProgressProvider {

    PtfProgress getPtfProgress(
            Account account,
            LocalDate fromDateIncl,
            LocalDate toDateIncl,
            Duration staleTolerance
    );

    PtfProgress getPtfProgressOffline(
            Account fiobAccount,
            LocalDate fromDateIncl,
            LocalDate toDateIncl
    );

}
