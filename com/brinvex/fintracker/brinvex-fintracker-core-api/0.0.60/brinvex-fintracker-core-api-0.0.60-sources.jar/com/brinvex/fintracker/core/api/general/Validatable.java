package com.brinvex.fintracker.core.api.general;

public interface Validatable {
}
