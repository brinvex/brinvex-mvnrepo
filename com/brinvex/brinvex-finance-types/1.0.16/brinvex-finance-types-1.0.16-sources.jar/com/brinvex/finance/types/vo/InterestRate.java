package com.brinvex.finance.types.vo;

import com.brinvex.finance.types.enu.InterestRateType;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDate;

public record InterestRate(
        InterestRateType type,
        LocalDate fromDateIncl,
        LocalDate toDateIncl,
        BigDecimal rate
) implements Serializable {

    public InterestRate {
        if (type == null) {
            throw new IllegalArgumentException("type must not be null");
        }
        if (fromDateIncl != null && toDateIncl != null) {
            if (fromDateIncl.isAfter(toDateIncl)) {
                throw new IllegalArgumentException("fromDateIncl must not be after toDateIncl, %s, %s".formatted(fromDateIncl, toDateIncl));
            }
        }
        if (rate == null) {
            throw new IllegalArgumentException("price must be greater than zero");
        }
    }

    public InterestRate(InterestRateType type, BigDecimal rate) {
        this(type, null, null, rate);
    }

    public InterestRate(InterestRateType type, LocalDate fromDateIncl, BigDecimal rate) {
        this(type, fromDateIncl, fromDateIncl, rate);
    }

    @Override
    public String toString() {
        return "%s,%s,%s,%s".formatted(type, fromDateIncl, toDateIncl, rate);
    }
}
