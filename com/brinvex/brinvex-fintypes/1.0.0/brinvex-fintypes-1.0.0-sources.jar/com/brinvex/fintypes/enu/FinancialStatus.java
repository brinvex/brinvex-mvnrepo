package com.brinvex.fintypes.enu;

public enum FinancialStatus {

    NORMAL,

    DEFICIENT,

    DELINQUENT,

    BANKRUPT,

}
