package com.brinvex.fintracker.core.api.model.domain.constraints;

public interface Validatable {
}
