package com.brinvex.util.ibkr.api.model;

import java.io.Serializable;

public record Credentials(
        String token,
        String activityFlexQueryId,
        String tradeConfirmFlexQueryId
) implements Serializable {
}
