package com.brinvex.util.spreadsheet.api;

import java.util.ServiceLoader;

public enum ExcelReaderFactory {

    INSTANCE;

    private ExcelXlsxReader xlsxReader;

    private ExcelXlsReader xlsReader;

    public ExcelReader getExcelReader() {
        return getXlsxReader();
    }

    public ExcelXlsxReader getXlsxReader() {
        if (xlsxReader == null) {
            ServiceLoader<ExcelXlsxReader> loader = ServiceLoader.load(ExcelXlsxReader.class);
            for (ExcelXlsxReader provider : loader) {
                this.xlsxReader = provider;
                break;
            }
        }
        if (xlsxReader == null) {
            throw new IllegalStateException(String.format("Not found any implementation of interface '%s'", ExcelXlsxReader.class));
        }
        return xlsxReader;
    }

    public ExcelXlsReader getXlsReader() {
        if (xlsReader == null) {
            ServiceLoader<ExcelXlsReader> loader = ServiceLoader.load(ExcelXlsReader.class);
            for (ExcelXlsReader provider : loader) {
                this.xlsReader = provider;
                break;
            }
        }
        if (xlsReader == null) {
            throw new IllegalStateException(String.format("Not found any implementation of interface '%s'", ExcelXlsReader.class));
        }
        return xlsReader;
    }

}
