package com.brinvex.util.java.validation;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.function.Supplier;
import java.util.regex.Pattern;

/**
 * <ul>
 *   <li>{@code Check} - If the condition is satisfied, returns {@code null}; otherwise, returns a message describing the condition violation.</li>
 *   <li>{@code Assert} - If the condition is satisfied, does nothing; otherwise, throws an {@code IllegalStateException} with a message describing the condition violation.</li>
 *   <li>{@code Validate} - If the condition is satisfied, does nothing; otherwise, throws an {@code IllegalArgumentException} with a message describing the condition violation.</li>
 * </ul>
 */
@SuppressWarnings({"SameParameterValue", "unused"})
public class Validate {

    private static void throwIfNotNull(String violationMsg) {
        if (violationMsg != null) {
            throw new IllegalArgumentException(violationMsg);
        }
    }
    
    /********************************************************************
     * BOOLEAN
     ********************************************************************/

    public static void isTrue(boolean expression) {
        throwIfNotNull(Check.isTrue(expression));
    }

    public static void isTrue(boolean expression, Supplier<String> msg) {
        throwIfNotNull(Check.isTrue(expression, msg));
    }

    public static void isFalse(boolean expression) {
        throwIfNotNull(Check.isFalse(expression));
    }

    public static void isFalse(boolean expression, Supplier<String> msg) {
        throwIfNotNull(Check.isFalse(expression, msg));
    }

    /********************************************************************
     * OBJECT
     ********************************************************************/

    public static void notNull(Object input) {
        throwIfNotNull(Check.notNull(input));
    }

    public static void notNull(Object input, Supplier<String> msg) {
        throwIfNotNull(Check.notNull(input, msg));
    }

    public static void isNull(Object input) {
        throwIfNotNull(Check.isNull(input));
    }

    public static void isNull(Object input, Supplier<String> msg) {
        throwIfNotNull(Check.isNull(input, msg));
    }

    public static void equal(Object input1, Object input2) {
        throwIfNotNull(Check.equal(input1, input2));
    }

    public static void equal(Object input1, Object input2, Supplier<String> msg) {
        throwIfNotNull(Check.equal(input1, input2, msg));
    }

    /********************************************************************
     * STRING
     ********************************************************************/

    public static void blank(String input) {
        throwIfNotNull(Check.blank(input));
    }

    public static void blank(String input, Supplier<String> msg) {
        throwIfNotNull(Check.blank(input, msg));
    }

    public static void empty(String input) {
        throwIfNotNull(Check.empty(input));
    }

    public static void empty(String input, Supplier<String> msg) {
        throwIfNotNull(Check.empty(input, msg));
    }

    public static void contains(String haystack, String needle) {
        throwIfNotNull(Check.contains(haystack, needle));
    }

    public static void contains(String haystack, String needle, Supplier<String> msg) {
        throwIfNotNull(Check.contains(haystack, needle, msg));
    }

    public static void notNullNotBlank(String input) {
        throwIfNotNull(Check.notNullNotBlank(input));
    }

    public static void notNullNotBlank(String input, Supplier<String> msg) {
        throwIfNotNull(Check.notNullNotBlank(input, msg));
    }

    public static void nullOrNotBlank(String input) {
        throwIfNotNull(Check.nullOrNotBlank(input));
    }

    public static void nullOrNotBlank(String input, Supplier<String> msg) {
        throwIfNotNull(Check.nullOrNotBlank(input, msg));
    }

    /********************************************************************
     * NUMBER
     ********************************************************************/

    public static void zero(BigDecimal number) {
        throwIfNotNull(Check.zero(number));
    }

    public static void zero(BigDecimal number, Supplier<String> msg) {
        throwIfNotNull(Check.zero(number, msg));
    }

    public static void nullOrZero(BigDecimal number) {
        throwIfNotNull(Check.nullOrZero(number));
    }

    public static void nullOrZero(BigDecimal number, Supplier<String> msg) {
        throwIfNotNull(Check.nullOrZero(number, msg));
    }

    public static void positive(BigDecimal number) {
        throwIfNotNull(Check.positive(number));
    }

    public static void positive(BigDecimal number, Supplier<String> msg) {
        throwIfNotNull(Check.positive(number, msg));
    }

    public static void nullOrPositive(BigDecimal number) {
        throwIfNotNull(Check.nullOrPositive(number));
    }

    public static void nullOrPositive(BigDecimal number, Supplier<String> msg) {
        throwIfNotNull(Check.nullOrPositive(number, msg));
    }

    public static void negative(BigDecimal number) {
        throwIfNotNull(Check.negative(number));
    }

    public static void negative(BigDecimal number, Supplier<String> msg) {
        throwIfNotNull(Check.negative(number, msg));
    }

    public static void nullOrNegative(BigDecimal number) {
        throwIfNotNull(Check.nullOrNegative(number));
    }

    public static void nullOrNegative(BigDecimal number, Supplier<String> msg) {
        throwIfNotNull(Check.nullOrNegative(number, msg));
    }

    public static void equal(BigDecimal number1, BigDecimal number2) {
        throwIfNotNull(Check.equal(number1, number2));
    }

    public static void equal(BigDecimal number1, BigDecimal number2, Supplier<String> msg) {
        throwIfNotNull(Check.equal(number1, number2, msg));
    }

    public static void greaterThan(BigDecimal number1, BigDecimal number2) {
        throwIfNotNull(Check.greaterThan(number1, number2));
    }

    public static void greaterThan(BigDecimal number1, BigDecimal number2, Supplier<String> msg) {
        throwIfNotNull(Check.greaterThan(number1, number2, msg));
    }

    public static void equalOrGreaterThan(BigDecimal number1, BigDecimal number2) {
        throwIfNotNull(Check.equalOrGreaterThan(number1, number2));
    }

    public static void equalOrGreaterThan(BigDecimal number1, BigDecimal number2, Supplier<String> msg) {
        throwIfNotNull(Check.equalOrGreaterThan(number1, number2, msg));
    }

    public static void lessThan(BigDecimal number1, BigDecimal number2) {
        throwIfNotNull(Check.lessThan(number1, number2));
    }

    public static void lessThan(BigDecimal number1, BigDecimal number2, Supplier<String> msg) {
        throwIfNotNull(Check.lessThan(number1, number2, msg));
    }

    public static void equalOrLessThan(BigDecimal number1, BigDecimal number2) {
        throwIfNotNull(Check.equalOrLessThan(number1, number2));
    }

    public static void equalOrLessThan(BigDecimal number1, BigDecimal number2, Supplier<String> msg) {
        throwIfNotNull(Check.equalOrLessThan(number1, number2, msg));
    }

    public static void opposite(BigDecimal number1, BigDecimal number2) {
        throwIfNotNull(Check.opposite(number1, number2));
    }

    public static void opposite(BigDecimal number1, BigDecimal number2, Supplier<String> msg) {
        throwIfNotNull(Check.opposite(number1, number2, msg));
    }

    /********************************************************************
     * DATE
     ********************************************************************/

    public static void before(LocalDate leftDate, LocalDate rightDate) {
        throwIfNotNull(Check.before(leftDate, rightDate));
    }

    public static void before(LocalDate leftDate, LocalDate rightDate, Supplier<String> msg) {
        throwIfNotNull(Check.before(leftDate, rightDate, msg));
    }

    public static void equalOrAfter(LocalDate leftDate, LocalDate rightDate) {
        throwIfNotNull(Check.equalOrAfter(leftDate, rightDate));
    }

    public static void equalOrAfter(LocalDate leftDate, LocalDate rightDate, Supplier<String> msg) {
        throwIfNotNull(Check.equalOrAfter(leftDate, rightDate, msg));
    }

    /********************************************************************
     * REGEX
     ********************************************************************/

    public static void matches(String input, Pattern pattern) {
        throwIfNotNull(Check.matches(input, pattern));
    }

    public static void matches(String input, Pattern pattern, Supplier<String> msg) {
        throwIfNotNull(Check.matches(input, pattern, msg));
    }

    public static void emptyOrMatches(String input, Pattern pattern) {
        throwIfNotNull(Check.emptyOrMatches(input, pattern));
    }

    public static void emptyOrMatches(String input, Pattern pattern, Supplier<String> msg) {
        throwIfNotNull(Check.emptyOrMatches(input, pattern, msg));
    }

    public static void nullOrEmptyOrMatches(String input, Pattern pattern) {
        throwIfNotNull(Check.nullOrEmptyOrMatches(input, pattern));
    }

    public static void nullOrEmptyOrMatches(String input, Pattern pattern, Supplier<String> msg) {
        throwIfNotNull(Check.nullOrEmptyOrMatches(input, pattern, msg));
    }

    public static void nullOrMatches(String input, Pattern pattern) {
        throwIfNotNull(Check.nullOrMatches(input, pattern));
    }

    public static void nullOrMatches(String input, Pattern pattern, Supplier<String> msg) {
        throwIfNotNull(Check.nullOrMatches(input, pattern, msg));
    }
}
