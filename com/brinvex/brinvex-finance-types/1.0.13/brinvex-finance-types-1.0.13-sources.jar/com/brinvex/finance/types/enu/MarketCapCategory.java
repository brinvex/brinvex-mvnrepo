package com.brinvex.finance.types.enu;

public enum MarketCapCategory {

    /**
     * Large-cap ($10 billion or more)
     */
    L,

    /**
     * Mid-cap ($2 billion to $10 billion)
     */
    M,

    /**
     * Small-cap (less than $2 billion)
     */
    S,

}
