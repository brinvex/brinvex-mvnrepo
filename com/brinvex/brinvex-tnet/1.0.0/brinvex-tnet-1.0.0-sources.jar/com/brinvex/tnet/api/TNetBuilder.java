package com.brinvex.tnet.api;

import com.brinvex.tnet.internal.TNetImpl;

import java.time.Duration;

public class TNetBuilder {

    private TNetPoolInitMode poolInitMode = TNetPoolInitMode.ONE_EAGER;
    private int poolSize = 2;
    private String socksProxyHost = "127.0.0.1";
    private int httpProxyBasePort = 8050;
    private int httpProxyPortOffset = 1;
    private Duration pollTimeout = Duration.ofSeconds(60);
    private String dockerEngineAddress = "http://127.0.0.1:2375";
    private String proxyServerDockerContNamePattern = null;
    private boolean healthcheckAtStartup = true;

    public TNetPoolInitMode getPoolInitMode() {
        return poolInitMode;
    }

    public TNetBuilder setPoolInitMode(TNetPoolInitMode poolInitMode) {
        this.poolInitMode = poolInitMode;
        return this;
    }

    public TNetBuilder setPoolSize(int poolSize) {
        this.poolSize = poolSize;
        return this;
    }

    public TNetBuilder setHttpProxyBasePort(int httpProxyBasePort) {
        this.httpProxyBasePort = httpProxyBasePort;
        return this;
    }

    public TNetBuilder setDockerEngineAddress(String dockerEngineAddress) {
        this.dockerEngineAddress = dockerEngineAddress;
        return this;
    }

    public TNetBuilder setSocksProxyHost(String socksProxyHost) {
        this.socksProxyHost = socksProxyHost;
        return this;
    }

    public TNetBuilder setHttpProxyPortOffset(int httpProxyPortOffset) {
        this.httpProxyPortOffset = httpProxyPortOffset;
        return this;
    }

    public TNetBuilder setPollTimeout(Duration pollTimeout) {
        this.pollTimeout = pollTimeout;
        return this;
    }

    public TNetBuilder setProxyServerDockerContNamePattern(String proxyServerDockerContNamePattern) {
        this.proxyServerDockerContNamePattern = proxyServerDockerContNamePattern;
        return this;
    }

    public TNetBuilder setHealthcheckAtStartup(boolean healthcheckAtStartup) {
        this.healthcheckAtStartup = healthcheckAtStartup;
        return this;
    }

    public TNet build() throws TNetException {
        return new TNetImpl(
                poolInitMode,
                poolSize,
                dockerEngineAddress,
                socksProxyHost,
                httpProxyBasePort,
                httpProxyPortOffset,
                pollTimeout,
                proxyServerDockerContNamePattern,
                healthcheckAtStartup
        );
    }
}