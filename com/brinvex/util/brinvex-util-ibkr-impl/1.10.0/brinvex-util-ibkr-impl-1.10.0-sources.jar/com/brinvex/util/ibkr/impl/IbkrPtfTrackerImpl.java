package com.brinvex.util.ibkr.impl;

import com.brinvex.util.ibkr.api.model.Credentials;
import com.brinvex.util.ibkr.api.model.DocKey;
import com.brinvex.util.ibkr.api.model.PtfProgress;
import com.brinvex.util.ibkr.api.model.FinTransaction;
import com.brinvex.util.ibkr.api.model.statement.EquitySummary;
import com.brinvex.util.ibkr.api.model.statement.FlexStatement.ActivityStatement;
import com.brinvex.util.ibkr.api.model.statement.FlexStatement.TradeConfirmStatement;
import com.brinvex.util.ibkr.api.service.IbkrDms;
import com.brinvex.util.ibkr.api.service.IbkrFetcher;
import com.brinvex.util.ibkr.api.service.IbkrStatementMerger;
import com.brinvex.util.ibkr.api.service.IbkrStatementParser;
import com.brinvex.util.ibkr.api.service.IbkrPtfTracker;
import com.brinvex.util.ibkr.api.service.IbkrTransactionMapper;
import com.brinvex.util.ibkr.api.service.exception.IbkrException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.math.BigDecimal;
import java.time.Duration;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Stream;

import static com.brinvex.util.ibkr.api.model.statement.FlexStatementType.ACT;
import static com.brinvex.util.ibkr.api.model.statement.FlexStatementType.TC;
import static com.brinvex.util.ibkr.impl.Util.nullSafe;
import static java.time.Duration.ofMillis;
import static java.time.Duration.ofSeconds;
import static java.util.Collections.emptyList;
import static java.util.Comparator.comparing;
import static java.util.stream.Collectors.toMap;

@SuppressWarnings({"DuplicatedCode", "unused"})
public class IbkrPtfTrackerImpl implements IbkrPtfTracker {

    private static final Logger LOG = LoggerFactory.getLogger(IbkrPtfTrackerImpl.class);

    private static final ZoneId IBKR_ZONE_ID = ZoneId.of("America/New_York");

    private final IbkrDms dms;

    private final IbkrStatementParser parser;

    private final IbkrFetcher fetcher;

    private final IbkrStatementMerger statementMerger;

    private final IbkrTransactionMapper transactionMapper;

    public IbkrPtfTrackerImpl(
            IbkrDms dms,
            IbkrStatementParser parser,
            IbkrFetcher fetcher,
            IbkrStatementMerger statementMerger,
            IbkrTransactionMapper transactionMapper
    ) {
        this.dms = dms;
        this.parser = parser;
        this.fetcher = fetcher;
        this.statementMerger = statementMerger;
        this.transactionMapper = transactionMapper;
    }

    @Override
    public PtfProgress getPortfolioProgressOffline(String accountId, LocalDate fromDayIncl, LocalDate toDayIncl) {
        if (accountId == null || accountId.isEmpty()) {
            throw new IllegalArgumentException("accountId cannot be null or empty");
        }
        if (fromDayIncl == null || toDayIncl == null) {
            throw new IllegalArgumentException("fromDayIncl and toDayIncl cannot be null ");
        }
        return getPortfolioProgress(accountId, null, fromDayIncl, toDayIncl, null);
    }

    @Override
    public PtfProgress getPortfolioProgressOnline(
            String accountId,
            Credentials credential,
            LocalDate fromDayIncl,
            LocalDate toDayIncl,
            Duration staleTolerance
    ) {
        if (accountId == null || accountId.isEmpty()) {
            throw new IllegalArgumentException("accountId cannot be null or empty");
        }
        if (credential == null) {
            throw new IllegalArgumentException("credential cannot be null ");
        }
        if (fromDayIncl == null || toDayIncl == null) {
            throw new IllegalArgumentException("fromDayIncl and toDayIncl cannot be null ");
        }
        if (staleTolerance == null) {
            throw new IllegalArgumentException("staleTolerance cannot be null ");
        }
        return getPortfolioProgress(accountId, credential, fromDayIncl, toDayIncl, staleTolerance);
    }

    private PtfProgress getPortfolioProgress(String accountId, Credentials credential, LocalDate fromDayIncl, LocalDate toDayIncl, Duration staleTolerance) {
        LocalDate ibkrToday = ZonedDateTime.now(IBKR_ZONE_ID).toLocalDate();

        {
            boolean actOnline = credential != null && credential.activityFlexQueryId() != null;
            if (actOnline) {
                LocalDate fetchFromDayIncl;
                List<DocKey> oldActDocKeys = dms.getDocKeys(ACT, accountId, fromDayIncl, toDayIncl);
                if (oldActDocKeys.isEmpty()) {
                    fetchFromDayIncl = fromDayIncl;
                } else {
                    LocalDate oldOldestDay = oldActDocKeys.getFirst().fromDayIncl();
                    LocalDate oldNewestDay = oldActDocKeys.getLast().toDayIncl();
                    if (fromDayIncl.isBefore(oldOldestDay)) {
                        fetchFromDayIncl = fromDayIncl;
                    } else if (toDayIncl.isAfter(oldNewestDay)) {
                        fetchFromDayIncl = oldNewestDay.plusDays(1);
                    } else {
                        fetchFromDayIncl = null;
                    }
                }
                if (fetchFromDayIncl != null && fetchFromDayIncl.isBefore(ibkrToday)) {
                    if (fetchFromDayIncl.isBefore(ibkrToday.minusDays(365))) {
                        throw new IbkrException(
                                "IBKR does not allow automatic fetching of Flex Activity Statements for periods starting more than 365 days ago. " +
                                "Please manually retrieve the missed statements and upload them to DMS. " +
                                "accountId=%s, activityFlexQueryId=%s, fromDayIncl=%s, toDayIncl=%s, fetchFromDayIncl=%s"
                                        .formatted(accountId, credential.activityFlexQueryId(), fromDayIncl, toDayIncl, fetchFromDayIncl));
                    }
                    String fetchedContent = fetcher.fetchFlexStatement(credential.token(), credential.activityFlexQueryId(), 4, ofSeconds(5));
                    ActivityStatement fetchedActStatement = parser.parseActivityStatement(fetchedContent);
                    DocKey fetchedDocKey = new DocKey(accountId, ACT, fetchedActStatement.fromDate(), fetchedActStatement.toDate());
                    LOG.debug("getPortfolioProgress - saving fetched statement - {}", fetchedDocKey);
                    boolean useful = dms.putStatementIfUseful(fetchedDocKey, fetchedContent);
                    assert useful;

                    {
                        List<DocKey> unnecessaryTcDocKeys = dms.getDocKeys(TC, accountId, fetchedActStatement.fromDate(), fetchedActStatement.toDate());
                        for (DocKey unnecessareTcDocKey : unnecessaryTcDocKeys) {
                            LOG.debug("getPortfolioProgress - deleting unnecessary statement - {}", unnecessareTcDocKey);
                            dms.delete(unnecessareTcDocKey);
                        }
                    }
                }
            }
        }
        List<ActivityStatement> actStatements = dms.getDocKeys(ACT, accountId, fromDayIncl, toDayIncl)
                .stream()
                .map(dms::getStatementContent)
                .map(parser::parseActivityStatement)
                .toList();

        ActivityStatement mergedActStatement = statementMerger.mergeActivityStatements(actStatements).orElse(null);
        if (mergedActStatement == null) {
            return null;
        }

        List<FinTransaction> newCashTrans = transactionMapper.mapCashTransactions(mergedActStatement.cashTransactions());

        List<FinTransaction> newTrades = transactionMapper.mapTrades(mergedActStatement.trades());

        List<FinTransaction> newCorpActions = transactionMapper.mapCorporateAction(mergedActStatement.corporateActions());

        List<FinTransaction> tcTrades;
        {
            LocalDate tcDay = mergedActStatement.toDate().plusDays(1);
            TradeConfirmStatement tcStatement = null;
            if (!tcDay.isAfter(toDayIncl)) {
                DocKey tcDocKey = new DocKey(accountId, TC, tcDay, tcDay);
                boolean tcOnline = credential != null && credential.tradeConfirmFlexQueryId() != null;
                if (tcOnline) {
                    if (tcDay.isEqual(ibkrToday)) {
                        tcStatement = nullSafe(dms.getStatementContentIfExists(tcDocKey), parser::parseTradeConfirmStatement);
                        if (tcStatement != null) {
                            ZonedDateTime ibkrNow = ZonedDateTime.now(IBKR_ZONE_ID);
                            boolean oldIsStale = tcStatement.whenGenerated().plus(staleTolerance).isBefore(ibkrNow);
                            if (oldIsStale) {
                                LOG.debug("getPortfolioProgress - old is stale - tcDocKey={}, whenGenerated={}, staleTolerance={}, ibkrNow={}",
                                        tcDocKey, tcStatement.whenGenerated(), staleTolerance, ibkrNow);
                                tcStatement = null;
                            } else {
                                LOG.debug("getPortfolioProgress - going to use old - tcDocKey={}, whenGenerated={}, staleTolerance={}, ibkrNow={}",
                                        tcDocKey, tcStatement.whenGenerated(), staleTolerance, ibkrNow);
                            }
                        }
                        if (tcStatement == null) {
                            String tcContent = fetcher.fetchFlexStatement(credential.token(), credential.tradeConfirmFlexQueryId(), 2, ofMillis(250));
                            dms.putStatement(tcDocKey, tcContent);
                            tcStatement = parser.parseTradeConfirmStatement(tcContent);
                        }
                    }
                }
                if (tcStatement == null) {
                    tcStatement = nullSafe(dms.getStatementContentIfExists(tcDocKey), parser::parseTradeConfirmStatement);
                }
            }
            if (tcStatement != null) {
                tcTrades = transactionMapper.mapTradeConfirms(tcStatement.tradeConfirmations());
            } else {
                tcTrades = emptyList();
            }
        }

        List<FinTransaction> newTrans = Stream.of(
                        newCorpActions,
                        newCashTrans,
                        newTrades,
                        tcTrades
                )
                .flatMap(Collection::stream)
                .filter(t -> !t.reportDate().isBefore(fromDayIncl))
                .filter(t -> !t.reportDate().isAfter(toDayIncl))
                .sorted(comparing(FinTransaction::reportDate))
                .toList();

        Map<LocalDate, BigDecimal> navs = mergedActStatement.equitySummaries()
                .stream()
                .filter(t -> !t.reportDate().isBefore(fromDayIncl))
                .filter(t -> !t.reportDate().isAfter(toDayIncl))
                .collect(toMap(EquitySummary::reportDate, EquitySummary::total, (u, v) -> {
                    throw new RuntimeException("Values conflict: %s, %s".formatted(u, v));
                }, LinkedHashMap::new));

        return new PtfProgress(newTrans, navs);
    }
}
