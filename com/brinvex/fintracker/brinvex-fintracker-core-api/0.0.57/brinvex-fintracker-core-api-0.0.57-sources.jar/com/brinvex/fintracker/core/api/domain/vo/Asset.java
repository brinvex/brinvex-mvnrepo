package com.brinvex.fintracker.core.api.domain.vo;

import com.brinvex.fintracker.core.api.domain.enu.AssetType;

public record Asset(
        String id,
        AssetType type,
        String country,
        String symbol,
        String name,
        String countryFigi,
        String isin,
        String extraType,
        String extraDetail
) {

    public Asset {
        if (type == null) {
            throw new IllegalArgumentException("type must not be null");
        }
    }

    public static AssetBuilder builder() {
        return new AssetBuilder();
    }

    public static class AssetBuilder {
        private String id;
        private AssetType type;
        private String country;
        private String symbol;
        private String name;
        private String countryFigi;
        private String isin;
        private String extraType;
        private String extraDetail;

        AssetBuilder() {
        }

        public AssetBuilder id(String id) {
            this.id = id;
            return this;
        }

        public AssetBuilder type(AssetType type) {
            this.type = type;
            return this;
        }

        public AssetBuilder country(String country) {
            this.country = country;
            return this;
        }

        public AssetBuilder symbol(String symbol) {
            this.symbol = symbol;
            return this;
        }

        public AssetBuilder name(String name) {
            this.name = name;
            return this;
        }

        public AssetBuilder countryFigi(String countryFigi) {
            this.countryFigi = countryFigi;
            return this;
        }

        public AssetBuilder isin(String isin) {
            this.isin = isin;
            return this;
        }

        public AssetBuilder extraType(String extraType) {
            this.extraType = extraType;
            return this;
        }

        public AssetBuilder extraDetail(String extraDetail) {
            this.extraDetail = extraDetail;
            return this;
        }

        public Asset build() {
            return new Asset(
                    this.id,
                    this.type,
                    this.country,
                    this.symbol,
                    this.name,
                    this.countryFigi,
                    this.isin,
                    this.extraType,
                    this.extraDetail);
        }
    }
}
