package com.brinvex.fintracker.core.api.model.domain.constraints.fintransaction;

import com.brinvex.fintracker.core.api.model.domain.Asset;
import com.brinvex.fintracker.core.api.model.domain.FinTransaction;
import jakarta.validation.constraints.Null;

public class OtherInternalFlowConstraints extends FinTransactionConstraints {

    OtherInternalFlowConstraints(FinTransaction finTransaction) {
        super(finTransaction);
    }

    @Null
    @Override
    public Asset getAsset() {
        return super.getAsset();
    }

}
