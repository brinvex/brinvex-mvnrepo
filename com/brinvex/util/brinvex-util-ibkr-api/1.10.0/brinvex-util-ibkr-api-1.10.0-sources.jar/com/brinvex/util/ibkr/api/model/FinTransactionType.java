/*
 * Copyright © 2023 Brinvex (dev@brinvex.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.brinvex.util.ibkr.api.model;

import java.math.BigDecimal;
import java.util.List;
import java.util.function.Predicate;

import static java.math.BigDecimal.ZERO;
import static java.util.Objects.requireNonNullElse;

@SuppressWarnings({"UnnecessaryLocalVariable", "DuplicatedCode"})
public enum FinTransactionType {

    BUY {
        @Override
        protected List<Predicate<FinTransaction>> predicates() {
            return List.of(
                    t -> t.settleDate() != null,
                    t -> t.netValue().compareTo(ZERO) < 0,
                    t -> t.symbol() != null,
                    t -> t.qty().compareTo(ZERO) > 0,
                    t -> t.price().compareTo(ZERO) > 0,
                    t -> t.fees().compareTo(ZERO) <= 0,
                    t -> requireNonNullElse(t.tax(), ZERO).compareTo(ZERO) == 0
            );
        }
    },
    SELL {
        @Override
        protected List<Predicate<FinTransaction>> predicates() {
            return List.of(
                    t -> t.settleDate() != null,
                    t -> t.netValue().compareTo(ZERO) > 0,
                    t -> t.symbol() != null,
                    t -> t.qty().compareTo(ZERO) < 0,
                    t -> t.price().compareTo(ZERO) > 0,
                    t -> t.fees().compareTo(ZERO) <= 0,
                    t -> requireNonNullElse(t.tax(), ZERO).compareTo(ZERO) <= 0
            );
        }
    },
    DEPOSIT {
        @Override
        protected List<Predicate<FinTransaction>> predicates() {
            return List.of(
                    t -> t.settleDate() != null,
                    t -> t.netValue().compareTo(ZERO) > 0,
                    t -> t.symbol() == null,
                    t -> t.qty().compareTo(ZERO) == 0,
                    t -> t.price() == null,
                    t -> t.fees().compareTo(ZERO) <= 0,
                    t -> requireNonNullElse(t.tax(), ZERO).compareTo(ZERO) == 0
            );
        }
    },
    WITHDRAWAL {
        @Override
        protected List<Predicate<FinTransaction>> predicates() {
            return List.of(
                    t -> t.settleDate() != null,
                    t -> t.netValue().compareTo(ZERO) < 0,
                    t -> t.symbol() == null,
                    t -> t.qty().compareTo(ZERO) == 0,
                    t -> t.price() == null,
                    t -> t.fees().compareTo(ZERO) <= 0,
                    t -> requireNonNullElse(t.tax(), ZERO).compareTo(ZERO) == 0
            );
        }
    },
    CASH_DIVIDEND {
        @Override
        protected List<Predicate<FinTransaction>> predicates() {
            return List.of(
                    t -> t.settleDate() != null,
                    t -> t.netValue().compareTo(ZERO) > 0,
                    t -> t.symbol() != null,
                    t -> t.qty().compareTo(ZERO) == 0,
                    t -> t.price() == null,
                    t -> t.fees().compareTo(ZERO) <= 0,
                    t -> requireNonNullElse(t.tax(), ZERO).compareTo(ZERO) <= 0
            );
        }
    },

    PAYMENT_IN_LIEU_OF_DIVIDENDS {
        @Override
        protected List<Predicate<FinTransaction>> predicates() {
            return List.of(
                    t -> t.settleDate() != null,
                    t -> t.netValue().compareTo(ZERO) > 0,
                    t -> t.symbol() != null,
                    t -> t.qty().compareTo(ZERO) == 0,
                    t -> t.price() == null,
                    t -> t.fees().compareTo(ZERO) <= 0,
                    t -> requireNonNullElse(t.tax(), ZERO).compareTo(ZERO) <= 0
            );
        }
    },

    FX_BUY {
        @Override
        protected List<Predicate<FinTransaction>> predicates() {
            return List.of(
                    t -> t.settleDate() != null,
                    t -> t.netValue().compareTo(ZERO) < 0,
                    t -> t.symbol() != null,
                    t -> t.qty().compareTo(ZERO) > 0,
                    t -> t.price().compareTo(ZERO) > 0,
                    t -> t.fees().compareTo(ZERO) <= 0,
                    t -> requireNonNullElse(t.tax(), ZERO).compareTo(ZERO) == 0
            );
        }
    },
    FX_SELL {
        @Override
        protected List<Predicate<FinTransaction>> predicates() {
            return List.of(
                    t -> t.settleDate() != null,
                    t -> t.netValue().compareTo(ZERO) > 0,
                    t -> t.symbol() != null,
                    t -> t.qty().compareTo(ZERO) < 0,
                    t -> t.price().compareTo(ZERO) > 0,
                    t -> t.fees().compareTo(ZERO) <= 0,
                    t -> requireNonNullElse(t.tax(), ZERO).compareTo(ZERO) == 0
            );
        }
    },
    FEE {
        @Override
        protected List<Predicate<FinTransaction>> predicates() {
            return List.of(
                    t -> t.settleDate() != null,
                    t -> t.qty().compareTo(ZERO) == 0,
                    t -> t.price() == null,
                    t -> t.fees().compareTo(ZERO) != 0,
                    t -> requireNonNullElse(t.tax(), ZERO).compareTo(ZERO) == 0
            );
        }
    },
    TAX {
        @Override
        protected List<Predicate<FinTransaction>> predicates() {
            return List.of(
                    t -> t.settleDate() != null,
                    t -> {
                        int netValSignum = t.netValue().signum();
                        int taxSignum = t.tax().signum();
                        return netValSignum != 0 && netValSignum == taxSignum;
                    },
                    t -> t.qty().compareTo(ZERO) == 0,
                    t -> t.price() == null,
                    t -> t.fees().compareTo(ZERO) == 0
            );
        }
    },
    TRANSFORMATION {
        @Override
        protected List<Predicate<FinTransaction>> predicates() {
            return List.of(
                    t -> t.price().compareTo(ZERO) >= 0,
                    t -> t.fees().compareTo(ZERO) == 0,
                    t -> requireNonNullElse(t.tax(), ZERO).compareTo(ZERO) == 0
            );
        }
    }
    ;

    private static final BigDecimal GROSS_NET_DIFF_TOLERANCE = new BigDecimal("0.005");

    protected abstract List<Predicate<FinTransaction>> predicates();

    private List<Predicate<FinTransaction>> predicates;

    @SuppressWarnings({"RedundantIfStatement", "ForLoopReplaceableByForEach"})
    public boolean transactionIsValid(FinTransaction t) {
        if (t.reportDate() == null) {
            return false;
        }
        if (t.type() == null) {
            return false;
        }
        if (!t.type().equals(FX_BUY) && !t.type().equals(FX_SELL)) {
            if (t.symbol() != null && t.country() == null) {
                return false;
            }
            if (t.symbol() == null && t.country() != null) {
                return false;
            }
        }
        if (t.netValue() != null) {
            if (t.currency() == null) {
                return false;
            }
        }
        if (this.predicates == null) {
            this.predicates = predicates();
        }
        for (int i = 0, nPredicates = this.predicates.size(); i < nPredicates; i++) {
            Predicate<FinTransaction> predicate = this.predicates.get(i);
            if (!predicate.test(t)) {
                return false;
            }
        }
        if (!grossValueNetValueIsValid(t)) {
            return false;
        }
        return true;
    }

    protected boolean grossValueNetValueIsValid(FinTransaction t) {
        BigDecimal grossValue = t.grossValue();
        BigDecimal netValue = t.netValue();
        if (grossValue == null) {
            return netValue == null;
        }
        BigDecimal fees = t.fees();
        BigDecimal tax = requireNonNullElse(t.tax(), ZERO);

        boolean isValid = grossValue.add(fees).add(tax).subtract(netValue).compareTo(GROSS_NET_DIFF_TOLERANCE) < 0;
        return isValid;
    }
}
