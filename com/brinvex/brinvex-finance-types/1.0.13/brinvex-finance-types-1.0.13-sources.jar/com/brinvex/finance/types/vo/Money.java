package com.brinvex.finance.types.vo;

import com.brinvex.finance.types.enu.Currency;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.function.BiFunction;
import java.util.function.Function;

public record Money(
        Currency ccy,
        BigDecimal amount
) implements Serializable {
    public Money {
        if (ccy == null) {
            throw new IllegalArgumentException("ccy must not be null");
        }
        if (amount == null) {
            throw new IllegalArgumentException("amount must not be null");
        }
    }

    public Money(String ccy, BigDecimal amount) {
        this(Currency.valueOf(ccy), amount);
    }

    public Money(String ccy, String amount) {
        this(Currency.valueOf(ccy), new BigDecimal(amount));
    }

    public Money(Currency ccy, String amount) {
        this(ccy, new BigDecimal(amount));
    }

    public Money combine(Money other, BiFunction<BigDecimal, BigDecimal, BigDecimal> amountOperation) {
        if (!ccy.equals(other.ccy())) {
            throw new IllegalArgumentException(
                    "Add operation not allowed for different currencies: %s, %s.".formatted(this, other)
            );
        }
        return new Money(ccy, amountOperation.apply(amount, other.amount));
    }

    public Money add(Money other) {
        return combine(other, BigDecimal::add);
    }

    public Money subtract(Money other) {
        return combine(other, BigDecimal::subtract);
    }

    public Money with(Function<BigDecimal, BigDecimal> amountOperation) {
        return new Money(ccy, amountOperation.apply(amount));
    }

    @Override
    public String toString() {
        return "Money[%s%s]".formatted(amount.toPlainString(), ccy);
    }
}
