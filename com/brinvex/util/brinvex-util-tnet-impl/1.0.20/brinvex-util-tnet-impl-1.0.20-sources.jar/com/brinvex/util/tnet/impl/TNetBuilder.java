package com.brinvex.util.tnet.impl;

import com.brinvex.util.tnet.api.TNetException;
import com.brinvex.util.tnet.api.TNetPoolInitMode;

import java.time.Duration;

public class TNetBuilder {

    private TNetPoolInitMode poolInitMode = TNetPoolInitMode.ONE_EAGER;
    private int maxPoolSize = 2;
    private String socksProxyHost = "127.0.0.1";
    private int socksProxyBasePort = 9050;
    private int socksProxyPortOffset = 1;
    private Duration pollTimeout = Duration.ofSeconds(60);
    private String dockerEngineAddress = "http://127.0.0.1:2375";
    private String proxyServerDockerContNamePattern = null;
    private boolean healthcheckAtStartup = true;

    public TNetPoolInitMode getPoolInitMode() {
        return poolInitMode;
    }

    public TNetBuilder setPoolInitMode(TNetPoolInitMode poolInitMode) {
        this.poolInitMode = poolInitMode;
        return this;
    }

    public TNetBuilder setMaxPoolSize(int maxPoolSize) {
        this.maxPoolSize = maxPoolSize;
        return this;
    }

    public TNetBuilder setSocksProxyBasePort(int socksProxyBasePort) {
        this.socksProxyBasePort = socksProxyBasePort;
        return this;
    }

    public TNetBuilder setDockerEngineAddress(String dockerEngineAddress) {
        this.dockerEngineAddress = dockerEngineAddress;
        return this;
    }

    public TNetBuilder setSocksProxyHost(String socksProxyHost) {
        this.socksProxyHost = socksProxyHost;
        return this;
    }

    public TNetBuilder setSocksProxyPortOffset(int socksProxyPortOffset) {
        this.socksProxyPortOffset = socksProxyPortOffset;
        return this;
    }

    public TNetBuilder setPollTimeout(Duration pollTimeout) {
        this.pollTimeout = pollTimeout;
        return this;
    }

    public TNetBuilder setProxyServerDockerContNamePattern(String proxyServerDockerContNamePattern) {
        this.proxyServerDockerContNamePattern = proxyServerDockerContNamePattern;
        return this;
    }

    public TNetBuilder setHealthcheckAtStartup(boolean healthcheckAtStartup) {
        this.healthcheckAtStartup = healthcheckAtStartup;
        return this;
    }

    public TNetImpl build() throws TNetException {
        return new TNetImpl(
                poolInitMode,
                maxPoolSize,
                dockerEngineAddress,
                socksProxyHost,
                socksProxyBasePort,
                socksProxyPortOffset,
                pollTimeout,
                proxyServerDockerContNamePattern,
                healthcheckAtStartup
        );
    }
}