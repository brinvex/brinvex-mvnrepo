package com.brinvex.fintypes.vo;

import com.brinvex.fintypes.enu.Currency;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDate;

public record DateMoney(
        LocalDate date,
        Money money
) implements Serializable {
    public DateMoney {
        if (date == null) {
            throw new IllegalArgumentException("date must not be null");
        }
        if (money == null) {
            throw new IllegalArgumentException("money must not be null");
        }
    }

    public DateMoney(LocalDate date, Currency ccy, BigDecimal amount) {
        this(date, new Money(ccy, amount));
    }

    public DateMoney(LocalDate date, String ccy, BigDecimal amount) {
        this(date, new Money(ccy, amount));
    }

    public DateMoney(LocalDate date, Currency ccy, String amount) {
        this(date, new Money(ccy, amount));
    }

    public DateMoney(LocalDate date, String ccy, String amount) {
        this(date, new Money(ccy, amount));
    }

    public DateAmount toDateAmount() {
        return new DateAmount(date, money.amount());
    }

    @Override
    public String toString() {
        return "DateMoney{%s/%s}".formatted(date, money);
    }
}
