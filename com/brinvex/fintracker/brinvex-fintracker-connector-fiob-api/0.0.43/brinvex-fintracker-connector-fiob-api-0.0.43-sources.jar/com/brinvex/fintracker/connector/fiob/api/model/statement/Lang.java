package com.brinvex.fintracker.connector.fiob.api.model.statement;

public enum Lang {

    CZ,

    EN,

    SK
}
