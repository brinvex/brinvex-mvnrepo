package com.brinvex.util.fiobank.api.model;


public enum Country {

    US(Currency.USD),

    CZ(Currency.CZK),

    DE(Currency.EUR),
    ;

    private final Currency ccy;

    Country(Currency ccy) {
        this.ccy = ccy;
    }

    public Currency getCcy() {
        return ccy;
    }
}
