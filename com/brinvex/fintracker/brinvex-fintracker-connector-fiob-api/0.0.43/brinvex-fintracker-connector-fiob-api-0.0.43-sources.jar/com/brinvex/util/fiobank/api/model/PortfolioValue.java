package com.brinvex.util.fiobank.api.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.StringJoiner;

public class PortfolioValue implements Serializable {

    private LocalDate day;

    private BigDecimal totalValue;

    private Currency currency;

    public LocalDate getDay() {
        return day;
    }

    public void setDay(LocalDate day) {
        this.day = day;
    }

    public BigDecimal getTotalValue() {
        return totalValue;
    }

    public void setTotalValue(BigDecimal totalValue) {
        this.totalValue = totalValue;
    }

    public Currency getCurrency() {
        return currency;
    }

    public void setCurrency(Currency currency) {
        this.currency = currency;
    }

    @Override
    public String toString() {
        return new StringJoiner(", ", PortfolioValue.class.getSimpleName() + "[", "]")
                .add("day=" + day)
                .add("totalValue=" + totalValue)
                .add("currency=" + currency)
                .toString();
    }
}
