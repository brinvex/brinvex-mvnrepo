package com.brinvex.finance.types.enu;

/**
 * Represents the supported currencies used in financial transactions.
 * Each currency is identified by its ISO 4217 currency code.
 * Additional currencies can be added as needed to support more markets or instruments.
 */
public enum Currency {

    /**
     * Czech Koruna - The official currency of the Czech Republic.
     */
    CZK,

    /**
     * Euro - The official currency of the Eurozone, used by many European countries.
     */
    EUR,

    /**
     * United States Dollar - The official currency of the United States.
     */
    USD,

}
