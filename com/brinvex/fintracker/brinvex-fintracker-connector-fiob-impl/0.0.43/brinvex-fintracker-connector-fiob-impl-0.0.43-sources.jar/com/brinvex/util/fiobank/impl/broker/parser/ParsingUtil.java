package com.brinvex.util.fiobank.impl.broker.parser;

import com.brinvex.util.fiobank.api.model.Currency;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class ParsingUtil {

    private static class DateFormat {
        private static final DateTimeFormatter DAY_HOUR_MINUTE = DateTimeFormatter.ofPattern("dd.MM.yyyy HH:mm");
        private static final DateTimeFormatter DAY = DateTimeFormatter.ofPattern("d.M.yyyy");
    }

    public static LocalDateTime toLocalDateTime(String s, DateTimeFormatter dtf) {
        return s == null || s.isBlank() ? null : LocalDateTime.parse(s, dtf);
    }

    public static LocalDateTime toFioDateTime(String s) {
        return toLocalDateTime(s, DateFormat.DAY_HOUR_MINUTE);
    }

    public static LocalDate toLocalDate(String s, DateTimeFormatter dtf) {
        return s == null || s.isBlank() ? null : LocalDate.parse(s, dtf);
    }

    public static LocalDate toFioDate(String s) {
        return toLocalDate(s, DateFormat.DAY);
    }

    public static BigDecimal toDecimal(String s) {
        return s == null || s.isBlank() ? null : new BigDecimal(s.replace(" ", "").replace(',', '.'));
    }

    public static Currency toCurrency(String s) {
        if (s == null || s.isBlank()) {
            return null;
        }
        s = s.trim();
        for (Currency ccy : Currency.values()) {
            if (ccy.name().equalsIgnoreCase(s)) {
                return ccy;
            }
        }
        return null;
    }

}
