module com.brinvex.metamodelgen.processor {
    exports com.brinvex.metamodelgen.processor;
    requires java.compiler;
    requires java.desktop;
}