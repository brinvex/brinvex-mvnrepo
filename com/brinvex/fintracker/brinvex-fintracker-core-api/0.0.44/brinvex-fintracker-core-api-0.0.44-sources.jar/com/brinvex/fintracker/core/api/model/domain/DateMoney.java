package com.brinvex.fintracker.core.api.model.domain;

import com.brinvex.fintracker.core.api.model.general.DateAmount;

import java.math.BigDecimal;
import java.time.LocalDate;

import static java.util.Objects.requireNonNull;

public record DateMoney(
        LocalDate date,
        Money money
) {
    public DateMoney {
        requireNonNull(date);
        requireNonNull(money);
    }

    public DateMoney(LocalDate date, String ccy, BigDecimal amount) {
        this(date, new Money(ccy, amount));
    }

    public DateAmount toDateAmount() {
        return new DateAmount(date, money.amount());
    }
}
