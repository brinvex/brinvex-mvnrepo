package com.brinvex.fintracker.connector.fiob.api;

import com.brinvex.fintracker.connector.fiob.api.service.FiobDms;
import com.brinvex.fintracker.connector.fiob.api.service.FiobFetcher;
import com.brinvex.fintracker.connector.fiob.api.service.FiobFinTransactionMapper;
import com.brinvex.fintracker.connector.fiob.api.service.FiobPtfProgressProvider;
import com.brinvex.fintracker.connector.fiob.api.service.FiobStatementMerger;
import com.brinvex.fintracker.connector.fiob.api.service.FiobStatementParser;
import com.brinvex.fintracker.core.api.FinTrackerModule;

public interface FiobModule extends FinTrackerModule {

    FiobFetcher fetcher();

    FiobStatementParser statementParser();

    FiobStatementMerger statementMerger();

    FiobDms dms();

    FiobFinTransactionMapper finTransactionMapper();

    FiobPtfProgressProvider ptfProgressProvider();


}
