package com.brinvex.fintracker.connector.rvlt.api.service;

import com.brinvex.fintracker.core.api.domain.vo.Account;
import com.brinvex.fintracker.core.api.provider.PtfProgressProvider;

import java.time.LocalDate;

public interface RvltPtfProgressProvider extends PtfProgressProvider {

    PtfProgress getPtfProgress(
            Account account,
            LocalDate fromDateIncl,
            LocalDate toDateIncl
    );
}
