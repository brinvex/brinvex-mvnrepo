package com.brinvex.fintracker.connector.amnd.api;

import com.brinvex.fintracker.connector.amnd.api.service.AmndDms;
import com.brinvex.fintracker.connector.amnd.api.service.AmndFinTransactionMapper;
import com.brinvex.fintracker.connector.amnd.api.service.AmndPtfProgressProvider;
import com.brinvex.fintracker.connector.amnd.api.service.AmndStatementParser;
import com.brinvex.fintracker.core.api.FinTrackerModule;

public interface AmndModule extends FinTrackerModule {

    AmndStatementParser statementParser();

    AmndDms dms();

    AmndFinTransactionMapper finTransactionMapper();

    AmndPtfProgressProvider ptfProgressProvider();

}
