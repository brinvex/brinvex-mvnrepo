package com.brinvex.fintracker.connector.amnd.api.service;

import com.brinvex.fintracker.core.api.provider.PtfProgressProvider;

import java.math.BigDecimal;
import java.time.LocalDate;

public interface AmndPtfProgressProvider extends PtfProgressProvider {

    /**
     * @param initialFeeReserve Represents the initial fee amount paid upfront at the start of the investment.
     *                          This value is reserved to be distributed incrementally across multiple subsequent
     *                          transactions, such as deposits and withdrawals.
     *                          <p>
     *                          Instead of associating the full fee amount with the initial transaction,
     *                          we use this reserve as a base to allocate smaller portions of the fee
     *                          to relevant transactions over time.
     *                          <p>
     *                          This technique helps mitigate the disturbing effect of a large initial fee
     *                          when calculating investment performance.
     */
    PtfProgress getPtfProgress(
            String accountId,
            BigDecimal initialFeeReserve,
            LocalDate fromDateIncl,
            LocalDate toDateIncl
    );

}
