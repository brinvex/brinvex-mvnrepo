/*
 * Copyright © 2023 Brinvex (dev@brinvex.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.brinvex.util.ibkr.api.extension;

import com.brinvex.util.ibkr.api.model.Currency;
import com.brinvex.util.ibkr.api.model.FinTransaction;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.StringJoiner;

public class Portfolio implements Serializable {
    private final String accountId;
    private final List<Holding> holdings = new ArrayList<>();
    private final Map<Currency, BigDecimal> wallets = new LinkedHashMap<>();
    private final List<FinTransaction> transactions = new ArrayList<>();

    public Portfolio(String accountId) {
        this.accountId = accountId;
    }

    public String getAccountId() {
        return accountId;
    }

    public List<Holding> getHoldings() {
        return holdings;
    }

    public Map<Currency, BigDecimal> getWallets() {
        return wallets;
    }

    public List<FinTransaction> getTransactions() {
        return transactions;
    }

    @Override
    public String toString() {
        return new StringJoiner(", ", Portfolio.class.getSimpleName() + "[", "]")
                .add("accountId='" + accountId + "'")
                .add("holdings=" + holdings)
                .add("wallets=" + wallets)
                .add("transactions=" + transactions)
                .toString();
    }
}
