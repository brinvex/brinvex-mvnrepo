package com.brinvex.fintracker.connector.fiob.api.service;

import com.brinvex.fintracker.core.api.domain.dto.Account;

import java.time.LocalDate;

public interface FiobFetcher {

    String fetchTransStatement(
            Account account,
            LocalDate fromDateIncl,
            LocalDate toDateIncl
    );

    String fetchSnapshotStatement(
            Account account,
            LocalDate date
    );

    FiobFetcher newSessionReusingFetcher();
}
