package com.brinvex.util.ibkr.api.model;

import com.brinvex.util.ibkr.api.model.statement.FlexStatementType;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.Comparator;

public record DocKey(
        String accountId,
        FlexStatementType statementType,
        LocalDate fromDayIncl,
        LocalDate toDayIncl
) implements Comparable<DocKey>, Serializable {

    private static final Comparator<DocKey> COMPARATOR =
            Comparator.comparing(DocKey::accountId)
                    .thenComparing(DocKey::statementType)
                    .thenComparing(DocKey::fromDayIncl)
                    .thenComparing(DocKey::toDayIncl);

    public DocKey {
        if (accountId == null || accountId.isEmpty()) {
            throw new IllegalArgumentException("accountId cannot be null or empty");
        }
        if (statementType == null) {
            throw new IllegalArgumentException("statementType cannot be null");
        }
        if (fromDayIncl == null) {
            throw new IllegalArgumentException("fromDayIncl cannot be null");
        }
        if (toDayIncl == null) {
            throw new IllegalArgumentException("toDayIncl cannot be null");
        }
        if (fromDayIncl.isAfter(toDayIncl)) {
            throw new IllegalArgumentException("fromDayIncl cannot be after toDayIncl");
        }
    }

    @Override
    public int compareTo(DocKey other) {
        return COMPARATOR.compare(this, other);
    }
}
