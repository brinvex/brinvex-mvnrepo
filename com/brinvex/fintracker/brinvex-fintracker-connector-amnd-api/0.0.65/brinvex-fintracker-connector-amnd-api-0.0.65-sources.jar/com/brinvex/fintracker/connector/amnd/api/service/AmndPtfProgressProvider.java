package com.brinvex.fintracker.connector.amnd.api.service;

import com.brinvex.fintracker.core.api.domain.dto.Account;
import com.brinvex.fintracker.core.api.provider.PtfProgressProvider;

import java.time.LocalDate;

public interface AmndPtfProgressProvider extends PtfProgressProvider {

    PtfProgress getPtfProgress(
            Account account,
            LocalDate fromDateIncl,
            LocalDate toDateIncl
    );

}
