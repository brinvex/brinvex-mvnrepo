/*
 * Copyright © 2023 Brinvex (dev@brinvex.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.brinvex.util.ibkr.api.service;

import java.time.Duration;

public interface IbkrFetcher {

    /**
     * See also
     * <a href="https://www.interactivebrokers.co.in/en/?f=asr_statements_tradeconfirmations&p=flexqueries4">
     * https://www.interactivebrokers.co.in/en/?f=asr_statements_tradeconfirmations&p=flexqueries4</a>
     *
     * @param estimatedRemoteInProgressTime as of 2024-08-11 it seems that the minimal time period needed
     *                                      to prevent the error '1019 Statement generation in progress. Please try again shortly.' is:
     *                                      4s for an ActivityFlexStatement
     *                                      0s for a TradeConfirmation
     */
    String fetchFlexStatement(String token, String flexQueryId, int maxRepeatCount, Duration estimatedRemoteInProgressTime);

    static IbkrFetcher create() {
        return create(HttpClientFacade.create());
    }

    static IbkrFetcher create(HttpClientFacade httpClientFacade) {
        try {
            return (IbkrFetcher) Class.forName("com.brinvex.util.ibkr.impl.IbkrFetcherImpl")
                    .getConstructor(HttpClientFacade.class)
                    .newInstance(httpClientFacade);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}
