package com.brinvex.fintracker.core.impl.dao;

import com.brinvex.fintracker.core.impl.ent.AccountEnt;
import jakarta.persistence.EntityManager;

import java.util.function.Supplier;

public class AccountDao extends BaseDao<AccountEnt, Long> {

    protected AccountDao(Supplier<EntityManager> entityManagerSupplier) {
        super(AccountEnt.class, Long.class, entityManagerSupplier);
    }
}
