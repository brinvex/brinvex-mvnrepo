package com.brinvex.fintracker.connector.rvlt.api.model.statement;

public enum TransactionSide {

    BUY,

    SELL,
}
