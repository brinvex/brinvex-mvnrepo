package com.brinvex.metamodelgen.processor.internal.model;

public interface ImportContext {

    String importType(String fqcn);

    String generateImports();
}
