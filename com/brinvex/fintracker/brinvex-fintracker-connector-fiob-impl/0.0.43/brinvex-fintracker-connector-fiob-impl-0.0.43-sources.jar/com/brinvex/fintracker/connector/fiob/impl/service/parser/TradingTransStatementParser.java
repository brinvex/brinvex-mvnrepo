package com.brinvex.fintracker.connector.fiob.impl.service.parser;

import com.brinvex.fintracker.connector.fiob.api.model.statement.Lang;
import com.brinvex.fintracker.connector.fiob.api.model.statement.Statement;
import com.brinvex.fintracker.connector.fiob.api.model.statement.TradingTransaction;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class TradingTransStatementParser {

    @SuppressWarnings("SpellCheckingInspection")
    public Statement.TradingTransStatement parseTransStatement(String transStatementCsvContent) {
        List<String> lines = transStatementCsvContent.lines().toList();

        String accountId = null;
        LocalDate periodFrom = null;
        LocalDate periodTo = null;
        Lang lang = null;
        Map<TradingTransColumnParser, Integer> headers = null;


        List<TradingTransaction> trans = new ArrayList<>();
        for (int i = 0, linesSize = lines.size(); i < linesSize; i++) {
            String line = lines.get(i).trim();
            if (line.isEmpty()) {
                continue;
            }
            try {

                if (accountId == null) {
                    Matcher matcher = Lazy.ACCOUNT_NUMBER_PATTERN.matcher(line);
                    if (!matcher.find()) {
                        throw new IllegalStateException("%s - Could not parse account number: '%s'".formatted(i + 1, line));
                    }
                    accountId = matcher.group("accountNumber");

                    if (line.startsWith("Overview")) {
                        lang = Lang.EN;
                    } else if (line.startsWith("Přehled")) {
                        lang = Lang.CZ;
                    } else if (line.startsWith("Prehľad")) {
                        lang = Lang.SK;
                    } else {
                        throw new IllegalStateException("%s - Could not detect lang: '%s'".formatted(i + 1, line));
                    }
                    i++; // Skip "Created:" line
                    continue;
                }
                if (periodFrom == null) {
                    Matcher matcher = Lazy.PERIOD_PATTERN.matcher(line);
                    if (!matcher.find()) {
                        throw new IllegalStateException("%s - Could not parse period: '%s'".formatted(i + 1, line));
                    }
                    periodFrom = LocalDate.parse(matcher.group("periodFrom"), Lazy.PERIOD_DF);
                    periodTo = LocalDate.parse(matcher.group("periodTo"), Lazy.PERIOD_DF);
                    continue;
                }

                if (headers == null) {
                    headers = new LinkedHashMap<>();
                    String[] headerTitles = Lazy.COLUMN_DELIMITER_PATTERN.split(line, -1);
                    for (int j = 0, headerTitlesLength = headerTitles.length; j < headerTitlesLength; j++) {
                        String headerTitle = headerTitles[j];
                        TradingTransColumnParser columnParser = TradingTransColumnParser.ofTitle(headerTitle, lang);
                        if (columnParser == null) {
                            continue;
                        }
                        headers.put(columnParser, j);
                    }
                    Set<TradingTransColumnParser> missingHeaders = new LinkedHashSet<>(TradingTransColumnParser.STANDARD_COLUMNS);
                    missingHeaders.removeAll(headers.keySet());
                    if (!missingHeaders.isEmpty()) {
                        throw new IllegalStateException("%s - Mising mandatory headers: %s, line='%s'".formatted(i + 1, missingHeaders, line));
                    }
                    continue;
                }

                TradingTransaction.TradingTransactionBuilder tranBuilder = TradingTransaction.builder();
                tranBuilder.lang(lang);
                {
                    List<String> cells = List.of(Lazy.COLUMN_DELIMITER_PATTERN.split(line, -1));
                    if (cells.getFirst().isBlank()) {
                        //"Total" row without a date
                        continue;
                    }
                    for (Map.Entry<TradingTransColumnParser, Integer> e : headers.entrySet()) {
                        TradingTransColumnParser columnDef = e.getKey();
                        Integer index = e.getValue();
                        String cell = cells.get(index);
                        cell = cell.trim();
                        columnDef.fill(tranBuilder, cell, lang);
                    }
                }
                trans.add(tranBuilder.build());
            } catch (Exception e) {
                throw new RuntimeException("%s - '%s'".formatted(i + 1, line), e);
            }
        }

        return new Statement.TradingTransStatement(
                accountId,
                periodFrom,
                periodTo,
                trans
        );
    }

    private static class Lazy {
        private static final Pattern COLUMN_DELIMITER_PATTERN = Pattern.compile(";");
        private static final Pattern ACCOUNT_NUMBER_PATTERN = Pattern.compile(".*:\\s+(?<accountNumber>\\d+)\"");
        private static final Pattern PERIOD_PATTERN = Pattern.compile(".*:\\s+(?<periodFrom>\\d{1,2}\\.\\d{1,2}\\.\\d{4})\\s+-\\s+(?<periodTo>\\d{1,2}\\.\\d{1,2}\\.\\d{4})");

        private static final DateTimeFormatter PERIOD_DF = DateTimeFormatter.ofPattern("d.M.yyyy");
    }

}
