package com.brinvex.fintracker.core.impl.provider.ptfprogress;

import com.brinvex.fintracker.core.api.domain.vo.Asset;
import com.brinvex.fintracker.core.api.domain.enu.AssetType;
import com.brinvex.fintracker.core.api.domain.enu.Currency;
import com.brinvex.fintracker.core.api.domain.vo.FinTransaction;
import com.brinvex.fintracker.core.api.domain.vo.FinTransaction.FinTransactionBuilder;
import com.brinvex.fintracker.core.api.domain.enu.FinTransactionType;
import com.brinvex.fintracker.core.api.provider.PtfProgressProvider;
import com.brinvex.util.dms.api.Dms;
import com.brinvex.util.java.StringUtil;
import com.brinvex.util.java.csv.CsvConfig;
import com.brinvex.util.java.csv.CsvTable;
import com.brinvex.util.java.validation.Assert;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static com.brinvex.util.java.NullUtil.nullSafe;
import static com.brinvex.util.java.StringUtil.stripToNull;

public class PtfProgressProviderImpl implements PtfProgressProvider {

    private final Dms dms;

    public PtfProgressProviderImpl(Dms dms) {
        this.dms = dms;
    }

    @Override
    public boolean supports(PtfProgressReq ptfProgressReq) {
        String reqPtfProgressProvider = ptfProgressReq.providerName();
        return reqPtfProgressProvider == null || reqPtfProgressProvider.equals("core");
    }

    @Override
    public PtfProgress process(PtfProgressReq ptfProgressReq) {
        Assert.isTrue(supports(ptfProgressReq));
        String ptfName = ptfProgressReq.ptfProps().get("name");
        LocalDate fromDateIncl = ptfProgressReq.fromDateIncl();
        LocalDate toDateIncl = ptfProgressReq.toDateIncl();
        List<String> transCsvLines = dms.getTextLines(ptfName, ptfName + "_transactions.csv");
        List<FinTransaction> finTrans = parseFinTransactions(transCsvLines, fromDateIncl, toDateIncl);
        return new PtfProgress(finTrans, null);
    }

    private static List<FinTransaction> parseFinTransactions(List<String> transCsvLines, LocalDate fromDateIncl, LocalDate toDateIncl) {
        CsvTable csvTable = CsvTable.of(transCsvLines, CsvConfig.builder()
                .separator(',')
                .quoteCharacter('"')
                .build());

        List<FinTransaction> finTrans = new ArrayList<>();
        for (int br = 0; br < csvTable.bodySize(); br++) {
            Map<String, String> row = csvTable.bodyRow(br);
            LocalDate date = LocalDate.parse(row.get("date"));
            if (date.isBefore(fromDateIncl) || date.isAfter(toDateIncl)) {
                continue;
            }
            FinTransactionBuilder tranBuilder = FinTransaction.builder();
            tranBuilder.date(date);
            tranBuilder.id(stripToNull(row.get("id")));
            tranBuilder.type(FinTransactionType.valueOf(row.get("type")));
            tranBuilder.ccy(nullSafe(row.get("ccy"), StringUtil::stripToNull, Currency::valueOf));
            tranBuilder.netValue(nullSafe(row.get("netValue"), StringUtil::stripToNull, BigDecimal::new));
            tranBuilder.qty(nullSafe(row.get("qty"), StringUtil::stripToNull, BigDecimal::new));
            tranBuilder.price(nullSafe(row.get("price"), StringUtil::stripToNull, BigDecimal::new));

            AssetType assetType = nullSafe(row.get("asset_type"), StringUtil::stripToNull, AssetType::valueOf);
            if (assetType != null) {
                Asset.AssetBuilder assetBuilder = Asset.builder();
                assetBuilder.id(stripToNull(row.get("asset_id")));
                assetBuilder.type(assetType);
                assetBuilder.country(stripToNull(row.get("asset_country")));
                assetBuilder.symbol(stripToNull(row.get("asset_symbol")));
                assetBuilder.name(stripToNull(row.get("asset_name")));
                assetBuilder.countryFigi(stripToNull(row.get("asset_countryFigi")));
                assetBuilder.isin(stripToNull(row.get("asset_isin")));
                assetBuilder.extraType(stripToNull(row.get("asset_extraType")));
                assetBuilder.extraDetail(stripToNull(row.get("asset_extraDetail")));
                tranBuilder.asset(assetBuilder.build());
            }

            tranBuilder.grossValue(nullSafe(row.get("grossValue"), StringUtil::stripToNull, BigDecimal::new));
            tranBuilder.tax(nullSafe(row.get("tax"), StringUtil::stripToNull, BigDecimal::new));
            tranBuilder.fee(nullSafe(row.get("fee"), StringUtil::stripToNull, BigDecimal::new));
            tranBuilder.settleDate(nullSafe(row.get("settleDate"), LocalDate::parse));
            tranBuilder.groupId(stripToNull(row.get("groupId")));
            tranBuilder.extraId(stripToNull(row.get("extraId")));
            tranBuilder.extraType(stripToNull(row.get("extraType")));
            tranBuilder.extraDetail(stripToNull(row.get("extraDetail")));

            finTrans.add(tranBuilder.build());
        }
        return finTrans;
    }
}
