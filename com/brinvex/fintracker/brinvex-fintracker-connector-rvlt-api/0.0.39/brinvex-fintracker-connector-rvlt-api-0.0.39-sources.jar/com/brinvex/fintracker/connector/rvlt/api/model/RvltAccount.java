package com.brinvex.fintracker.connector.rvlt.api.model;

import java.util.Map;

public record RvltAccount(
        String accountNumber,
        String accountName
) {
    public RvltAccount {
        if (accountNumber == null || accountNumber.isBlank()) {
            throw new IllegalArgumentException("accountNumber must not be null or blank");
        }
        if (accountName == null || accountName.isBlank()) {
            throw new IllegalArgumentException("accountName must not be null or blank");
        }
    }

    public static RvltAccount of(Map<String, String> props) {
        String accountNumber = props.get("accountNumber");
        if (accountNumber == null || accountNumber.isEmpty()) {
            return null;
        }
        String accountName = props.get("accountName");
        return new RvltAccount(accountNumber, accountName);
    }

}
