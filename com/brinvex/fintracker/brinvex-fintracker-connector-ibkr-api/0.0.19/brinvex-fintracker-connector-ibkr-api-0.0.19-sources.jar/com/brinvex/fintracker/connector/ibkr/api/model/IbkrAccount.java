package com.brinvex.fintracker.connector.ibkr.api.model;

import java.time.LocalDate;
import java.util.Map;
import java.util.StringJoiner;

public record IbkrAccount(
        String accountId,
        Credentials credentials,
        MigratedAccount migratedAccount
) {

    public record Credentials(
            String token,
            String activityFlexQueryId,
            String tradeConfirmationFlexQueryId
    ) {

        public Credentials {
            if (token == null) {
                throw new IllegalArgumentException("token must not be null");
            }
            if (activityFlexQueryId == null) {
                throw new IllegalArgumentException("activityFlexQueryId must not be null");
            }
            if (tradeConfirmationFlexQueryId == null) {
                throw new IllegalArgumentException("tradeConfirmationFlexQueryId must not be null");
            }
        }

        @Override
        public String toString() {
            return new StringJoiner(", ", Credentials.class.getSimpleName() + "[", "]")
                    .add("token=%s***".formatted(token == null ? null : token.substring(0, 2)))
                    .add("activityFlexQueryId=%s***".formatted(activityFlexQueryId == null ? null : activityFlexQueryId.substring(0, 3)))
                    .add("tradeConfirmationFlexQueryId=%s***".formatted(tradeConfirmationFlexQueryId == null ? null : tradeConfirmationFlexQueryId.substring(0, 3)))
                    .toString();
        }
    }

    public record MigratedAccount(
            String oldAccountId,
            LocalDate oldAccountValidToIncl
    ) {
        public MigratedAccount {
            if (oldAccountId == null) {
                throw new IllegalArgumentException("oldAccountId must not be null");
            }
            if (oldAccountValidToIncl == null) {
                throw new IllegalArgumentException("oldAccountValidToIncl must not be null");
            }
        }
    }

    public IbkrAccount(String accountId) {
        this(accountId, null, null);
    }

    public IbkrAccount(String accountId, Credentials credentials) {
        this(accountId, credentials, null);
    }

    public IbkrAccount(String accountId, MigratedAccount migratedAccount) {
        this(accountId, null, migratedAccount);
    }

    public IbkrAccount {
        if (accountId == null || accountId.isBlank()) {
            throw new IllegalArgumentException("accountId must not be null or blank");
        }
    }

    public static IbkrAccount of(Map<String, String> props) {
        String accountId = props.get("accountId");
        String token = props.get("token");
        String activityFlexQueryId = props.get("activityFlexQueryId");
        String tradeConfirmationFlexQueryId = props.get("tradeConfirmationFlexQueryId");
        String oldAccountId = props.get("oldAccountId");
        String oldAccountValidToIncl = props.get("oldAccountValidToIncl");

        IbkrAccount account;
        if (accountId == null || accountId.isEmpty()) {
            account = null;
        } else {
            IbkrAccount.Credentials credentials;
            if (token != null && !token.isBlank()) {
                credentials = new IbkrAccount.Credentials(token, activityFlexQueryId, tradeConfirmationFlexQueryId);
            } else {
                credentials = null;
            }
            IbkrAccount.MigratedAccount migratedAccount;
            if (oldAccountId != null && !oldAccountId.isBlank()) {
                migratedAccount = new IbkrAccount.MigratedAccount(oldAccountId, LocalDate.parse(oldAccountValidToIncl));
            } else {
                migratedAccount = null;
            }
            account = new IbkrAccount(accountId, credentials, migratedAccount);
        }
        return account;
    }

}
