package com.brinvex.util.ibkr.impl.builder;

import com.brinvex.util.ibkr.api.model.Currency;
import com.brinvex.util.ibkr.api.model.statement.EquitySummary;
import lombok.Setter;
import lombok.experimental.Accessors;

import java.math.BigDecimal;
import java.time.LocalDate;

@Setter
@Accessors(fluent = true, chain = true)
public class EquitySummaryBuilder {
    private LocalDate reportDate;
    private Currency currency;
    private BigDecimal cash;
    private BigDecimal stock;
    private BigDecimal dividendAccruals;
    private BigDecimal interestAccruals;
    private BigDecimal total;

    public EquitySummary build() {
        return new EquitySummary(
                this.reportDate,
                this.currency,
                this.cash,
                this.stock,
                this.dividendAccruals,
                this.interestAccruals,
                this.total
        );
    }
}
