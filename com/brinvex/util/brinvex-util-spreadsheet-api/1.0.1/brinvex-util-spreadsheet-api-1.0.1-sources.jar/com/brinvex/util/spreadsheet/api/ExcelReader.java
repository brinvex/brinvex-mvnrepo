package com.brinvex.util.spreadsheet.api;

import java.io.InputStream;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

public interface ExcelReader {

    List<Map<String, Object>> readColumns(InputStream is, Map<String, Class<?>> columnNamesAndTypes, int rowsToSkip);

    List<Map<String, Object>> readCompactRange(InputStream is, Map<String, Class<?>> headerNamesAndTypes);

    default List<Map<String, Object>> readCompactRange(InputStream is, Collection<String> headers) {
        return readCompactRange(is, headers.stream().collect(Collectors.toMap(Function.identity(), e -> Object.class)));
    }


}
