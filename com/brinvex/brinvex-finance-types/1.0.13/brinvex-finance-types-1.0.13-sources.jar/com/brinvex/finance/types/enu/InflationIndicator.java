package com.brinvex.finance.types.enu;

public enum InflationIndicator {

    CPI,

    YOY_RATE,

    MONTH_RATE,

}
