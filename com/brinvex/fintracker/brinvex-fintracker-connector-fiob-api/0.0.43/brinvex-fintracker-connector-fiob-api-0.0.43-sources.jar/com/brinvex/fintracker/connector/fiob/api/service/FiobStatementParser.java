package com.brinvex.fintracker.connector.fiob.api.service;

import com.brinvex.fintracker.connector.fiob.api.model.statement.Statement;

public interface FiobStatementParser {

    Statement.TradingTransStatement parseTradingTransStatement(String statementCsvContent);

}
