package com.brinvex.fintracker.core.api.provider;

import com.brinvex.fintracker.core.api.domain.dto.Account;
import com.brinvex.fintracker.core.api.domain.vo.DateAmount;
import com.brinvex.fintracker.core.api.domain.dto.FinTransaction;

import java.time.Duration;
import java.time.LocalDate;
import java.util.List;
import java.util.SequencedCollection;

public interface PtfProgressProvider extends Provider<PtfProgressProvider.PtfProgressReq, PtfProgressProvider.PtfProgress> {

    record PtfProgressReq(
            String providerName,
            Account account,
            LocalDate fromDateIncl,
            LocalDate toDateIncl,
            Duration staleTolerance
    ) {
    }

    record PtfProgress(
            SequencedCollection<FinTransaction> transactions,
            SequencedCollection<DateAmount> netAssetValues
    ) {

        public PtfProgress(SequencedCollection<FinTransaction> transactions, SequencedCollection<DateAmount> netAssetValues) {
            this.transactions = transactions == null ? null : List.copyOf(transactions);
            this.netAssetValues = netAssetValues == null ? null : List.copyOf(netAssetValues);
        }
    }
}
