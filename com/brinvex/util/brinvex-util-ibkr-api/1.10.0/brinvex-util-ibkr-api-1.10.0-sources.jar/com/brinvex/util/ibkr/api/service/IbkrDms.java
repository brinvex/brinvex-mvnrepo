package com.brinvex.util.ibkr.api.service;

import com.brinvex.util.ibkr.api.model.DocKey;
import com.brinvex.util.ibkr.api.model.statement.FlexStatementType;

import java.time.LocalDate;
import java.util.List;

public interface IbkrDms {

    String getStatementContent(DocKey docKey);

    String getStatementContentIfExists(DocKey docKey);

    boolean putStatementIfUseful(DocKey docKey, String content);

    boolean putStatement(DocKey docKey, String content);

    List<DocKey> getDocKeys(FlexStatementType statementType, String accountId, LocalDate fromDayIncl, LocalDate toDayIncl);

    DocKey getUniqueDocKey(FlexStatementType statementType, String accountId, LocalDate fromDayIncl, LocalDate toDayIncl);

    void delete(DocKey docKey);

    static IbkrDms create(com.brinvex.util.dms.api.Dms dmsService) {
        try {
            return (IbkrDms) Class.forName("com.brinvex.util.ibkr.impl.IbkrDmsImpl")
                    .getConstructor(com.brinvex.util.dms.api.Dms.class)
                    .newInstance(dmsService);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

}
