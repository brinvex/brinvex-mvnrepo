package com.brinvex.fintracker.connector.fiob.impl.service;

import com.brinvex.fintracker.connector.fiob.api.model.FiobDocKey;
import com.brinvex.fintracker.connector.fiob.api.model.FiobDocKey.TradingTransDocKey;
import com.brinvex.fintracker.connector.fiob.api.service.FiobDms;
import com.brinvex.fintracker.core.api.exception.StorageException;
import com.brinvex.util.dms.api.Dms;
import com.brinvex.util.java.validation.Assert;

import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.SequencedCollection;
import java.util.SequencedSet;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static java.util.Collections.emptyMap;
import static java.util.Comparator.naturalOrder;

public class FiobDmsImpl implements FiobDms {

    private final Dms dms;

    public FiobDmsImpl(Dms dms) {
        this.dms = dms;
    }

    @Override
    public List<TradingTransDocKey> getTradingTransDocKeys(String accountId, LocalDate fromDateIncl, LocalDate toDateIncl) {
        String directory = getDirectory(accountId);
        SequencedCollection<String> rawKeys = dms.getKeys(directory);
        List<TradingTransDocKey> results = new ArrayList<>();
        for (String rawKey : rawKeys) {
            TradingTransDocKey docKey = parseTradingTransactionsDocKey(rawKey);
            if (docKey != null) {
                if (!accountId.equals(docKey.accountId())) {
                    throw new StorageException("Unexpected document '%s' in directory '%s'".formatted(rawKey, directory));
                }
                boolean outside = (toDateIncl != null && docKey.fromDateIncl().isAfter(toDateIncl)) || (fromDateIncl != null && docKey.toDateIncl().isBefore(fromDateIncl));
                if (outside) {
                    continue;
                }
                results.add(docKey);
            }
        }
        results.sort(naturalOrder());
        return results;
    }

    private TradingTransDocKey parseTradingTransactionsDocKey(String fileKey) {
        TradingTransDocKey docKey;
        Matcher m = Lazy.TRADING_TRANS_RAW_KEY_PATTERN.matcher(fileKey);
        if (m.matches()) {
            String docAccountId = m.group(1);
            LocalDate docFromDateIncl = LocalDate.parse(m.group(2), Lazy.RAW_KEY_DF);
            LocalDate docToDateIncl = LocalDate.parse(m.group(3), Lazy.RAW_KEY_DF);
            docKey = new TradingTransDocKey(docAccountId, docFromDateIncl, docToDateIncl);
        } else {
            docKey = null;
        }
        return docKey;
    }


    @Override
    public String getStatementContent(FiobDocKey docKey) {
        String directory = getDirectory(docKey.accountId());
        String fileKey = constructFileKey(docKey);
        return dms.getTextContent(directory, fileKey, Lazy.FIOB_CHARSET, StandardCharsets.UTF_8);

    }

    @Override
    public boolean putTradingTransStatement(TradingTransDocKey docKey, String content) {
        String accountId = docKey.accountId();
        String directory = getDirectory(accountId);

        List<TradingTransDocKey> tradingTransDocKeys = new ArrayList<>(getTradingTransDocKeys(accountId, docKey.fromDateIncl(), docKey.toDateIncl()));
        tradingTransDocKeys.add(docKey);
        SequencedSet<TradingTransDocKey> redundantKeys = new LinkedHashSet<>(dms.getRedundantPeriodKeys(
                tradingTransDocKeys, TradingTransDocKey::fromDateIncl, TradingTransDocKey::toDateIncl));

        boolean newSaved;
        if (!redundantKeys.remove(docKey)) {
            String newFileKey = constructFileKey(docKey);
            Assert.notNull(parseTradingTransactionsDocKey(newFileKey));
            dms.add(directory, newFileKey, content);
            newSaved = true;
        } else {
            newSaved = false;
        }
        dms.delete(directory, redundantKeys.stream().map(this::constructFileKey).toList());

        return newSaved;

    }

    @Override
    public void delete(FiobDocKey docKey) {
        String directory = getDirectory(docKey.accountId());
        String fileKey = constructFileKey(docKey);
        dms.delete(directory, fileKey);
    }

    @Override
    public void putMetaProperties(String accountId, String metaFileName, Map<String, String> metaProperties) {
        String directory = getDirectory(accountId);
        dms.put(directory, metaFileName, metaProperties);
    }

    @Override
    public Map<String, String> getMetaProperties(String accountId, String metaFileName) {
        String directory = getDirectory(accountId);
        if (dms.exists(directory, metaFileName)) {
            return Map.copyOf(dms.getPropertiesContent(directory, metaFileName));
        }
        return emptyMap();
    }

    private String constructFileKey(FiobDocKey docKey) {
        return switch (docKey) {
            case TradingTransDocKey actDocKey -> "%s-Transactions-%s-%s.csv".formatted(
                    actDocKey.accountId(),
                    Lazy.RAW_KEY_DF.format(actDocKey.fromDateIncl()),
                    Lazy.RAW_KEY_DF.format(actDocKey.toDateIncl())
            );
        };
    }

    private String getDirectory(String accountId) {
        return accountId;
    }

    private static final class Lazy {
        private static final Charset FIOB_CHARSET = Charset.forName("windows-1250");

        private static final DateTimeFormatter RAW_KEY_DF = DateTimeFormatter.ofPattern("yyyyMMdd");
        private static final Pattern TRADING_TRANS_RAW_KEY_PATTERN = Pattern.compile("(\\w{8,20})-Transactions-(\\d{8})-(\\d{8})\\.csv");
    }

}
