package com.brinvex.finance.types.enu;

/*
 * Partially inspired by IBKR SecType:
 *      STK, OPT, FUT, CONTFUT, CASH, BOND, CFD, FOP, WAR, IOPT, FWD, BAG, IND, BILL, FUND, FIXED, SLB, NEWS, CMDTY, BSK, ICU, ICS, CRYPTO;
 * Source:
 * ...\TWS_API\source\JavaClient\com\ib\client\Types.java
 * ...\TWS_API\samples\Java\samples\testbed\contracts\ContractSamples.java
 *
 *
 */
@SuppressWarnings("SpellCheckingInspection")
public enum InstrumentType {

    STK("Stock", "S"),

    ETF("ETF", "E"),

    BOND("Bond", "B"),

    FUND("Fund", "F"),

    IND("Index", "I"),

    CASH("Cash", "C"),

    DERIV("Derivative", "D"),
    ;

    private final String longName;

    private final String shortName;

    InstrumentType(String longName, String shortName) {
        this.longName = longName;
        this.shortName = shortName;
    }

    public String longName() {
        return longName;
    }

    public String shortName() {
        return shortName;
    }
}
