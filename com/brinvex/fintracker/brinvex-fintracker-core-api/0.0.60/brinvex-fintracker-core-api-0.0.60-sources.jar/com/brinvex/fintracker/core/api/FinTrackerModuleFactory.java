package com.brinvex.fintracker.core.api;

import com.brinvex.fintracker.core.api.provider.Provider;

import java.util.Set;

public interface FinTrackerModuleFactory<MODULE extends FinTrackerModule> {

    Class<MODULE> moduleType();

    Set<Class<? extends Provider<?, ?>>> providerTypes();

    MODULE createModule(FinTrackerModuleContext moduleCtx);

}
