package com.brinvex.fintracker.core.impl.domain.active;

import com.brinvex.finance.types.enu.Currency;
import com.brinvex.fintracker.core.api.domain.active.PtfRuntime;
import com.brinvex.fintracker.core.api.domain.dto.FinTransaction;

import java.math.BigDecimal;
import java.util.EnumMap;
import java.util.SequencedCollection;

public class PtfRuntimeImpl implements PtfRuntime {

    private record Holding () {

    }

    private final EnumMap<Currency, BigDecimal> cash = new EnumMap<>(Currency.class);

    @Override
    public void applyFinTransactions(SequencedCollection<FinTransaction> finTransactions) {

    }
}
