package com.brinvex.fintracker.connector.rvlt.api.service;

import com.brinvex.fintracker.connector.rvlt.api.model.statement.Transaction;
import com.brinvex.fintracker.core.api.domain.vo.FinTransaction;

import java.util.List;

public interface RvltFinTransactionMapper {

    List<FinTransaction> mapTransactions(List<Transaction> rvltTransactions);

}
