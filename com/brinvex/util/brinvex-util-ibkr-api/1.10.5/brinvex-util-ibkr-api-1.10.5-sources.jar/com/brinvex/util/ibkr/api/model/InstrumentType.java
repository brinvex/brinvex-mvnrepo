/*
 * Copyright © 2023 Brinvex (dev@brinvex.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.brinvex.util.ibkr.api.model;

import com.brinvex.util.ibkr.api.model.statement.AssetCategory;
import com.brinvex.util.ibkr.api.model.statement.AssetSubCategory;

public enum InstrumentType {

    STK_COMMON,
    STK_ADR,
    STK_REIT,
    ETF,
    CASH;

    public static InstrumentType fromAssetCategory(AssetCategory assetCategory) {
        return fromAssetCategory(assetCategory, null);
    }

    public static InstrumentType fromAssetCategory(AssetCategory assetCategory, AssetSubCategory assetSubCategory) {
        return switch (assetCategory) {
            case null -> null;
            case STK -> switch (assetSubCategory) {
                case COMMON -> STK_COMMON;
                case ADR -> STK_ADR;
                case REIT -> STK_REIT;
                case ETF -> ETF;
            };
            case CASH -> CASH;
        };
    }

}
