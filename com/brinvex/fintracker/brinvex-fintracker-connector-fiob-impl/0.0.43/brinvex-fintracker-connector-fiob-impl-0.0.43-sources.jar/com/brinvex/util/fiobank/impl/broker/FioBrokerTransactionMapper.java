package com.brinvex.util.fiobank.impl.broker;

import com.brinvex.util.fiobank.api.model.Country;
import com.brinvex.util.fiobank.api.model.Currency;
import com.brinvex.fintracker.connector.fiob.api.model.statement.Lang;
import com.brinvex.fintracker.connector.fiob.api.model.statement.TradingTransactionDirection;
import com.brinvex.util.fiobank.api.model.RawBrokerTransaction;
import com.brinvex.util.fiobank.api.model.Transaction;
import com.brinvex.util.fiobank.api.model.TransactionType;
import com.brinvex.util.fiobank.api.service.exception.FiobankServiceException;
import com.brinvex.util.fiobank.impl.broker.parser.ParsingUtil;
import com.brinvex.util.java.validation.Assert;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.LinkedList;
import java.util.List;
import java.util.Objects;
import java.util.function.Function;
import java.util.function.Supplier;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static java.lang.String.format;
import static java.math.BigDecimal.ZERO;
import static java.util.Objects.requireNonNullElse;
import static java.util.Optional.ofNullable;

@SuppressWarnings({"DuplicatedCode", "SpellCheckingInspection"})
public class FioBrokerTransactionMapper {

    private static class LazyHolder {
        private static final ZoneId FIO_TIME_ZONE = ZoneId.of("Europe/Prague");

        private static final Pattern DIVIDEND_TAX_RATE_PATTERN = Pattern.compile("\\(((čistá)|(po\\s+zdanění)),\\s+daň\\s(?<taxRate>\\d+(,\\d+)?)\\s*%\\)");

        private static final DateTimeFormatter ID_DATE_FORMAT = DateTimeFormatter.ofPattern("yyMMdd");
    }

    @SuppressWarnings("DataFlowIssue")
    public List<Transaction> mapTransactions(
            Transaction prevTran,
            List<RawBrokerTransaction> rawTransToProcess,
            Function<String, Country> symbolCountryProvider
    ) {
        RawBrokerTransaction rawTran = rawTransToProcess.removeFirst();

        LinkedList<Transaction> resultTrans = new LinkedList<>();

        LocalDateTime tranDate = rawTran.getTradeDate();
        ZonedDateTime tranZonedDate = tranDate.atZone(LazyHolder.FIO_TIME_ZONE);

        TransactionType tranType = detectTranType(rawTran);
        Country country = detectCountry(rawTran);
        BigDecimal rawValue = getValue(rawTran);
        BigDecimal fees = getFees(rawTran);
        BigDecimal qty = rawTran.getShares();
        TradingTransactionDirection direction = rawTran.getDirection();
        String symbol = rawTran.getSymbol();
        Currency ccy = rawTran.getCcy();
        String rawCcy = rawTran.getRawCurrency();
        BigDecimal price = rawTran.getPrice();
        String text = rawTran.getText();
        LocalDate settlDate = rawTran.getSettlementDate();

        TransactionType nextTranType;
        Country nextCountry;
        BigDecimal nextRawValue;
        BigDecimal nextFees;
        BigDecimal nextQty;
        TradingTransactionDirection nextDirection;
        String nextSymbol;
        Currency nextCcy;
        BigDecimal nextPrice;
        String nextText;
        {
            RawBrokerTransaction nextRawTran = rawTransToProcess.isEmpty() ? null : rawTransToProcess.getFirst();
            if (nextRawTran != null
                && tranDate.isEqual(nextRawTran.getTradeDate())
                && settlDate.isEqual(nextRawTran.getSettlementDate())
            ) {
                nextTranType = detectTranType(nextRawTran);
                nextCountry = detectCountry(nextRawTran);
                nextRawValue = getValue(nextRawTran);
                nextFees = getFees(nextRawTran);
                nextQty = nextRawTran.getShares();
                nextDirection = nextRawTran.getDirection();
                nextSymbol = nextRawTran.getSymbol();
                nextCcy = nextRawTran.getCcy();
                nextPrice = nextRawTran.getPrice();
                nextText = nextRawTran.getText();
            } else {
                nextTranType = null;
                nextCountry = null;
                nextRawValue = null;
                nextFees = null;
                nextQty = null;
                nextDirection = null;
                nextSymbol = null;
                nextCcy = null;
                nextPrice = null;
                nextText = null;
            }
        }

        Supplier<Transaction> tranInitializer = () -> {
            Transaction t = new Transaction();
            t.date(tranZonedDate.toLocalDate());
            t.settleDate(settlDate);
            t.ccy(ccy);
            t.note(text);
            t.qty(BigDecimal.ZERO);
            t.fees(BigDecimal.ZERO);
            resultTrans.add(t);
            return t;
        };

        if (tranType == TransactionType.DEPOSIT) {
            Assert.isTrue(direction == null || TradingTransactionDirection.BANK_TRANSFER.equals(direction));
            Assert.isNull(symbol);
            Assert.isNull(price);
            Assert.isTrue(qty.compareTo(ZERO) == 0);
            Assert.isTrue(rawValue.compareTo(ZERO) > 0);
            Assert.notNull(fees);
            Assert.negativeOrZero(fees);

            Transaction t = tranInitializer.get();
            t.type(TransactionType.DEPOSIT);
            t.grossValue(rawValue);
            t.netValue(rawValue.add(fees));
            t.ccy(ccy);
            t.qty(BigDecimal.ZERO);
            t.fees(fees);

        } else if (tranType == TransactionType.WITHDRAWAL) {
            Assert.isTrue(direction == null || TradingTransactionDirection.BANK_TRANSFER.equals(direction));
            Assert.isNull(symbol);
            Assert.isNull(price);
            Assert.isTrue(qty.compareTo(ZERO) == 0);
            Assert.notNull(rawValue);
            Assert.negative(rawValue);
            Assert.isTrue(fees.compareTo(ZERO) == 0);

            if (TransactionType.FEE.equals(nextTranType) && "Poplatek za převod peněz".equals(nextText)) {
                Assert.notNull(nextFees);
                Assert.notNull(nextRawValue);
                Assert.equal(nextFees, nextRawValue);
                Assert.notNull(nextFees);
                Assert.negative(nextFees);
                fees = nextFees;
                rawTransToProcess.removeFirst();
            }
            Transaction t = tranInitializer.get();
            t.type(TransactionType.WITHDRAWAL);
            t.grossValue(rawValue);
            t.netValue(rawValue.add(fees));
            t.fees(fees);

        } else if (tranType == TransactionType.BUY) {
            Assert.isTrue(direction.equals(TradingTransactionDirection.BUY));
            Assert.notNull(country);
            Assert.notNull(symbol);
            Assert.isTrue(price.compareTo(ZERO) > 0);
            Assert.isTrue(qty.compareTo(ZERO) > 0);
            Assert.notNull(ccy);
            Assert.notNull(rawValue);
            Assert.negative(rawValue);
            Assert.notNull(fees);
            Assert.negativeOrZero(fees);

            Transaction t = tranInitializer.get();
            t.type(TransactionType.BUY);
            t.grossValue(rawValue.subtract(fees));
            t.netValue(rawValue);
            t.country(country);
            t.symbol(symbol);
            t.qty(qty);
            t.price(price);
            t.fees(fees);

        } else if (tranType == TransactionType.SELL) {
            Assert.isTrue(direction.equals(TradingTransactionDirection.SELL));
            Assert.notNull(country);
            Assert.notNull(symbol);
            Assert.isTrue(price.compareTo(ZERO) > 0);
            Assert.notNull(qty);
            Assert.positiveOrZero(qty);
            Assert.notNull(ccy);
            Assert.isTrue(rawValue.compareTo(ZERO) > 0);
            Assert.notNull(fees);
            Assert.negativeOrZero(fees);

            Transaction t = tranInitializer.get();
            t.type(TransactionType.SELL);
            t.country(country);
            t.symbol(symbol);
            t.qty(qty.negate());
            t.price(price);
            t.grossValue(rawValue.subtract(fees));
            t.netValue(rawValue);
            t.fees(fees);

        } else if (tranType == TransactionType.FX_BUY) {
            Assert.isTrue(direction.equals(TradingTransactionDirection.CURRENCY_CONVERSION));
            Assert.notNull(symbol);
            Assert.isTrue(price.compareTo(ZERO) > 0);
            Assert.isTrue(qty.compareTo(ZERO) > 0);
            Assert.notNull(ccy);
            Assert.notNull(rawValue);
            Assert.negative(rawValue);
            Assert.isTrue(fees.compareTo(ZERO) == 0);

            Transaction t = tranInitializer.get();
            t.type(TransactionType.FX_BUY);
            t.grossValue(rawValue);
            t.netValue(rawValue);
            t.symbol(symbol);
            t.qty(qty);
            t.price(price);
            t.fees(fees);

        } else if (tranType == TransactionType.FX_SELL) {
            Assert.isTrue(direction.equals(TradingTransactionDirection.CURRENCY_CONVERSION));
            Assert.notNull(symbol);
            Assert.isTrue(price.compareTo(ZERO) > 0);
            Assert.isTrue(qty.compareTo(ZERO) > 0);
            Assert.notNull(ccy);
            Assert.isTrue(rawValue.compareTo(ZERO) > 0);
            Assert.isTrue(fees.compareTo(ZERO) == 0);

            Transaction t = tranInitializer.get();
            t.type(TransactionType.FX_SELL);
            t.grossValue(rawValue);
            t.netValue(rawValue);
            t.symbol(symbol);
            t.qty(qty.negate());
            t.price(price);
            t.fees(fees);

        } else if (tranType == TransactionType.CASH_DIVIDEND) {
            Assert.isNull(direction);
            Assert.notNull(symbol);
            Assert.notNull(ccy);
            Assert.notNull(BigDecimal.ONE);
            Assert.notNull(price);
            Assert.equal(BigDecimal.ONE, price);
            Assert.isTrue(qty.compareTo(ZERO) > 0);
            Assert.isTrue(rawValue.compareTo(ZERO) > 0);
            Assert.isTrue(fees.compareTo(ZERO) == 0);

            BigDecimal tax = null;
            BigDecimal grossValue = rawValue;
            if (TransactionType.TAX.equals(nextTranType) && symbol.equals(nextSymbol)) {
                Assert.notNull(ccy);
                Assert.notNull(nextCcy);
                Assert.equal(ccy, nextCcy);
                Assert.notNull(nextPrice);
                Assert.notNull(BigDecimal.ONE);
                Assert.equal(nextPrice, BigDecimal.ONE);
                Assert.isTrue(nextFees.compareTo(ZERO) == 0);
                Assert.notNull(nextRawValue);
                Assert.negative(nextRawValue);
                Assert.notNull(nextRawValue);
                Assert.notNull(nextQty);
                Assert.equal(nextRawValue, nextQty);
                tax = nextRawValue;
                rawTransToProcess.removeFirst();
            } else {
                Matcher m = LazyHolder.DIVIDEND_TAX_RATE_PATTERN.matcher(text);
                if (m.find()) {
                    BigDecimal taxRate = ParsingUtil.toDecimal(m.group("taxRate"))
                            .divide(new BigDecimal("100.00"), 6, RoundingMode.HALF_UP);
                    Assert.isTrue(taxRate.compareTo(ZERO) > 0);
                    Assert.notNull(rawValue);
                    Assert.notNull(qty);
                    Assert.equal(rawValue, qty);
                    tax = rawValue
                            .divide(BigDecimal.ONE.subtract(taxRate), 6, RoundingMode.HALF_UP)
                            .multiply(taxRate)
                            .negate()
                            .setScale(2, RoundingMode.HALF_UP);
                    grossValue = rawValue.subtract(tax);
                }
            }
            if (TransactionType.FEE.equals(nextTranType) && "Poplatek za připsání dividend".equals(nextText)) {
                Assert.notNull(nextCcy);
                Assert.notNull(ccy);
                Assert.equal(nextCcy, ccy);
                Assert.notNull(nextRawValue);
                Assert.notNull(nextFees);
                Assert.equal(nextRawValue, nextFees);
                fees = nextRawValue;
                Assert.notNull(fees);
                Assert.negative(fees);
                rawTransToProcess.removeFirst();
            }

            Transaction t = tranInitializer.get();
            t.type(TransactionType.CASH_DIVIDEND);
            t.grossValue(grossValue);
            t.netValue(grossValue.add(Objects.requireNonNullElse(tax, BigDecimal.ZERO)).add(fees));
            t.country(country);
            t.symbol(symbol);
            t.fees(fees);
            t.tax(tax);

        } else if (tranType == TransactionType.CAPITAL_DIVIDEND) {
            Assert.isTrue(symbol != null);
            Assert.isTrue(ccy != null);
            Assert.isTrue(price.compareTo(BigDecimal.ONE) == 0);
            Assert.isTrue(qty.compareTo(ZERO) > 0);
            Assert.isTrue(rawValue.compareTo(ZERO) > 0);
            Assert.isTrue(fees.compareTo(ZERO) == 0);

            Transaction t = tranInitializer.get();
            t.type(TransactionType.CAPITAL_DIVIDEND);
            t.country(country);
            t.symbol(symbol);
            t.ccy(ccy);
            t.grossValue(rawValue);
            t.netValue(rawValue);

        } else if (tranType == TransactionType.STOCK_DIVIDEND) {
            Assert.isNull(direction);
            Assert.notNull(symbol);
            Assert.notNull(BigDecimal.ONE);
            Assert.notNull(price);
            Assert.equal(BigDecimal.ONE, price);
            Assert.isTrue(qty.compareTo(ZERO) > 0);
            Assert.notNull(fees);
            Assert.negativeOrZero(fees);

            if (String.format("%s - Stock Dividend", symbol).equals(text)) {
                Assert.isTrue(fees.compareTo(ZERO) == 0);
                Assert.isNull(country);
                country = symbolCountryProvider.apply(symbol);
                Transaction t = tranInitializer.get();
                t.type(TransactionType.STOCK_DIVIDEND);
                t.country(country);
                t.symbol(symbol);
                t.qty(qty);
                t.netValue(ZERO);
                t.grossValue(ZERO);
                t.ccy(country.getCcy());
                t.fees(fees);
            } else if (String.format("%s - Finanční kompenzace - Stock Dividend", symbol).equals(text)) {
                Assert.isTrue(fees.compareTo(ZERO) == 0);
                Assert.notNull(rawValue);
                Assert.notNull(qty);
                Assert.equal(rawValue, qty);
                Assert.notNull(country);
                Transaction t = tranInitializer.get();
                t.type(TransactionType.STOCK_DIVIDEND);
                t.grossValue(rawValue);
                t.netValue(rawValue);
                t.country(country);
                t.symbol(symbol);
                t.qty(BigDecimal.ZERO);
            } else {
                throw new FiobankServiceException("Unsupported: " + text);
            }

        } else if (tranType == TransactionType.DIVIDEND_REVERSAL) {
            Assert.isNull(direction);
            Assert.notNull(country);
            Assert.notNull(symbol);
            Assert.notNull(ccy);
            Assert.notNull(BigDecimal.ONE);
            Assert.notNull(price);
            Assert.equal(BigDecimal.ONE, price);
            Assert.notNull(qty);
            Assert.negative(qty);
            Assert.notNull(rawValue);
            Assert.negative(rawValue);
            Assert.notNull(fees);
            Assert.negativeOrZero(fees);

            BigDecimal taxRefund;
            {
                Assert.isTrue(TransactionType.TAX_REFUND.equals(nextTranType));
                Assert.isTrue(symbol.equals(nextSymbol));
                Assert.isTrue(ccy.equals(nextCcy));
                Assert.isTrue(nextPrice.compareTo(BigDecimal.ONE) == 0);
                Assert.isTrue(nextFees.compareTo(ZERO) == 0);
                Assert.isTrue(nextRawValue.compareTo(ZERO) > 0);
                Assert.notNull(nextRawValue);
                Assert.notNull(nextQty);
                Assert.equal(nextRawValue, nextQty);
                taxRefund = nextRawValue;
                rawTransToProcess.removeFirst();
            }
            Transaction t = tranInitializer.get();
            t.type(TransactionType.DIVIDEND_REVERSAL);
            t.grossValue(rawValue);
            t.netValue(rawValue.add(taxRefund).add(fees));
            t.country(country);
            t.symbol(symbol);
            t.fees(fees);
            t.tax(taxRefund);

        } else if (tranType == TransactionType.FEE) {
            Assert.isNull(direction);
            Assert.isTrue(symbol != null || qty.compareTo(BigDecimal.ZERO) == 0);
            Assert.notNull(ccy);
            Assert.notNull(rawValue);
            Assert.negativeOrZero(rawValue);
            Assert.notNull(fees);
            Assert.negativeOrZero(fees);
            Assert.isTrue(price == null || price.compareTo(BigDecimal.ONE) == 0);

            BigDecimal value;
            if (fees.compareTo(BigDecimal.ZERO) == 0) {
                value = rawValue;
            } else if (rawValue.compareTo(BigDecimal.ZERO) == 0) {
                value = fees;
            } else if (rawValue.equals(fees)) {
                value = rawValue;
            } else {
                throw new FiobankServiceException(String.format("fees=%s, rawValue=%s", fees, rawValue));
            }
            if (value.compareTo(BigDecimal.ZERO) != 0) {
                Transaction t = tranInitializer.get();
                t.type(TransactionType.FEE);
                t.grossValue(BigDecimal.ZERO);
                t.netValue(value);
                t.fees(value);
                t.symbol(symbol);
                t.country(country);
            }

        } else if (tranType == TransactionType.RECLAMATION) {
            Assert.isNull(direction);
            Assert.isNull(symbol);
            Assert.isTrue(qty == null || qty.compareTo(BigDecimal.ZERO) == 0);
            Assert.notNull(ccy);
            Assert.notNull(rawValue);
            Assert.positiveOrZero(rawValue);
            Assert.isTrue(fees.compareTo(BigDecimal.ZERO) == 0 || fees.compareTo(rawValue) == 0);

            Transaction t = tranInitializer.get();
            t.type(TransactionType.RECLAMATION);
            t.price(price);
            t.grossValue(rawValue);
            t.netValue(rawValue);

        } else if (tranType == TransactionType.INSTRUMENT_CHANGE_CHILD) {
            Assert.isTrue(nextTranType == TransactionType.INSTRUMENT_CHANGE_PARENT);
            Assert.isTrue(text.equals(nextText));
            Assert.isTrue(qty.compareTo(ZERO) > 0);
            Assert.notNull(qty);
            Assert.notNull(nextQty);
            Assert.equal(qty, nextQty);
            Assert.isTrue(price.compareTo(ZERO) == 0);
            Assert.isTrue(nextPrice.compareTo(ZERO) == 0);
            Assert.isTrue(rawValue.compareTo(ZERO) == 0);
            Assert.isTrue(nextRawValue.compareTo(ZERO) == 0);
            Assert.isTrue(fees.compareTo(ZERO) == 0);
            Assert.isTrue(nextFees.compareTo(ZERO) == 0);
            Assert.isNull(country);
            Assert.isNull(nextCountry);
            Assert.isNull(ccy);
            Assert.isNull(nextCcy);

            Country positionCountry = symbolCountryProvider.apply(nextSymbol);
            Currency countryCcy = positionCountry == null ? null : positionCountry.getCcy();
            Transaction t1;
            {
                Assert.isTrue(TradingTransactionDirection.SELL.equals(nextDirection));
                t1 = tranInitializer.get();
                t1.type(TransactionType.INSTRUMENT_CHANGE_PARENT);
                t1.netValue(BigDecimal.ZERO);
                t1.grossValue(BigDecimal.ZERO);
                t1.country(positionCountry);
                t1.ccy(countryCcy);
                t1.symbol(nextSymbol);
                t1.qty(qty.negate());
                t1.id(generateTranId(t1, prevTran));
                t1.bunchId(t1.id());
            }
            {
                Assert.isTrue(TradingTransactionDirection.BUY.equals(direction));
                Transaction t2 = tranInitializer.get();
                t2.type(TransactionType.INSTRUMENT_CHANGE_CHILD);
                t2.netValue(BigDecimal.ZERO);
                t2.grossValue(BigDecimal.ZERO);
                t2.country(positionCountry);
                t2.ccy(countryCcy);
                t2.symbol(symbol);
                t2.qty(qty);
                t2.bunchId(t1.id());
            }
            rawTransToProcess.removeFirst();
        } else if (tranType == TransactionType.INSTRUMENT_CHANGE_PARENT) {
            Assert.isTrue(nextTranType == TransactionType.INSTRUMENT_CHANGE_CHILD);
            Assert.isTrue(text.equals(nextText));
            Assert.isTrue(qty.compareTo(ZERO) > 0);
            Assert.notNull(qty);
            Assert.notNull(nextQty);
            Assert.equal(qty, nextQty);
            Assert.isTrue(price.compareTo(ZERO) == 0);
            Assert.isTrue(nextPrice.compareTo(ZERO) == 0);
            Assert.isTrue(rawValue.compareTo(ZERO) == 0);
            Assert.isTrue(nextRawValue.compareTo(ZERO) == 0);
            Assert.isTrue(fees.compareTo(ZERO) == 0);
            Assert.isTrue(nextFees.compareTo(ZERO) == 0);
            Assert.isNull(ccy);
            Assert.isNull(nextCcy);

            country = symbolCountryProvider.apply(symbol);
            Currency countryCcy = country == null ? null : country.getCcy();

            if (nextCountry == null) {
                nextCountry = country;
            }

            Transaction t1;
            {
                Assert.isTrue(TradingTransactionDirection.SELL.equals(direction));
                t1 = tranInitializer.get();
                t1.type(TransactionType.INSTRUMENT_CHANGE_PARENT);
                t1.netValue(BigDecimal.ZERO);
                t1.grossValue(BigDecimal.ZERO);
                t1.country(country);
                t1.ccy(countryCcy);
                t1.symbol(symbol);
                t1.qty(qty.negate());
                t1.id(generateTranId(t1, prevTran));
                t1.bunchId(t1.id());
            }
            {
                Assert.isTrue(TradingTransactionDirection.BUY.equals(nextDirection));
                Transaction t2 = tranInitializer.get();
                t2.type(TransactionType.INSTRUMENT_CHANGE_CHILD);
                t2.netValue(BigDecimal.ZERO);
                t2.grossValue(BigDecimal.ZERO);
                t2.country(nextCountry);
                t2.ccy(countryCcy);
                t2.symbol(nextSymbol);
                t2.qty(qty);
                t2.bunchId(t1.id());
            }
            rawTransToProcess.removeFirst();
        } else if (tranType == TransactionType.TAX_REFUND) {
            Assert.isTrue(symbol != null);
            Assert.isTrue(ccy != null);
            Assert.notNull(price);
            Assert.notNull(BigDecimal.ONE);
            Assert.equal(price, BigDecimal.ONE);
            Assert.isTrue(qty.compareTo(ZERO) > 0);
            Assert.notNull(rawValue);
            Assert.notNull(qty);
            Assert.equal(rawValue, qty);
            Assert.isTrue(fees.compareTo(ZERO) == 0);
            {
                Transaction t = tranInitializer.get();
                t.type(TransactionType.TAX_REFUND);
                t.country(country);
                t.symbol(symbol);
                t.grossValue(BigDecimal.ZERO);
                t.netValue(rawValue);
                t.tax(rawValue);
            }
        } else if (tranType == TransactionType.TAX) {
            Assert.isNull(direction);
            Assert.notNull(symbol);
            Assert.notNull(ccy);
            Assert.notNull(price);
            Assert.notNull(BigDecimal.ONE);
            Assert.equal(price, BigDecimal.ONE);
            Assert.notNull(qty);
            Assert.negativeOrZero(qty);
            Assert.isTrue(rawValue.compareTo(qty) <= 0);
            Assert.isTrue(fees.compareTo(ZERO) == 0);
            {
                Transaction t = tranInitializer.get();
                t.type(TransactionType.TAX);
                t.country(country);
                t.symbol(symbol);
                t.grossValue(BigDecimal.ZERO);
                t.netValue(rawValue);
                t.tax(rawValue);
            }
        } else if (tranType == TransactionType.LIQUIDATION) {
            Assert.notNull(symbol);
            Assert.isTrue(price.compareTo(BigDecimal.ONE) == 0 || price.compareTo(BigDecimal.ZERO) == 0);
            Assert.isTrue(qty.compareTo(ZERO) > 0);
            Assert.isTrue(rawValue.compareTo(BigDecimal.ZERO) == 0 || rawValue.compareTo(qty) == 0);
            Assert.isTrue(fees.compareTo(ZERO) == 0);

            if (TransactionType.LIQUIDATION.equals(nextTranType)) {
                Assert.notNull(country);
                Assert.isTrue(nextDirection.equals(TradingTransactionDirection.SELL));
                Assert.isTrue(nextSymbol.equals(symbol));
                Assert.isTrue(nextCcy.equals(ccy));
                Assert.isTrue(nextPrice.compareTo(ZERO) == 0);
                Assert.isTrue(nextQty.compareTo(ZERO) > 0);
                Assert.isTrue(nextRawValue.compareTo(ZERO) == 0);
                Assert.isTrue(nextFees.compareTo(ZERO) == 0);
                rawTransToProcess.removeFirst();

                Transaction t = tranInitializer.get();
                t.type(TransactionType.LIQUIDATION);
                t.country(country);
                t.symbol(symbol);
                t.ccy(ccy);
                t.grossValue(qty);
                t.netValue(qty);
                t.qty(nextQty.negate());
                t.price(BigDecimal.ZERO);
            } else {
                Assert.isNull(country);
                Assert.isNull(ccy);
                country = symbolCountryProvider.apply(symbol);
                Currency countryCcy = country == null ? null : country.getCcy();

                Transaction t = tranInitializer.get();
                t.type(TransactionType.LIQUIDATION);
                t.country(country);
                t.symbol(symbol);
                t.ccy(countryCcy);
                t.grossValue(BigDecimal.ZERO);
                t.netValue(BigDecimal.ZERO);
                t.qty(qty.negate());
                t.price(BigDecimal.ZERO);

            }
        } else if (tranType == TransactionType.SPINOFF_PARENT) {
            Assert.isNull(direction);
            Assert.isNull(country);
            Assert.notNull(symbol);
            Assert.isNull(ccy);
            Assert.notNull(rawCcy);
            Assert.notNull(BigDecimal.ONE);
            Assert.notNull(price);
            Assert.equal(BigDecimal.ONE, price);
            Assert.isTrue(qty.compareTo(ZERO) > 0);
            Assert.isTrue(rawValue.compareTo(ZERO) == 0);
            Assert.isTrue(fees.compareTo(ZERO) == 0);

            country = symbolCountryProvider.apply(symbol);
            Currency positionCcy = country == null ? null : country.getCcy();

            Transaction t1;
            {
                t1 = tranInitializer.get();
                t1.type(TransactionType.SPINOFF_PARENT);
                t1.ccy(positionCcy);
                t1.country(country);
                t1.symbol(symbol);
                t1.id(generateTranId(t1, prevTran));
                t1.bunchId(t1.id());
            }
            {
                Transaction t2 = tranInitializer.get();
                t2.type(TransactionType.SPINOFF_CHILD);
                t2.ccy(positionCcy);
                t2.country(country);
                t2.symbol(rawCcy);
                t2.qty(qty);
                t2.bunchId(t1.id());
            }
        } else if (tranType == TransactionType.MERGER_CHILD) {
            Assert.isTrue(direction == TradingTransactionDirection.BUY);
            Assert.notNull(symbol);
            Assert.isNull(ccy);
            Assert.isNull(rawCcy);
            Assert.isTrue(price.compareTo(ZERO) == 0);
            Assert.isTrue(qty.compareTo(ZERO) > 0);
            Assert.isTrue(rawValue.compareTo(ZERO) == 0);
            Assert.isTrue(fees.compareTo(ZERO) == 0);

            Assert.isTrue(TransactionType.MERGER_PARENT.equals(nextTranType));
            Assert.isTrue(nextDirection == TradingTransactionDirection.SELL);
            Assert.isTrue(nextRawValue.compareTo(ZERO) == 0);
            Assert.isTrue(nextFees.compareTo(ZERO) == 0);
            Assert.isTrue(nextPrice.compareTo(ZERO) == 0);
            Assert.isTrue(nextQty.compareTo(ZERO) > 0);

            Assert.isNull(country);
            country = symbolCountryProvider.apply(nextSymbol);
            Currency countryCcy = country == null ? null : country.getCcy();
            Transaction t1;
            {
                t1 = tranInitializer.get();
                t1.type(TransactionType.MERGER_PARENT);
                t1.ccy(countryCcy);
                t1.country(country);
                t1.symbol(nextSymbol);
                t1.qty(nextQty.negate());
                t1.id(generateTranId(t1, prevTran));
                t1.bunchId(t1.id());
            }
            {
                Transaction t2 = tranInitializer.get();
                t2.type(TransactionType.MERGER_CHILD);
                t2.ccy(countryCcy);
                t2.country(country);
                t2.symbol(symbol);
                t2.qty(qty);
                t2.bunchId(t1.id());
            }
            rawTransToProcess.removeFirst();
        } else if (tranType == TransactionType.SPINOFF_VALUE) {
            Assert.isNull(direction);
            Assert.notNull(symbol);
            Assert.notNull(ccy);
            Assert.notNull(rawCcy);
            Assert.notNull(BigDecimal.ONE);
            Assert.notNull(price);
            Assert.equal(BigDecimal.ONE, price);
            Assert.notNull(rawValue);
            Assert.notNull(qty);
            Assert.equal(rawValue, qty);
            Assert.isTrue(rawValue.compareTo(ZERO) > 0);
            Assert.isTrue(fees.compareTo(ZERO) == 0);

            Assert.isTrue(TransactionType.SPINOFF_VALUE.equals(nextTranType));
            Assert.isTrue(nextDirection == null);
            Assert.isTrue(nextSymbol.equals(symbol));
            Assert.isTrue(nextRawValue.negate().equals(rawValue));
            Assert.isTrue(nextQty.negate().equals(qty));
            Assert.isTrue(nextFees.compareTo(ZERO) == 0);
            Assert.isTrue(price.compareTo(BigDecimal.ONE) == 0);
            rawTransToProcess.removeFirst();
            Transaction t1;
            {
                t1 = tranInitializer.get();
                t1.type(TransactionType.SPINOFF_VALUE);
                t1.country(country);
                t1.symbol(symbol);
                t1.grossValue(rawValue);
                t1.netValue(rawValue);
                t1.id(generateTranId(t1, prevTran));
                t1.bunchId(t1.id());
            }
            {
                Transaction t2 = tranInitializer.get();
                t2.type(TransactionType.SPINOFF_VALUE);
                t2.country(country);
                t2.symbol(symbol);
                t2.grossValue(rawValue.negate());
                t2.netValue(rawValue.negate());
                t2.bunchId(t1.id());
            }
        } else if (tranType == TransactionType.SPLIT) {
            Assert.isNull(country);
            Assert.isNull(ccy);
            country = symbolCountryProvider.apply(symbol);
            Currency countryCcy = country == null ? null : country.getCcy();

            if (TransactionType.SPLIT.equals(nextTranType) && nextSymbol.equals(symbol)) {
                Assert.isTrue(direction == TradingTransactionDirection.SELL);
                Assert.isTrue(nextDirection == TradingTransactionDirection.BUY);
                Assert.isNull(nextCcy);
                Assert.isTrue(nextPrice.compareTo(ZERO) == 0);
                Assert.isTrue(nextQty.compareTo(ZERO) > 0);
                Assert.isTrue(nextRawValue.compareTo(ZERO) == 0);
                Assert.isTrue(nextFees.compareTo(ZERO) == 0);
                qty = qty.negate().add(nextQty);
                rawTransToProcess.removeFirst();
            }
            {
                Transaction t = tranInitializer.get();
                t.type(TransactionType.SPLIT);
                t.ccy(countryCcy);
                t.grossValue(BigDecimal.ZERO);
                t.netValue(BigDecimal.ZERO);
                t.country(country);
                t.symbol(symbol);
                t.symbol(symbol);
                t.qty(qty);
            }
        } else {
            throw new FiobankServiceException(String.format("Unsupported transaction: %s", rawTran));
        }

        for (Transaction resultTran : resultTrans) {
            if (resultTran.id() == null) {
                resultTran.id(generateTranId(resultTran, prevTran));
                prevTran = resultTran;
            }
        }

        return resultTrans;
    }

    @SuppressWarnings("DuplicatedCode")
    protected BigDecimal getValue(RawBrokerTransaction rawTran) {
        Currency ccy = rawTran.getCcy();
        BigDecimal rawValue = null;
        if (ccy != null) {
            BigDecimal volUsd = rawTran.getVolumeUsd();
            BigDecimal volEur = rawTran.getVolumeEur();
            BigDecimal volCzk = rawTran.getVolumeCzk();
            if (ccy == Currency.USD) {
                Assert.isTrue(volEur == null);
                Assert.isTrue(volCzk == null);
                rawValue = volUsd;
            } else if (ccy == Currency.EUR) {
                Assert.isTrue(volUsd == null);
                Assert.isTrue(volCzk == null);
                rawValue = volEur;
            } else if (ccy == Currency.CZK) {
                Assert.isTrue(volUsd == null);
                Assert.isTrue(volEur == null);
                rawValue = volCzk;
            } else {
                throw new IllegalStateException("Unexpected value: " + ccy);
            }
        }
        return requireNonNullElse(rawValue, ZERO);
    }

    @SuppressWarnings("DuplicatedCode")
    protected BigDecimal getFees(RawBrokerTransaction rawTran) {
        Currency ccy = rawTran.getCcy();
        BigDecimal rawFees = null;
        if (ccy != null) {
            BigDecimal feesUsd = rawTran.getFeesUsd();
            BigDecimal feesEur = rawTran.getFeesEur();
            BigDecimal feesCzk = rawTran.getFeesCzk();
            if (ccy == Currency.USD) {
                Assert.isTrue(feesEur == null);
                Assert.isTrue(feesCzk == null);
                rawFees = feesUsd;
            } else if (ccy == Currency.EUR) {
                Assert.isTrue(feesUsd == null);
                Assert.isTrue(feesCzk == null);
                rawFees = feesEur;
            } else if (ccy == Currency.CZK) {
                Assert.isTrue(feesUsd == null);
                Assert.isTrue(feesEur == null);
                rawFees = feesCzk;
            } else {
                throw new IllegalStateException("Unexpected value: " + ccy);
            }
        }
        return ofNullable(rawFees).map(BigDecimal::negate).orElse(ZERO);
    }

    protected Country detectCountry(RawBrokerTransaction rawTransaction) {
        Currency ccy = rawTransaction.getCcy();
        if (ccy == null) {
            return null;
        }
        return switch (ccy) {
            case USD -> Country.US;
            case EUR -> Country.DE;
            case CZK -> Country.CZ;
        };
    }

    @SuppressWarnings({"SpellCheckingInspection", "DuplicatedCode", "RedundantIfStatement"})
    protected TransactionType detectTranType(RawBrokerTransaction tran) {
        Lang lang = tran.getLang();
        String symbol = tran.getSymbol();
        TradingTransactionDirection direction = tran.getDirection();
        String text = tran.getText();
        String market = tran.getMarket();
        if (direction == null && text.startsWith("Vloženo na účet z") && text.endsWith("Bezhotovostní vklad")) {
            return TransactionType.DEPOSIT;
        }
        if (direction == null && text.equals("Vklad Bezhotovostní vklad")) {
            return TransactionType.DEPOSIT;
        }
        if (direction == null && text.equals("v Bezhotovostní vklad")) {
            return TransactionType.DEPOSIT;
        }
        if (direction == null && text.startsWith("Převod z účtu")) {
            return TransactionType.DEPOSIT;
        }
        if (TradingTransactionDirection.BANK_TRANSFER.equals(direction) && text.startsWith("Převod na účet")) {
            return TransactionType.WITHDRAWAL;
        }

        if (TradingTransactionDirection.CURRENCY_CONVERSION.equals(direction) && text.equals("Nákup")) {
            return TransactionType.FX_BUY;
        }
        if (TradingTransactionDirection.CURRENCY_CONVERSION.equals(direction) && text.equals("Prodej")) {
            return TransactionType.FX_SELL;
        }

        if (TradingTransactionDirection.BUY.equals(direction) && text.equals("Nákup")) {
            return TransactionType.BUY;
        }
        if (TradingTransactionDirection.SELL.equals(direction) && text.equals("Prodej")) {
            return TransactionType.SELL;
        }
        if (direction == null && text.startsWith(format("%s - Dividenda", symbol))) {
            return TransactionType.CASH_DIVIDEND;
        }
        if (direction == null && text.startsWith(format("%s - Daň z divid. zaplacená", symbol))) {
            return TransactionType.TAX;
        }
        if (direction == null && text.startsWith(format("%s - Daň z dividend zaplacená", symbol))) {
            return TransactionType.TAX;
        }
        if (direction == null && text.startsWith(format("%s - Divi.", symbol))) {
            return TransactionType.CASH_DIVIDEND;
        }
        if (direction == null && text.startsWith(format("%s - Return of Principal", symbol))) {
            return TransactionType.CAPITAL_DIVIDEND;
        }
        if (direction == null && text.startsWith(format("%s - Stock Dividend", symbol))) {
            return TransactionType.STOCK_DIVIDEND;
        }
        if (direction == null && text.startsWith(format("%s - Finanční kompenzace - Stock Dividend", symbol))) {
            return TransactionType.STOCK_DIVIDEND;
        }
        if (direction == null && text.startsWith(format("%s - Oprava dividendy z", symbol))) {
            return TransactionType.DIVIDEND_REVERSAL;
        }
        if (direction == null && text.startsWith(format("%s - Tax Refund", symbol))) {
            return TransactionType.TAX_REFUND;
        }
        if (direction == null && text.startsWith(format("%s - Oprava daně z dividendy", symbol))) {
            return TransactionType.TAX_REFUND;
        }
        if (direction == null && text.startsWith(format("%s - Refundable U.S. Fed Tax Reclassified By Issuer", symbol))) {
            return TransactionType.TAX_REFUND;
        }

        if (direction == null && text.startsWith(format("%s - ADR Fee", symbol))) {
            return TransactionType.FEE;
        }
        if (direction == null && text.startsWith(format("%s - Spin-off Fair Market Value", symbol))) {
            return TransactionType.SPINOFF_VALUE;
        }
        if (direction == null && text.startsWith(format("%s - Spin-off - daň zaplacená", symbol))) {
            return TransactionType.TAX;
        }
        if (direction == null &&
            text.startsWith(format("%s - Spin-off", symbol)) &&
            !text.contains("Fair Market Value") &&
            !text.contains("daň zaplacená")
        ) {
            return TransactionType.SPINOFF_PARENT;
        }
        if (direction == null && text.startsWith(format("%s - Security Liquidated", symbol))) {
            return TransactionType.LIQUIDATION;
        }
        if (direction == TradingTransactionDirection.SELL && text.startsWith("Security Liquidated")) {
            return TransactionType.LIQUIDATION;
        }
        if (direction == null && text.startsWith("Poplatek za on-line data")) {
            return TransactionType.FEE;
        }
        if (direction == null && text.startsWith("Reklamace ")) {
            return TransactionType.RECLAMATION;
        }

        if (lang.equals(Lang.CZ) && market.equals("Poplatek")) {
            return TransactionType.FEE;
        }
        if (lang.equals(Lang.EN) && market.equals("Fee")) {
            return TransactionType.FEE;
        }
        if (lang.equals(Lang.SK) && market.equals("Poplatok")) {
            return TransactionType.FEE;
        }

        boolean transformation = false;
        if (lang.equals(Lang.CZ) && market.equals("Transformace")) {
            transformation = true;
        }
        if (lang.equals(Lang.EN) && market.equals("Transformation")) {
            transformation = true;
        }
        if (lang.equals(Lang.SK) && market.equals("Transformácia")) {
            transformation = true;
        }
        if (transformation) {
            if (text.contains("Ticker Change: ")
                || text.contains("Change of Listing: ")
                || text.contains("Change in Security ID (ISIN Change)")
            ) {
                if (TradingTransactionDirection.SELL.equals(direction)) {
                    return TransactionType.INSTRUMENT_CHANGE_PARENT;
                } else if (TradingTransactionDirection.BUY.equals(direction)) {
                    return TransactionType.INSTRUMENT_CHANGE_CHILD;
                }
            }
            if (text.contains("Split ")) {
                return TransactionType.SPLIT;
            }
            if (text.contains("Stock Merger ")) {
                if (TradingTransactionDirection.SELL.equals(direction)) {
                    return TransactionType.MERGER_PARENT;
                } else if (TradingTransactionDirection.BUY.equals(direction)) {
                    return TransactionType.MERGER_CHILD;
                }
            }
            if (text.contains("Security Deleted As Worthless")) {
                return TransactionType.LIQUIDATION;
            }

            if (text.equals(String.format("%s - Reorganization", symbol))) {
                String rawSymbol = tran.getRawSymbol();
                if (TradingTransactionDirection.SELL.equals(direction) && (symbol + "*").equals(rawSymbol)) {
                    return TransactionType.INSTRUMENT_CHANGE_PARENT;
                } else if (TradingTransactionDirection.BUY.equals(direction) && symbol.equals(rawSymbol)) {
                    return TransactionType.INSTRUMENT_CHANGE_CHILD;
                }
            }
        }

        throw new FiobankServiceException(format("Could not detect transaction type: %s", tran));
    }

    protected String generateTranId(Transaction tran, Transaction prevTran) {
        LocalDate date = tran.date();
        BigDecimal qty = tran.qty();
        BigDecimal price = tran.price();
        BigDecimal grossValue = tran.grossValue();
        TransactionType type = tran.type();
        Currency ccy = tran.ccy();
        Country country = tran.country();
        String symbol = tran.symbol();
        String id = format("%s/%s/%s/%s/%s/%s/%s/%s/%s",
                LazyHolder.ID_DATE_FORMAT.format(date),
                type,
                ccy,
                country,
                symbol,
                grossValue == null ? "" : grossValue.unscaledValue(),
                qty == null ? "" : qty.unscaledValue(),
                price == null ? "" : price.unscaledValue(),
                Objects.hashCode(tran.note())
        );
        if (prevTran != null) {
            String prevId = prevTran.id();
            LocalDate prevDate = prevTran.date();
            TransactionType prevType = prevTran.type();
            Currency prevCcy = prevTran.ccy();
            Country prevCountry = prevTran.country();
            String prevSymbol = prevTran.symbol();

            if (id.equals(prevId) ||
                (date.isEqual(prevDate)
                 && Objects.equals(type, prevType)
                 && Objects.equals(ccy, prevCcy)
                 && Objects.equals(country, prevCountry)
                 && Objects.equals(symbol, prevSymbol)
                )
            ) {
                id = id + "/" + Objects.hash(prevId);
            }
        }
        return id;
    }
}