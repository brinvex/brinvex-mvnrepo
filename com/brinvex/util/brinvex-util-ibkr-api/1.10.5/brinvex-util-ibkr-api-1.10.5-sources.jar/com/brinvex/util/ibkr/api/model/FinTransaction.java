/*
 * Copyright © 2023 Brinvex (dev@brinvex.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.brinvex.util.ibkr.api.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDate;

public record FinTransaction(
        String id,
        LocalDate reportDate,
        FinTransactionType type,
        Country country,
        String symbol,
        String isin,
        String figi,
        InstrumentType instrumentType,
        BigDecimal qty,
        Currency currency,
        BigDecimal price,
        BigDecimal grossValue,
        BigDecimal netValue,
        BigDecimal tax,
        BigDecimal fees,
        LocalDate settleDate,
        String description,
        String extraDateTimeStr
) implements Serializable {

    public FinTransaction(
            String id,
            LocalDate reportDate,
            FinTransactionType type,
            Country country,
            String symbol,
            String isin,
            String figi,
            InstrumentType instrumentType,
            BigDecimal qty,
            Currency currency,
            BigDecimal price,
            BigDecimal grossValue,
            BigDecimal netValue,
            BigDecimal tax,
            BigDecimal fees,
            LocalDate settleDate,
            String description,
            String extraDateTimeStr
    ) {
        this.id = id;
        this.reportDate = reportDate;
        this.type = type;
        this.country = country;
        this.symbol = symbol;
        this.isin = isin;
        this.figi = figi;
        this.instrumentType = instrumentType;
        this.qty = qty;
        this.currency = currency;
        this.price = price;
        this.grossValue = grossValue;
        this.netValue = netValue;
        this.tax = tax;
        this.fees = fees;
        this.settleDate = settleDate;
        this.description = description;
        this.extraDateTimeStr = extraDateTimeStr;

        if (!type.transactionIsValid(this)) {
            throw new IllegalArgumentException("Transaction is not valid: %s".formatted(this));
        }
    }
}
