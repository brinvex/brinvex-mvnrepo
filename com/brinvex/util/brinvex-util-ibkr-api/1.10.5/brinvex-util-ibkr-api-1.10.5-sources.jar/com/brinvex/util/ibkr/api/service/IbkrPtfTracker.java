/*
 * Copyright © 2023 Brinvex (dev@brinvex.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.brinvex.util.ibkr.api.service;

import com.brinvex.util.ibkr.api.model.Credentials;
import com.brinvex.util.ibkr.api.model.PtfProgress;

import java.time.Duration;
import java.time.LocalDate;

public interface IbkrPtfTracker {

    PtfProgress getPortfolioProgressOffline(
            String accountId,
            LocalDate fromDayIncl,
            LocalDate toDayIncl
    );

    PtfProgress getPortfolioProgressOnline(
            String accountId,
            Credentials credential,
            LocalDate fromDayIncl,
            LocalDate toDayIncl,
            Duration staleTolerance
    );

    static IbkrPtfTracker create(com.brinvex.util.dms.api.Dms dms) {
        return create(
                IbkrDms.create(dms),
                IbkrStatementParser.create(),
                IbkrFetcher.create(),
                IbkrStatementMerger.create(),
                IbkrTransactionMapper.create()
        );
    }

    static IbkrPtfTracker create(IbkrDms dms, IbkrStatementParser parser, IbkrFetcher fetcher, IbkrStatementMerger statementMerger, IbkrTransactionMapper transMapper) {
        try {
            return (IbkrPtfTracker) Class.forName("com.brinvex.util.ibkr.impl.IbkrPtfTrackerImpl")
                    .getConstructor(IbkrDms.class, IbkrStatementParser.class, IbkrFetcher.class, IbkrStatementMerger.class, IbkrTransactionMapper.class)
                    .newInstance(dms, parser, fetcher, statementMerger, transMapper);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}
