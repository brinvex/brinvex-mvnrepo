package com.brinvex.fintracker.connector.amnd.api.service;

import com.brinvex.fintracker.core.api.model.domain.PtfProgress;
import com.brinvex.fintracker.core.api.provider.PtfProgressProvider;

import java.time.LocalDate;

public interface AmndPtfProgressProvider extends PtfProgressProvider {

    PtfProgress getPtfProgress(
            String accountNumber,
            LocalDate fromDateIncl,
            LocalDate toDateIncl
    );

}
