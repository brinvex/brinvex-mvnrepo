package com.brinvex.fintracker.core.api.domain.constraints.asset;

import com.brinvex.fintracker.core.api.domain.dto.Asset;
import com.brinvex.fintracker.core.api.domain.enu.AssetType;
import com.brinvex.fintracker.core.api.general.Validatable;
import jakarta.validation.constraints.NotNull;

public abstract class AssetConstraints implements Validatable {

    public static AssetConstraints of(Asset asset) {
        return switch (asset.type()) {
            case CASH -> new CashConstraints(asset);
            case STOCK, ETF, FUND, BOND, DERIVATIVE -> new InstrumentConstraints(asset);
        };
    }

    private final Asset asset;

    AssetConstraints(Asset asset) {
        this.asset = asset;
    }

    public Long getId() {
        return asset.id();
    }

    @NotNull
    public AssetType getType() {
        return asset.type();
    }

    public String getCountry() {
        return asset.country();
    }

    public String getSymbol() {
        return asset.symbol();
    }

    public String getName() {
        return asset.name();
    }

    public String getCountryFigi() {
        return asset.countryFigi();
    }

    public String getIsin() {
        return asset.isin();
    }

    public String getExternalType() {
        return asset.externalType();
    }

    public String getExternalDetail() {
        return asset.externalDetail();
    }
}
