package com.brinvex.fintracker.connector.fiob.api.model;

import com.brinvex.fintracker.core.api.domain.enu.Currency;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.StringJoiner;

public record FiobAccount(
        String accountId,
        String accountName,
        Currency pcy,
        FiobAccountType type,
        String credentials
) {

    public FiobAccount {
        if (accountId == null || accountId.isBlank()) {
            throw new IllegalArgumentException("accountId must not be null or blank");
        }
        if (accountName == null || accountName.isBlank()) {
            throw new IllegalArgumentException("accountName must not be null or blank");
        }
        if (pcy == null) {
            throw new IllegalArgumentException("pcy must not be null");
        }
        if (type == null) {
            throw new IllegalArgumentException("type must not be null");
        }
        if (credentials == null || credentials.isBlank()) {
            credentials = null;
        }
    }

    public static FiobAccount of(Map<String, String> props) {
        String accountId = props.get("accountId");
        if (accountId == null || accountId.isEmpty()) {
            return null;
        }
        String accountName = props.get("accountName");
        FiobAccountType type = FiobAccountType.valueOf(props.get("type"));
        String credentials = props.get("credentials");
        Currency ccy = Currency.valueOf(props.get("pcy"));
        return new FiobAccount(accountId, accountName, ccy, type, credentials);
    }

    public Map<String, String> toProperties() {
        Map<String, String> props = new LinkedHashMap<>();
        props.put("accountId", accountId);
        props.put("accountName", accountName);
        props.put("type", type.name());
        props.put("pcy", pcy.name());
        if (credentials != null) {
            props.put("credentials", credentials);
        }
        return props;
    }

    @Override
    public String toString() {
        return new StringJoiner(", ", "FiobAccount[", "]")
                .add("%s/%s".formatted(accountId, accountName))
                .add(type.name())
                .toString();
    }
}
