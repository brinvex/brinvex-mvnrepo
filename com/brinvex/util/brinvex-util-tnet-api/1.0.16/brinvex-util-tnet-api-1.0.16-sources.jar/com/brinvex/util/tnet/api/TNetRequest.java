package com.brinvex.util.tnet.api;

import java.io.Serializable;
import java.net.URI;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;
import java.util.StringJoiner;

public class TNetRequest<REQ_BODY, RESP_BODY> implements Serializable {

    public static TNetRequest<Void, String> createGet(URI uri) {
        return new TNetRequest<>(Method.GET, uri, String.class);
    }

    public static TNetRequest<Void, byte[]> createGetBytes(URI uri) {
        return new TNetRequest<>(Method.GET, uri, byte[].class);
    }

    public static TNetRequest<String, String> createPost(URI uri) {
        return new TNetRequest<>(Method.POST, uri, String.class);
    }

    public static TNetRequest<String, byte[]> createPostReceivingBytes(URI uri) {
        return new TNetRequest<>(Method.POST, uri, byte[].class);
    }

    public float getCircuitRestartProbability() {
        return circuitRestartProbability;
    }

    public TNetRequest<REQ_BODY, RESP_BODY> setCircuitRestartProbability(float circuitRestartProbability) {
        this.circuitRestartProbability = circuitRestartProbability;
        return this;
    }

    public boolean isExtractRespHeaders() {
        return extractRespHeaders;
    }

    public TNetRequest<REQ_BODY, RESP_BODY> setExtractRespHeaders(boolean extractRespHeaders) {
        this.extractRespHeaders = extractRespHeaders;
        return this;
    }

    public Set<REQ_BODY> getErrorRespBodies() {
        return errorRespBodies;
    }

    public TNetRequest<REQ_BODY, RESP_BODY> setErrorRespBodies(Set<REQ_BODY> errorRespBodies) {
        this.errorRespBodies = errorRespBodies;
        return this;
    }

    public static class GetBytesRequest extends TNetRequest<Void, byte[]> {
        public GetBytesRequest(URI uri) {
            super(Method.GET, uri, byte[].class);
        }
    }

    public enum Method {
        GET,
        POST
    }

    /**
     * org.apache.hc.client5.http.cookie.StandardCookieSpec
     */
    public enum CookiePolicy {
        RELAXED,
        STRICT,
        IGNORE
    }

    private final Method method;

    private final URI uri;

    private final Class<RESP_BODY> respBodyType;

    private REQ_BODY body = null;

    private int repeatCount = 1;

    private Charset respCharset = StandardCharsets.UTF_8;

    private Set<Integer> toleratedErrStatusCodes = Set.of(404);

    private boolean tolerateEmptyRespBody = false;

    private Set<REQ_BODY> errorRespBodies;

    private float circuitRestartProbability = 0.0F;

    private final Map<String, Collection<Object>> headers = new LinkedHashMap<>(
            Map.of("User-Agent", Set.of("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"))
    );

    private boolean extractRespHeaders = false;

    private CookiePolicy cookiePolicy;

    private boolean useT = true;

    private TNetRequest(Method method, URI uri, Class<RESP_BODY> respBodyType) {
        this.method = method;
        this.uri = uri;
        this.respBodyType = respBodyType;
    }

    public Method getMethod() {
        return method;
    }

    public URI getUri() {
        return uri;
    }

    public Class<RESP_BODY> getRespBodyType() {
        return respBodyType;
    }

    public REQ_BODY getBody() {
        return body;
    }

    public TNetRequest<REQ_BODY, RESP_BODY> setBody(REQ_BODY body) {
        this.body = body;
        return this;
    }

    public int getRepeatCount() {
        return repeatCount;
    }

    public TNetRequest<REQ_BODY, RESP_BODY> setRepeatCount(int repeatCount) {
        this.repeatCount = repeatCount;
        return this;
    }

    public Charset getRespCharset() {
        return respCharset;
    }

    public TNetRequest<REQ_BODY, RESP_BODY> setRespCharset(Charset respCharset) {
        this.respCharset = respCharset;
        return this;
    }

    public Set<Integer> getToleratedErrStatusCodes() {
        return toleratedErrStatusCodes;
    }

    public TNetRequest<REQ_BODY, RESP_BODY> setToleratedErrStatusCodes(Set<Integer> toleratedErrStatusCodes) {
        this.toleratedErrStatusCodes = toleratedErrStatusCodes;
        return this;
    }

    public boolean isTolerateEmptyRespBody() {
        return tolerateEmptyRespBody;
    }

    public TNetRequest<REQ_BODY, RESP_BODY> setTolerateEmptyRespBody(boolean tolerateEmptyRespBody) {
        this.tolerateEmptyRespBody = tolerateEmptyRespBody;
        return this;
    }

    public TNetRequest<REQ_BODY, RESP_BODY> setHeader(String headerKey, Object headerValue) {
        headers.put(headerKey, Set.of(headerValue));
        return this;
    }

    public TNetRequest<REQ_BODY, RESP_BODY> setMultiHeader(String headerKey, Collection<Object> headerValues) {
        headers.put(headerKey, headerValues);
        return this;
    }

    public Map<String, Collection<Object>> getHeaders() {
        return headers;
    }

    public boolean isUseT() {
        return useT;
    }

    public TNetRequest<REQ_BODY, RESP_BODY> setUseT(boolean useT) {
        this.useT = useT;
        return this;
    }

    public CookiePolicy getCookiePolicy() {
        return cookiePolicy;
    }

    public TNetRequest<REQ_BODY, RESP_BODY> setCookiePolicy(CookiePolicy cookiePolicy) {
        this.cookiePolicy = cookiePolicy;
        return this;
    }

    @Override
    public String toString() {
        return new StringJoiner(", ", TNetRequest.class.getSimpleName() + "[", "]")
                .add("method=" + method)
                .add("uri=" + uri)
                .add("respBodyType=" + respBodyType)
                .add("body=" + body)
                .add("repeatCount=" + repeatCount)
                .add("respCharset=" + respCharset)
                .add("toleratedErrorStatusCodes=" + toleratedErrStatusCodes)
                .add("tolerateEmptyRespBody=" + tolerateEmptyRespBody)
                .add("errorRespBodies=" + errorRespBodies)
                .add("circuitRestartProbability=" + circuitRestartProbability)
                .add("headers=" + headers)
                .add("extractRespHeaders=" + extractRespHeaders)
                .add("useT=" + useT)
                .add("cookiePolicy=" + cookiePolicy)
                .toString();
    }
}
