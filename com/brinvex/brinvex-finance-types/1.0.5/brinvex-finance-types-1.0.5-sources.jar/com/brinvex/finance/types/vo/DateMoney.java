package com.brinvex.finance.types.vo;

import com.brinvex.finance.types.enu.Currency;

import java.math.BigDecimal;
import java.time.LocalDate;

public record DateMoney(
        LocalDate date,
        Money money
) {
    public DateMoney {
        if (date == null) {
            throw new IllegalArgumentException("date must not be null");
        }
        if (money == null) {
            throw new IllegalArgumentException("money must not be null");
        }
    }

    public DateMoney(LocalDate date, Currency ccy, BigDecimal amount) {
        this(date, new Money(ccy, amount));
    }

    public DateMoney(LocalDate date, String ccy, BigDecimal amount) {
        this(date, new Money(ccy, amount));
    }

    public DateMoney(LocalDate date, Currency ccy, String amount) {
        this(date, new Money(ccy, amount));
    }

    public DateMoney(LocalDate date, String ccy, String amount) {
        this(date, new Money(ccy, amount));
    }

    public DateAmount toDateAmount() {
        return new DateAmount(date, money.amount());
    }

    @Override
    public String toString() {
        return "DateMoney[%s/%s]".formatted(date, money);
    }
}
