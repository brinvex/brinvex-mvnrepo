module com.brinvex.metamodelgen.annotations {
    exports com.brinvex.metamodelgen.annotations;
    requires transitive java.compiler;
}