package com.brinvex.fintracker.connector.ibkr.impl;

import com.brinvex.fintracker.connector.ibkr.api.IbkrModule;
import com.brinvex.fintracker.connector.ibkr.api.service.IbkrDms;
import com.brinvex.fintracker.connector.ibkr.api.service.IbkrFetcher;
import com.brinvex.fintracker.connector.ibkr.api.service.IbkrFinTransactionMapper;
import com.brinvex.fintracker.connector.ibkr.api.service.IbkrPtfProgressProvider;
import com.brinvex.fintracker.connector.ibkr.api.service.IbkrStatementMerger;
import com.brinvex.fintracker.connector.ibkr.api.service.IbkrStatementParser;
import com.brinvex.fintracker.connector.ibkr.impl.service.IbkrDmsImpl;
import com.brinvex.fintracker.connector.ibkr.impl.service.IbkrFetcherImpl;
import com.brinvex.fintracker.connector.ibkr.impl.service.IbkrFinTransactionMapperImpl;
import com.brinvex.fintracker.connector.ibkr.impl.service.IbkrPtfProgressProviderImpl;
import com.brinvex.fintracker.connector.ibkr.impl.service.IbkrStatementMergerImpl;
import com.brinvex.fintracker.connector.ibkr.impl.service.IbkrStatementParserImpl;
import com.brinvex.fintracker.core.api.infra.FinTrackerModule;
import com.brinvex.fintracker.core.api.infra.FinTrackerModuleContext;
import com.brinvex.fintracker.core.api.infra.FinTrackerModuleFactory;
import com.brinvex.fintracker.core.api.infra.FinTrackerSupport;

public class IbkrModuleImpl implements IbkrModule, FinTrackerModule {

    public static class IbkrModuleFactory implements FinTrackerModuleFactory<IbkrModule> {

        @Override
        public Class<IbkrModule> moduleType() {
            return IbkrModule.class;
        }

        @Override
        public IbkrModule createModule(FinTrackerModuleContext moduleCtx) {
            return new IbkrModuleImpl(moduleCtx);
        }
    }

    private final FinTrackerModuleContext moduleCtx;

    public IbkrModuleImpl(FinTrackerModuleContext moduleCtx) {
        this.moduleCtx = moduleCtx;
    }

    @Override
    public FinTrackerSupport support() {
        return moduleCtx.support();
    }

    @Override
    public IbkrStatementMerger statementMerger() {
        return moduleCtx.singletonService(IbkrStatementMerger.class, IbkrStatementMergerImpl::new);
    }

    @Override
    public IbkrStatementParser statementParser() {
        return moduleCtx.singletonService(IbkrStatementParser.class, IbkrStatementParserImpl::new);
    }

    @Override
    public IbkrFinTransactionMapper finTransactionMapper() {
        return moduleCtx.singletonService(IbkrFinTransactionMapper.class, IbkrFinTransactionMapperImpl::new);
    }

    @Override
    public IbkrDms dms() {
        return moduleCtx.singletonService(IbkrDms.class, () -> new IbkrDmsImpl(moduleCtx.dms()));
    }

    @Override
    public IbkrFetcher fetcher() {
        return moduleCtx.singletonService(IbkrFetcher.class, IbkrFetcherImpl::new);
    }

    @Override
    public IbkrPtfProgressProvider ptfProgressProvider() {
        return moduleCtx.singletonService(IbkrPtfProgressProvider.class, () -> new IbkrPtfProgressProviderImpl(
                dms(),
                statementParser(),
                fetcher(),
                statementMerger(),
                finTransactionMapper(),
                support().validator()
        ));
    }
}
