/*
 * Copyright © 2023 Brinvex (dev@brinvex.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.brinvex.util.ibkr.impl.builder;

import com.brinvex.util.ibkr.api.model.statement.CashTransaction;
import com.brinvex.util.ibkr.api.model.statement.CorporateAction;
import com.brinvex.util.ibkr.api.model.statement.EquitySummary;
import com.brinvex.util.ibkr.api.model.statement.FlexStatement;
import com.brinvex.util.ibkr.api.model.statement.Trade;
import lombok.Setter;
import lombok.experimental.Accessors;

import java.time.LocalDate;
import java.time.ZonedDateTime;
import java.util.Collection;
import java.util.List;

@Setter
@Accessors(fluent = true, chain = true)
public class ActivityStatementBuilder {
    private String accountId;
    private LocalDate fromDate;
    private LocalDate toDate;
    private ZonedDateTime whenGenerated;
    private Collection<CashTransaction> cashTransactions;
    private Collection<Trade> trades;
    private Collection<CorporateAction> corporateActions;
    private Collection<EquitySummary> equitySummaries;

    public FlexStatement.ActivityStatement build() {
        return new FlexStatement.ActivityStatement(
                accountId,
                fromDate,
                toDate,
                whenGenerated,
                cashTransactions == null ? null : List.copyOf(cashTransactions),
                trades == null ? null : List.copyOf(trades),
                corporateActions == null ? null : List.copyOf(corporateActions),
                equitySummaries == null ? null : List.copyOf(equitySummaries)
        );
    }

}
