package com.brinvex.fintracker.core.api.domain.dto;

import com.brinvex.fintracker.core.api.domain.vo.DateAmount;
import com.brinvex.fintracker.core.api.domain.vo.FinTransaction;
import com.brinvex.fintracker.core.api.domain.enu.Currency;

import java.util.List;
import java.util.SequencedCollection;

public record PtfProgress(
        SequencedCollection<FinTransaction> transactions,
        SequencedCollection<DateAmount> netAssetValues,
        Currency ccy
) {

    public PtfProgress(SequencedCollection<FinTransaction> transactions, SequencedCollection<DateAmount> netAssetValues, Currency ccy) {
        this.transactions = transactions == null ? null : List.copyOf(transactions);
        this.netAssetValues = netAssetValues == null ? null : List.copyOf(netAssetValues);
        this.ccy = ccy;
    }
}

