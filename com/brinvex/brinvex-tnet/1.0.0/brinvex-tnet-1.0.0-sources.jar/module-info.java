module com.brinvex.tnet {
    exports com.brinvex.tnet.api;
    requires org.apache.httpcomponents.client5.httpclient5;
    requires org.apache.httpcomponents.core5.httpcore5;
    requires org.slf4j;
}