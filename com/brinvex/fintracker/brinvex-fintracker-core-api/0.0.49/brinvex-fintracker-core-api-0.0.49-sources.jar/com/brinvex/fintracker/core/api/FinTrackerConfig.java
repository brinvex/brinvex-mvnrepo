package com.brinvex.fintracker.core.api;

import com.brinvex.util.dms.api.DmsFactory;
import jakarta.validation.ValidatorFactory;
import lombok.Setter;
import lombok.experimental.Accessors;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.function.BiFunction;
import java.util.function.Supplier;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


/// ###### Property Naming Convention
/// ```
/// fintracker.core.abc=value1
/// fintracker.ibkr.x.y.z1=value2
/// ```
/// - *FULL_PROP_KEY*
///   The complete property key including the application prefix.
///   Example: `fintracker.core.abc`, `fintracker.ibkr.x.y.z1`
///
/// - *COMPACT_PROP_KEY*
///   The property key without the application prefix.
///   Example: `core.key1`, `ibkr.x.y.z1`
///
/// - *MODULE_PROP_KEY_PART*
///   The part of the key that identifies the module, represented as its compact name {@link FinTrackerModule#compactName(Class)}.
///   Example: `core`, `ibkr`
///
/// - *MAIN_KEY*
///   The primary name of the property.
///   Example: `key1`, `x.y.z1`
@SuppressWarnings("LombokGetterMayBeUsed")
public final class FinTrackerConfig {

    public static final String FULL_PROP_KEY_PREFIX = "fintracker.";

    private static final Pattern FULL_PROP_KEY_PATTERN = Pattern.compile("fintracker\\.(?<Module>[a-z]\\w+)\\.(?<MainKey>[\\w.]+)");

    private static final BiFunction<String, String, String> COMPACT_PROP_KEY_FORMATTER = "%s.%s"::formatted;

    public static final BiFunction<Class<? extends FinTrackerModule>, String, String> FULL_PROP_KEY_FORMATTER =
            (moduleType, key) -> "fintracker.%s.%s".formatted(FinTrackerModule.compactName(moduleType), key);

    private final Map<String, String> properties;
    private final Supplier<DmsFactory> dmsFactory;
    private final Supplier<ValidatorFactory> validatorFactory;

    private FinTrackerConfig(
            Map<String, String> properties,
            Supplier<DmsFactory> dmsFactory,
            Supplier<ValidatorFactory> validatorFactory
    ) {
        this.properties = Map.copyOf(properties);
        this.dmsFactory = dmsFactory;
        this.validatorFactory = validatorFactory;
    }

    public static FinTrackerConfigBuilder builder() {
        return new FinTrackerConfigBuilder();
    }

    public String getProperty(String moduleCompactName, String mainKey, String defaultValue) {
        return properties.getOrDefault(COMPACT_PROP_KEY_FORMATTER.apply(moduleCompactName, mainKey), defaultValue);
    }

    public Supplier<DmsFactory> getDmsFactory() {
        return dmsFactory;
    }

    public Supplier<ValidatorFactory> getValidatorFactory() {
        return validatorFactory;
    }

    @SuppressWarnings("UnusedReturnValue")
    @Accessors(fluent = true, chain = true)
    public static class FinTrackerConfigBuilder {

        private final Map<String, String> properties = new LinkedHashMap<>();

        @Setter
        private Supplier<DmsFactory> dmsFactory;

        @Setter
        private Supplier<ValidatorFactory> validatorFactory;

        private FinTrackerConfigBuilder() {
        }

        public FinTrackerConfig build() {
            return new FinTrackerConfig(properties, dmsFactory, validatorFactory);
        }

        public FinTrackerConfigBuilder setProperties(Map<String, String> fullKeyProperties) {
            for (Map.Entry<String, String> e : fullKeyProperties.entrySet()) {
                setProperty(e.getKey(), e.getValue());
            }
            return this;
        }

        public FinTrackerConfigBuilder setProperty(String fullKey, String value) {
            Matcher m = FULL_PROP_KEY_PATTERN.matcher(fullKey);
            if (m.matches()) {
                setProperty(m.group("Module"), m.group("MainKey"), value);
            } else {
                throw new IllegalArgumentException("Invalid property key: '%s'".formatted(fullKey));
            }
            return this;
        }

        public FinTrackerConfigBuilder setProperty(Class<? extends FinTrackerModule> moduleType, String mainKey, String value) {
            return setProperty(FinTrackerModule.compactName(moduleType), mainKey, value);
        }

        private FinTrackerConfigBuilder setProperty(String moduleKeyPart, String mainKey, String value) {
            if (propKeyIsInvalid(mainKey)) {
                throw new IllegalArgumentException("Invalid property mainKey: '%s'".formatted(mainKey));
            }
            properties.put(COMPACT_PROP_KEY_FORMATTER.apply(moduleKeyPart, mainKey), value);
            return this;
        }

        private boolean propKeyIsInvalid(String key) {
            return key == null
                   || key.isBlank()
                   || key.charAt(0) == '.'
                   || key.charAt(key.length() - 1) == '.'
                   || !key.trim().equals(key);
        }
    }
}
