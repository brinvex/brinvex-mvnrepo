package com.brinvex.fintracker.core.api;

import com.brinvex.fintracker.core.api.provider.Provider;

import java.util.SequencedCollection;
import java.util.function.Function;

public interface FinTrackerModule {

    SequencedCollection<Provider<?, ?>> providers(Class<? extends Provider<?, ?>> providerType);

    static String compactName(Class<? extends FinTrackerModule> moduleType) {
        return moduleType.getSimpleName().replace("Module", "").toLowerCase();
    }

    interface PropKey {
        Function<Class<?>, String> customService = serviceType -> "customService.%s".formatted(serviceType.getSimpleName());
        String dmsWorkspace = "dmsWorkspace";
    }
}
