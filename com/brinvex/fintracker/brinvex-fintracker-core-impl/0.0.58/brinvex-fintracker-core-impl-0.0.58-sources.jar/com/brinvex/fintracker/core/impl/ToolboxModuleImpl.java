package com.brinvex.fintracker.core.impl;

import com.brinvex.fintracker.core.api.FinTrackerConfig;
import com.brinvex.fintracker.core.api.facade.CacheFactory;
import com.brinvex.fintracker.core.api.facade.JsonMapperFacade;
import com.brinvex.fintracker.core.api.facade.PdfReaderFacade;
import com.brinvex.fintracker.core.api.facade.ValidatorFacade;
import com.brinvex.fintracker.core.api.ToolboxModule;
import com.brinvex.fintracker.core.api.provider.Provider;
import com.brinvex.fintracker.core.impl.facade.JsonMapperFacadeImpl;
import com.brinvex.fintracker.core.impl.facade.PdfReaderFacadeImpl;
import com.brinvex.fintracker.core.impl.facade.ValidatorFacadeImpl;
import com.brinvex.util.dms.api.DmsFactory;
import com.brinvex.util.java.validation.Validate;
import jakarta.validation.Validation;
import jakarta.validation.Validator;
import jakarta.validation.ValidatorFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.SequencedCollection;
import java.util.function.Supplier;

import static java.util.Collections.emptyList;

public class ToolboxModuleImpl implements ToolboxModule {

    private static final Logger LOG = LoggerFactory.getLogger(ToolboxModuleImpl.class);

    private final FinTrackerConfig config;

    private volatile ValidatorFacade validator;

    private volatile JsonMapperFacade jsonMapper;

    private volatile DmsFactory dmsFactory;

    private volatile PdfReaderFacade pdfReader;

    public ToolboxModuleImpl(FinTrackerConfig config) {
        Validate.notNull(config);
        this.config = config;
    }

    @Override
    public SequencedCollection<Provider<?, ?>> providers(Class<? extends Provider<?, ?>> providerType) {
        return emptyList();
    }

    @Override
    public ValidatorFacade validator() {
        if (validator == null) {
            synchronized (this) {
                if (validator == null) {
                    Supplier<Validator> jakartaValidatorSupplier = config.validator();
                    jakarta.validation.Validator jakartaValidator;
                    if (jakartaValidatorSupplier != null) {
                        jakartaValidator = jakartaValidatorSupplier.get();
                    } else {
                        try (ValidatorFactory validatorFactory = Validation.buildDefaultValidatorFactory()) {
                            jakartaValidator = validatorFactory.getValidator();
                        }
                    }
                    validator = new ValidatorFacadeImpl(jakartaValidator);
                }
            }
        }
        return validator;
    }

    @Override
    public JsonMapperFacade jsonMapper() {
        if (jsonMapper == null) {
            synchronized (this) {
                if (jsonMapper == null) {
                    Supplier<JsonMapperFacade> jsonMapperSupplier = config.jsonMapper();
                    if (jsonMapperSupplier != null) {
                        jsonMapper = jsonMapperSupplier.get();
                    } else {
                        jsonMapper = new JsonMapperFacadeImpl();
                    }
                }
            }
        }
        return jsonMapper;
    }

    @Override
    public PdfReaderFacade pdfReader() {
        if (pdfReader == null) {
            synchronized (this) {
                if (pdfReader == null) {
                    Supplier<PdfReaderFacade> pdfReaderSupplier = config.prdReader();
                    if (pdfReaderSupplier != null) {
                        pdfReader = pdfReaderSupplier.get();
                    } else {
                        pdfReader = new PdfReaderFacadeImpl();
                    }
                }
            }
        }
        return pdfReader;
    }

    public DmsFactory dmsFactory() {
        if (dmsFactory == null) {
            synchronized (this) {
                if (dmsFactory == null) {
                    Supplier<DmsFactory> dmsFactorySupplier = config.dmsFactory();
                    if (dmsFactorySupplier != null) {
                        dmsFactory = dmsFactorySupplier.get();
                    } else {
                        throw new IllegalStateException("dmsFactory supplier must not be null");
                    }
                }
            }
        }
        return dmsFactory;
    }
}
