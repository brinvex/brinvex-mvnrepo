package com.brinvex.fintracker.core.impl;

import com.brinvex.fintracker.core.api.FinTrackerConfig;
import com.brinvex.fintracker.core.api.facade.HttpClientFacade;
import com.brinvex.fintracker.core.api.facade.PdfReaderFacade;
import com.brinvex.fintracker.core.api.facade.ValidatorFacade;
import com.brinvex.fintracker.core.api.internal.FinTrackerSupport;
import com.brinvex.fintracker.core.impl.facade.HttpClientFacadeImpl;
import com.brinvex.fintracker.core.impl.facade.PdfReaderFacadeImpl;
import com.brinvex.fintracker.core.impl.facade.ValidatorFacadeImpl;
import com.brinvex.util.dms.api.DmsFactory;
import com.brinvex.util.java.validation.Validate;
import jakarta.validation.Validation;
import jakarta.validation.ValidatorFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.function.Supplier;

public class FinTrackerSupportImpl implements FinTrackerSupport {

    private static final Logger LOG = LoggerFactory.getLogger(FinTrackerSupportImpl.class);

    private final FinTrackerConfig config;

    private volatile DmsFactory dmsFactory;

    private volatile HttpClientFacade httpClient;

    private volatile ValidatorFacade validator;

    private volatile PdfReaderFacade pdfReader;

    public FinTrackerSupportImpl(FinTrackerConfig config) {
        Validate.notNull(config);
        this.config = config;
    }

    @Override
    public DmsFactory dmsFactory() {
        if (dmsFactory == null) {
            synchronized (this) {
                if (dmsFactory == null) {
                    Supplier<DmsFactory> dmsFactorySupplier = config.getDmsFactory();
                    if (dmsFactorySupplier == null) {
                        throw new IllegalStateException("dmsFactory supplier must not be null");
                    }
                    dmsFactory = dmsFactorySupplier.get();
                }
            }
        }
        return dmsFactory;
    }

    @Override
    public HttpClientFacade httpClient() {
        if (httpClient == null) {
            synchronized (this) {
                if (httpClient == null) {
                    httpClient = new HttpClientFacadeImpl();
                }
            }
        }
        return httpClient;
    }

    @Override
    public ValidatorFacade validator() {
        if (validator == null) {
            synchronized (this) {
                if (validator == null) {
                    Supplier<ValidatorFactory> validatorFactorySupplier = config.getValidatorFactory();
                    jakarta.validation.Validator jakartaValidator;
                    if (validatorFactorySupplier != null) {
                        jakartaValidator = validatorFactorySupplier.get().getValidator();
                    } else {
                        try (ValidatorFactory validatorFactory = Validation.buildDefaultValidatorFactory()) {
                            jakartaValidator = validatorFactory.getValidator();
                        }
                    }
                    validator = new ValidatorFacadeImpl(jakartaValidator);
                }
            }
        }
        return validator;
    }

    @Override
    public PdfReaderFacade pdfReader() {
        if (pdfReader == null) {
            synchronized (this) {
                if (pdfReader == null) {
                    pdfReader = new PdfReaderFacadeImpl();
                }
            }
        }
        return pdfReader;
    }
}
