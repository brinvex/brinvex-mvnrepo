package com.brinvex.util.fiobank.impl.broker.parser;

import com.brinvex.fintracker.connector.fiob.api.model.statement.Lang;
import com.brinvex.fintracker.connector.fiob.impl.service.parser.FiobParsingUtil;
import com.brinvex.util.fiobank.api.model.RawBrokerTransaction;
import com.brinvex.util.java.StringUtil;

import java.util.Set;
import java.util.function.BiConsumer;
import java.util.function.BiFunction;
import java.util.function.Function;


@SuppressWarnings("SpellCheckingInspection")
public enum TranColumnDef {

    TRADE_DATE("Dátum obchodu", "Datum obchodu", "Trade Date", ParsingUtil::toFioDateTime, RawBrokerTransaction::setTradeDate),
    DIRECTION("Smer", "Směr", "Direction", (lang, direction) -> FiobParsingUtil.toDirection(Lang.valueOf(lang.name()), direction), RawBrokerTransaction::setDirection),
    SYMBOL("Symbol", "Symbol", "Symbol", s -> StringUtil.stripToNull(s), TranColumnDef::fillSymbol),
    PRICE("Cena", "Cena", "Price", ParsingUtil::toDecimal, RawBrokerTransaction::setPrice),
    SHARES("Počet", "Počet", "Shares", ParsingUtil::toDecimal, RawBrokerTransaction::setShares),
    CURRENCY("Mena", "Měna", "Currency", s -> StringUtil.stripToNull(s), TranColumnDef::fillCurrency),
    VOLUME_CZK("Objem v CZK", "Objem v CZK", "Volume (CZK)", ParsingUtil::toDecimal, RawBrokerTransaction::setVolumeCzk),
    FEES_CZK("Poplatky v CZK", "Poplatky v CZK", "Fees", ParsingUtil::toDecimal, RawBrokerTransaction::setFeesCzk),
    VOLUME_USD("Objem v USD", "Objem v USD", "Volume in USD", ParsingUtil::toDecimal, RawBrokerTransaction::setVolumeUsd),
    FEES_USD("Poplatky v USD", "Poplatky v USD", "Fees (USD)", ParsingUtil::toDecimal, RawBrokerTransaction::setFeesUsd),
    VOLUME_EUR("Objem v EUR", "Objem v EUR", "Volume (EUR)", ParsingUtil::toDecimal, RawBrokerTransaction::setVolumeEur),
    FEES_EUR("Poplatky v EUR", "Poplatky v EUR", "Fees (EUR)", ParsingUtil::toDecimal, RawBrokerTransaction::setFeesEur),
    MARKET("Trh", "Trh", "Market", s -> StringUtil.stripToNull(s), RawBrokerTransaction::setMarket),
    INSTRUMENT_NAME("Názov FN", "Název CP", "Title", s -> StringUtil.stripToNull(s), RawBrokerTransaction::setInstrumentName),
    SETTLEMENT_DATE("Dátum vysporiadania", "Datum vypořádání", "Settlement Date", ParsingUtil::toFioDate, RawBrokerTransaction::setSettlementDate),
    STATUS("Stav", "Stav", "Status", s -> StringUtil.stripToNull(s), RawBrokerTransaction::setStatus),
    ORDER_ID("Pokyn ID", "Pokyn ID", "Order ID", s -> StringUtil.stripToNull(s), RawBrokerTransaction::setOrderId),
    TEXT("Text FIO", "Text FIO", "Text FIO", s -> StringUtil.stripToNull(s), RawBrokerTransaction::setText),
    USER_COMMENTS("Užívateľská identifikácia", "Uživatelská identifikace", "User Comments", s -> StringUtil.stripToNull(s), RawBrokerTransaction::setUserComments),
    ;

    public static final Set<TranColumnDef> STANDARD_COLUMNS = Set.of(
            TRADE_DATE,
            DIRECTION,
            SYMBOL,
            PRICE,
            SHARES,
            CURRENCY,
            VOLUME_CZK,
            FEES_CZK,
            VOLUME_USD,
            FEES_USD,
            VOLUME_EUR,
            FEES_EUR,
            TEXT
    );

    private final String titleSK;

    private final String titleCZ;

    private final String titleEN;

    private final BiFunction<Lang, String, ?> mapper;

    private final BiConsumer<RawBrokerTransaction, ?> filler;

    <T> TranColumnDef(
            String titleSK,
            String titleCZ,
            String titleEN,
            BiFunction<Lang, String, T> mapper,
            BiConsumer<RawBrokerTransaction, T> filler
    ) {
        this.titleSK = titleSK;
        this.titleCZ = titleCZ;
        this.titleEN = titleEN;
        this.mapper = mapper;
        this.filler = filler;
    }

    <T> TranColumnDef(
            String titleSK,
            String titleCZ,
            String titleEN,
            Function<String, T> mapper,
            BiConsumer<RawBrokerTransaction, T> filler
    ) {
        this(titleSK, titleCZ, titleEN, (lang, s) -> mapper.apply(s), filler);
    }

    public static TranColumnDef ofTitle(String title, Lang lang) {
        for (TranColumnDef value : values()) {
            if (value.getTitle(lang).equals(title)) {
                return value;
            }
        }
        return null;
    }

    public String getTitle(Lang lang) {
        switch (lang) {
            case CZ:
                return titleCZ;
            case EN:
                return titleEN;
            case SK:
                return titleSK;
        }
        throw new IllegalArgumentException("Unexpected value: " + lang);
    }

    private static void fillSymbol(RawBrokerTransaction rawTransaction, String rawSymbol) {
        if (rawSymbol != null && !rawSymbol.isBlank()) {
            rawTransaction.setRawSymbol(rawSymbol);
            rawTransaction.setSymbol(rawSymbol.endsWith("*") ? rawSymbol.substring(0, rawSymbol.length() - 1) : rawSymbol);
        }
    }

    private static void fillCurrency(RawBrokerTransaction rawTransaction, String rawCurrency) {
        rawTransaction.setRawCurrency(rawCurrency);
        rawTransaction.setCcy(ParsingUtil.toCurrency(rawCurrency));
    }

    public void fill(RawBrokerTransaction rawTransaction, String cell, Lang lang) {
        Object value = mapper.apply(lang, cell);
        @SuppressWarnings("unchecked")
        BiConsumer<RawBrokerTransaction, Object> filler = (BiConsumer<RawBrokerTransaction, Object>) this.filler;
        filler.accept(rawTransaction, value);
    }
}
