package com.brinvex.fintracker.core.api.model.domain;

import lombok.Builder;

import java.io.Serializable;

@Builder
public record Asset(
        String id,
        AssetType type,
        String country,
        String symbol,
        String name,
        String countryFigi,
        String isin,
        String extraType,
        String extraDetail
) implements Serializable {

    public Asset {
        if (type == null) {
            throw new IllegalArgumentException("type must not be null");
        }
    }
}
