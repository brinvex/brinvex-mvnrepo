package com.brinvex.fintracker.connector.fiob.api;

import com.brinvex.fintracker.connector.fiob.api.service.FiobDms;
import com.brinvex.fintracker.connector.fiob.api.service.FiobFetcher;
import com.brinvex.fintracker.connector.fiob.api.service.FiobFinTransactionMapper;
import com.brinvex.fintracker.connector.fiob.api.service.FiobStatementParser;
import com.brinvex.fintracker.core.api.infra.FinTrackerModule;

public interface FiobModule extends FinTrackerModule {

    FiobFetcher fetcher();

    FiobDms dms();

    FiobStatementParser statementParser();

    FiobFinTransactionMapper finTransactionMapper();

}
