package com.brinvex.util.tnet.api;

public interface TNet extends AutoCloseable {

    <REQ_BODY, RESP_BODY> TNetResponse<RESP_BODY> execute(TNetRequest<REQ_BODY, RESP_BODY> req) throws TNetException;

}
