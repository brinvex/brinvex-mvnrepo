/*
 * Copyright © 2023 Brinvex (dev@brinvex.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.brinvex.util.ibkr.api.service;

import com.brinvex.util.ibkr.api.model.DocKey;
import com.brinvex.util.ibkr.api.model.DocKey.ActivityDocKey;
import com.brinvex.util.ibkr.api.model.DocKey.TradeConfirmDocKey;

import java.time.LocalDate;
import java.util.List;

public interface IbkrDms {

    List<ActivityDocKey> getActivityDocKeys(String accountId, LocalDate fromDayIncl, LocalDate toDayIncl);

    List<TradeConfirmDocKey> getTradeConfirmDocKeys(String accountId, LocalDate fromDayIncl, LocalDate toDayIncl);

    TradeConfirmDocKey getUniqueTradeConfirmDocKey(String accountId, LocalDate day);

    String getStatementContent(DocKey docKey);

    boolean putStatementIfUseful(ActivityDocKey docKey, String content);

    boolean putStatement(DocKey docKey, String content);

    void delete(DocKey docKey);

    static IbkrDms create(com.brinvex.util.dms.api.Dms dms) {
        try {
            return (IbkrDms) Class.forName("com.brinvex.util.ibkr.impl.IbkrDmsImpl")
                    .getConstructor(com.brinvex.util.dms.api.Dms.class)
                    .newInstance(dms);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

}
