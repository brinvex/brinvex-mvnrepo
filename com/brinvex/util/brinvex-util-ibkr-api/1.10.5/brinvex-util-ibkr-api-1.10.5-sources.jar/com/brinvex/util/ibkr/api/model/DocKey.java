/*
 * Copyright © 2023 Brinvex (dev@brinvex.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.brinvex.util.ibkr.api.model;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Comparator;

public sealed interface DocKey extends Serializable {

    String accountId();

    record ActivityDocKey(
            @Override
            String accountId,
            LocalDate fromDayIncl,
            LocalDate toDayIncl
    ) implements DocKey, Comparable<ActivityDocKey>, Serializable {

        private static final Comparator<ActivityDocKey> COMPARATOR =
                Comparator.comparing(ActivityDocKey::accountId)
                        .thenComparing(ActivityDocKey::fromDayIncl)
                        .thenComparing(ActivityDocKey::toDayIncl);

        public ActivityDocKey {
            if (accountId == null || accountId.isEmpty()) {
                throw new IllegalArgumentException("accountId cannot be null or empty");
            }
            if (fromDayIncl == null) {
                throw new IllegalArgumentException("fromDayIncl cannot be null");
            }
            if (toDayIncl == null) {
                throw new IllegalArgumentException("toDayIncl cannot be null");
            }
            if (fromDayIncl.isAfter(toDayIncl)) {
                throw new IllegalArgumentException("fromDayIncl cannot be after toDayIncl");
            }
        }

        @Override
        public int compareTo(ActivityDocKey other) {
            return COMPARATOR.compare(this, other);
        }
    }

    record TradeConfirmDocKey(
            @Override
            String accountId,
            LocalDate day,
            LocalTime whenGenerated
    ) implements DocKey, Comparable<TradeConfirmDocKey>, Serializable {

        private static final Comparator<TradeConfirmDocKey> COMPARATOR =
                Comparator.comparing(TradeConfirmDocKey::accountId)
                        .thenComparing(TradeConfirmDocKey::day)
                        .thenComparing(TradeConfirmDocKey::whenGenerated);

        public TradeConfirmDocKey {
            if (accountId == null || accountId.isEmpty()) {
                throw new IllegalArgumentException("accountId cannot be null or empty");
            }
            if (day == null) {
                throw new IllegalArgumentException("day cannot be null");
            }
            if (whenGenerated == null) {
                throw new IllegalArgumentException("whenGenerated cannot be null");
            }
        }

        @Override
        public int compareTo(TradeConfirmDocKey other) {
            return COMPARATOR.compare(this, other);
        }
    }
}
