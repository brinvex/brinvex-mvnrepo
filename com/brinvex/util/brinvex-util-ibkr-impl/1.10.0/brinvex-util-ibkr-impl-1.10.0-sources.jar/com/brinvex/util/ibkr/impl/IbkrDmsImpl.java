package com.brinvex.util.ibkr.impl;

import com.brinvex.util.ibkr.api.model.DocKey;
import com.brinvex.util.ibkr.api.model.statement.FlexStatementType;
import com.brinvex.util.ibkr.api.service.IbkrDms;
import com.brinvex.util.ibkr.api.service.exception.IbkrDmsException;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.SequencedCollection;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static java.util.Collections.emptySet;
import static java.util.Comparator.comparing;
import static java.util.Comparator.naturalOrder;

public class IbkrDmsImpl implements IbkrDms {

    private static final class Lazy {
        private static final DateTimeFormatter dmsDocDf = DateTimeFormatter.ofPattern("yyyyMMdd");
        private static final Pattern activityDmsDocPattern = Pattern.compile("(\\w{8,16})-ACT-(\\d{8})-(\\d{8})\\.xml");
        private static final Pattern tradeConfirmDmsDocPattern = Pattern.compile("(\\w{8,16})-TC-(\\d{8})-(\\d{8})\\.xml");
    }

    private final com.brinvex.util.dms.api.Dms dms;

    public IbkrDmsImpl(com.brinvex.util.dms.api.Dms dms) {
        this.dms = dms;
    }

    @Override
    public List<DocKey> getDocKeys(FlexStatementType statementType, String accountId, LocalDate fromDayIncl, LocalDate toDayIncl) {
        String directory = getDirectory(accountId);
        SequencedCollection<String> fileKeys = dms.getKeys(directory);
        List<DocKey> results = new ArrayList<>();
        Pattern p = switch (statementType) {
            case ACT -> Lazy.activityDmsDocPattern;
            case TC -> Lazy.tradeConfirmDmsDocPattern;
        };
        for (String fileKey : fileKeys) {
            Matcher m = p.matcher(fileKey);
            if (m.matches()) {
                String docAccountId = m.group(1);
                if (!docAccountId.equals(accountId)) {
                    throw new IbkrDmsException("Unexpected document '%s' in directory '%s'".formatted(fileKey, directory));
                }
                LocalDate docFromDayIncl = LocalDate.parse(m.group(2), Lazy.dmsDocDf);
                LocalDate docToDayIncl = LocalDate.parse(m.group(3), Lazy.dmsDocDf);
                boolean outside = (toDayIncl != null && docFromDayIncl.isAfter(toDayIncl)) || (fromDayIncl != null && docToDayIncl.isBefore(fromDayIncl));
                if (outside) {
                    continue;
                }
                results.add(new DocKey(docAccountId, statementType, docFromDayIncl, docToDayIncl));
            }
        }
        results.sort(naturalOrder());
        return results;
    }

    @Override
    public DocKey getUniqueDocKey(FlexStatementType statementType, String accountId, LocalDate fromDayIncl, LocalDate toDayIncl) {
        List<DocKey> docKeys = getDocKeys(statementType, accountId, fromDayIncl, toDayIncl);
        int docKeysSize = docKeys.size();
        return switch (docKeysSize) {
            case 0 -> null;
            case 1 -> docKeys.getFirst();
            default -> throw new IbkrDmsException((
                    "Expecting one but found %s docKeys matching " +
                    "statementType=%s, accountId=%s, fromDayIncl=%s, toDayIncl=%s")
                    .formatted(docKeysSize, statementType, accountId, fromDayIncl, toDayIncl));
        };
    }

    @Override
    public String getStatementContent(DocKey docKey) {
        String directory = getDirectory(docKey.accountId());
        String fileKey = constructFileKey(docKey);
        return dms.getTextContent(directory, fileKey);
    }

    @Override
    public String getStatementContentIfExists(DocKey docKey) {
        String directory = getDirectory(docKey.accountId());
        String fileKey = constructFileKey(docKey);
        if (!dms.exists(directory, fileKey)) {
            return null;
        }
        return dms.getTextContent(directory, fileKey);
    }

    @Override
    public boolean putStatementIfUseful(DocKey docKey, String content) {
        String accountId = docKey.accountId();
        FlexStatementType statementType = docKey.statementType();
        String directory = getDirectory(accountId);

        List<DocKey> oldDocKeys = getDocKeys(statementType, accountId, docKey.fromDayIncl(), docKey.toDayIncl());
        String newFileKey = constructFileKey(docKey);
        List<DocKey> oldAndNewDocKeys = new ArrayList<>(oldDocKeys);
        oldAndNewDocKeys.add(docKey);
        Set<DocKey> uselessKeys = detectUselessDocs(oldAndNewDocKeys);
        boolean newSaved;
        if (!uselessKeys.remove(docKey)) {
            dms.add(directory, newFileKey, content);
            newSaved = true;
        } else {
            newSaved = false;
        }
        for (DocKey uselessKey : uselessKeys) {
            dms.delete(directory, constructFileKey(uselessKey));
        }
        return newSaved;
    }

    @Override
    public boolean putStatement(DocKey docKey, String content) {
        String accountId = docKey.accountId();
        String directory = getDirectory(accountId);
        String newFileKey = constructFileKey(docKey);
        return dms.put(directory, newFileKey, content);
    }

    @Override
    public void delete(DocKey docKey) {
        String directory = getDirectory(docKey.accountId());
        String fileKey = constructFileKey(docKey);
        dms.delete(directory, fileKey);
    }

    private String constructFileKey(DocKey docKey) {
        String statementTypeKeyPart = switch (docKey.statementType()) {
            case ACT -> "ACT";
            case TC -> "TC";
        };
        return "%s-%s-%s-%s.xml".formatted(
                docKey.accountId(),
                statementTypeKeyPart,
                Lazy.dmsDocDf.format(docKey.fromDayIncl()),
                Lazy.dmsDocDf.format(docKey.toDayIncl())
        );
    }

    private Set<DocKey> detectUselessDocs(List<DocKey> docKeys) {
        int size = docKeys.size();
        if (size <= 1) {
            return emptySet();
        }
        docKeys = docKeys.stream().sorted(comparing(DocKey::fromDayIncl).thenComparing(DocKey::toDayIncl)).toList();
        Set<DocKey> uselessDocs = new HashSet<>();
        int prevUsefulIndex = 0;
        for (int i = 0; i < size; i++) {
            DocKey midKey = docKeys.get(i);
            boolean useful;
            if (i == 0) {
                DocKey nextKey = docKeys.get(i + 1);
                useful = midKey.fromDayIncl().isBefore(nextKey.fromDayIncl());
            } else if (i == size - 1) {
                DocKey prevKey = docKeys.get(prevUsefulIndex);
                useful = midKey.toDayIncl().isAfter(prevKey.toDayIncl());
            } else {
                DocKey prevKey = docKeys.get(prevUsefulIndex);
                DocKey nextKey = docKeys.get(i + 1);
                LocalDate prevToDayExcl = prevKey.toDayIncl().plusDays(1);
                boolean neighborsContinuous = !prevToDayExcl.isBefore(nextKey.fromDayIncl());
                if (neighborsContinuous) {
                    boolean inside = !midKey.fromDayIncl().isBefore(prevKey.fromDayIncl()) && !midKey.toDayIncl().isAfter(nextKey.toDayIncl());
                    useful = !inside;
                } else {
                    boolean insidePrev = !midKey.fromDayIncl().isBefore(prevKey.fromDayIncl()) && !midKey.toDayIncl().isAfter(prevKey.toDayIncl());
                    boolean insideNext = !midKey.fromDayIncl().isBefore(nextKey.fromDayIncl()) && !midKey.toDayIncl().isAfter(nextKey.toDayIncl());
                    useful = !insidePrev || !insideNext;
                }
            }
            if (!useful) {
                uselessDocs.add(midKey);
            } else {
                prevUsefulIndex = i;
            }
        }
        return uselessDocs;
    }

    private String getDirectory(String accountId) {
        return accountId;
    }

}
