package com.brinvex.fintracker.core.impl.ent;

import com.brinvex.finance.types.enu.Currency;
import jakarta.persistence.Basic;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;
import org.hibernate.annotations.JdbcTypeCode;
import org.hibernate.type.SqlTypes;

import java.time.LocalDate;
import java.util.Map;

@Entity
@Table(name = "account")
public class AccountEnt {

    @Id
    @SequenceGenerator(name = "account_seq", allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "account_seq")
    @Column(name = "id")
    private Long id;

    @Column(name = "name", updatable = false, length = 100)
    private String name;

    @Column(name = "type", updatable = false, length = 50)
    private String type;

    @Column(name = "ccy", nullable = false, updatable = false, length = 3)
    @Enumerated(EnumType.STRING)
    private Currency ccy;

    @Basic(optional = false)
    @Column(name = "open_date", nullable = false, updatable = false)
    private LocalDate openDate;

    @Basic(optional = false)
    @Column(name = "close_date", nullable = false, updatable = false)
    private LocalDate closeDate;

    @Basic(optional = false)
    @Column(name = "external_id", updatable = false)
    private String externalId;

    @Column(name = "credentials", updatable = false)
    private String credentials;

    @JdbcTypeCode(SqlTypes.JSON)
    @Column(name = "ext_details", nullable = false, updatable = false, columnDefinition = "jsonb")
    private Map<String, String> extraProps;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Currency getCcy() {
        return ccy;
    }

    public void setCcy(Currency ccy) {
        this.ccy = ccy;
    }

    public LocalDate getOpenDate() {
        return openDate;
    }

    public void setOpenDate(LocalDate openDate) {
        this.openDate = openDate;
    }

    public LocalDate getCloseDate() {
        return closeDate;
    }

    public void setCloseDate(LocalDate closeDate) {
        this.closeDate = closeDate;
    }

    public String getExternalId() {
        return externalId;
    }

    public void setExternalId(String externalId) {
        this.externalId = externalId;
    }

    public String getCredentials() {
        return credentials;
    }

    public void setCredentials(String credentials) {
        this.credentials = credentials;
    }

    public Map<String, String> getExtraProps() {
        return extraProps;
    }

    public void setExtraProps(Map<String, String> extraProps) {
        this.extraProps = extraProps;
    }
}
