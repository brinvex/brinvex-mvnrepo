package com.brinvex.finance.types.enu;

/// For information on industry classification standards, see Wikipedia:
/// - <a href="https://en.wikipedia.org/wiki/Industry_Classification_Benchmark">Industry_Classification_Benchmark</a>
/// - <a href="https://en.wikipedia.org/wiki/Global_Industry_Classification_Standard">Global_Industry_Classification_Standard</a>
public enum IndustrySector {

    ENERGY("Energy"),

    MATERIALS("Materials"),

    INDUSTRIALS("Industrials"),

    /// Consumer discretionary is a term for classifying goods and services
    /// that are considered **non-essential** by consumers,
    /// but desirable if their available income is sufficient to purchase them.
    /// Examples of consumer discretionary products can include durable goods,
    /// high-end apparel, entertainment, leisure activities, and automobiles.
    /// Source: <a href="https://www.investopedia.com/terms/c/consumerstaples.asp">Investopedia</a>
    CONSUMER_DISCRETIONARY("Consumer Discretionary"),

    /// The term consumer staples refers to a set of **essential** products used by consumers.
    /// This category includes things like foods and beverages, household goods,
    /// and hygiene products as well as alcohol and tobacco.
    /// Source: <a href="https://www.investopedia.com/terms/c/consumerstaples.asp">Investopedia</a>
    CONSUMER_STAPLES("Consumer Staples"),

    HEALTH_CARE("Health Care"),

    FINANCIALS("Financials"),

    INFORMATION_TECHNOLOGY("Information Technology"),

    COMMUNICATION_SERVICES("Communication Services"),

    UTILITIES("Utilities"),

    REAL_ESTATE("Real Estate"),

    /// Used for classifications involving multiple sectors.
    CROSS_SECTOR("Cross-Sector"),
    ;

    private final String title;

    IndustrySector(String title) {
        this.title = title;
    }

    public String getTitle() {
        return title;
    }
}
