package com.brinvex.util.ibkr.api.model.statement;

import com.brinvex.util.ibkr.api.model.Currency;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDate;

public record CorporateAction(
        LocalDate reportDate,
        AssetCategory assetCategory,
        AssetSubCategory assetSubCategory,
        String symbol,
        CorporateActionType type,
        Currency currency,
        BigDecimal amount,
        BigDecimal value,
        BigDecimal quantity,
        BigDecimal proceeds,
        String description,
        String securityID,
        SecurityIDType securityIDType,
        String figi,
        String isin,
        String listingExchange,
        String issuerCountryCode,
        String extraDateTimeStr,
        String transactionId,
        String actionID
) implements Serializable {

    public CorporateAction {
        if (assetCategory == null && assetSubCategory != null) {
            throw new IllegalArgumentException("assetCategory cannot be null when assetSubCategory is not null");
        }
    }
}
