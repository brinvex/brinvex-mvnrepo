/*
 * Copyright © 2023 Brinvex (dev@brinvex.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.brinvex.util.ibkr.api.model.statement;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.ZonedDateTime;
import java.util.List;

public sealed interface FlexStatement permits FlexStatement.ActivityStatement, FlexStatement.TradeConfirmStatement {

    record ActivityStatement(
            String accountId,
            LocalDate fromDate,
            LocalDate toDate,
            ZonedDateTime whenGenerated,
            List<CashTransaction> cashTransactions,
            List<Trade> trades,
            List<CorporateAction> corporateActions,
            List<EquitySummary> equitySummaries
    ) implements FlexStatement, Serializable {

        public ActivityStatement(
                String accountId,
                LocalDate fromDate,
                LocalDate toDate,
                ZonedDateTime whenGenerated,
                List<CashTransaction> cashTransactions,
                List<Trade> trades,
                List<CorporateAction> corporateActions,
                List<EquitySummary> equitySummaries
        ) {
            this.accountId = accountId;
            this.fromDate = fromDate;
            this.toDate = toDate;
            this.whenGenerated = whenGenerated;
            this.cashTransactions = cashTransactions == null ? null : List.copyOf(cashTransactions);
            this.trades = trades == null ? null : List.copyOf(trades);
            this.corporateActions = corporateActions == null ? null : List.copyOf(corporateActions);
            this.equitySummaries = equitySummaries == null ? null : List.copyOf(equitySummaries);
        }
    }

    record TradeConfirmStatement(
            String accountId,
            LocalDate fromDate,
            LocalDate toDate,
            ZonedDateTime whenGenerated,
            List<TradeConfirm> tradeConfirmations
    ) implements FlexStatement, Serializable {
        public TradeConfirmStatement(
                String accountId,
                LocalDate fromDate,
                LocalDate toDate,
                ZonedDateTime whenGenerated,
                List<TradeConfirm> tradeConfirmations
        ) {
            this.accountId = accountId;
            this.fromDate = fromDate;
            this.toDate = toDate;
            this.whenGenerated = whenGenerated;
            this.tradeConfirmations = tradeConfirmations == null ? null : List.copyOf(tradeConfirmations);
        }
    }
}