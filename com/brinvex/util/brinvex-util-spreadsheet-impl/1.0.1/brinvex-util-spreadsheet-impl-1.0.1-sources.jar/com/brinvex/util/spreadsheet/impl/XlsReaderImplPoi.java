package com.brinvex.util.spreadsheet.impl;

import com.brinvex.util.spreadsheet.api.ExcelXlsReader;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

import java.io.IOException;
import java.io.InputStream;
import java.io.UncheckedIOException;
import java.util.List;
import java.util.Map;

@SuppressWarnings("SameParameterValue")
public class XlsReaderImplPoi extends AbstractReaderImplPoi implements ExcelXlsReader {

    @Override
    public List<Map<String, Object>> readColumns(
            InputStream is,
            Map<String, Class<?>> columnNamesAndTypes,
            int rowsToSkip
    ) {
        HSSFWorkbook workbook;
        try {
            workbook = new HSSFWorkbook(is);
        } catch (IOException e) {
            throw new UncheckedIOException(e);
        }
        HSSFSheet sheet = workbook.getSheetAt(0);

        return readColumns(columnNamesAndTypes, sheet, rowsToSkip, true);

    }

    @Override
    public List<Map<String, Object>> readCompactRange(InputStream is, Map<String, Class<?>> headerNamesAndTypes) {
        HSSFWorkbook workbook;
        try {
            workbook = new HSSFWorkbook(is);
        } catch (IOException e) {
            throw new UncheckedIOException(e);
        }
        HSSFSheet sheet = workbook.getSheetAt(0);

        return readTable(headerNamesAndTypes, sheet, true);
    }
}
