package com.brinvex.fintracker.core.api.model.domain;

import java.io.Serializable;
import java.util.List;
import java.util.SequencedCollection;

public record PtfProgress(
        SequencedCollection<FinTransaction> transactions,
        SequencedCollection<DateAmount> netAssetValues,
        String ccy
) implements Serializable {

    public PtfProgress(SequencedCollection<FinTransaction> transactions, SequencedCollection<DateAmount> netAssetValues, String ccy) {
        this.transactions = transactions == null ? null : List.copyOf(transactions);
        this.netAssetValues = netAssetValues == null ? null : List.copyOf(netAssetValues);
        this.ccy = ccy;
    }
}

