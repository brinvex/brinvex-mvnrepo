module com.brinvex.fintypes {
    exports com.brinvex.fintypes.enu;
    exports com.brinvex.fintypes.vo;
}