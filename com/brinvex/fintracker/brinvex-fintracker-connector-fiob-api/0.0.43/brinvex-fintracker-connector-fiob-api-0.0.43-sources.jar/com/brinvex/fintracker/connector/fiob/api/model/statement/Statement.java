package com.brinvex.fintracker.connector.fiob.api.model.statement;

import java.time.LocalDate;
import java.util.List;

public sealed interface Statement {

    record TradingTransStatement(
            String accountId,
            LocalDate periodFrom,
            LocalDate periodTo,
            List<TradingTransaction> transactions
    ) implements Statement {
    }

    record TradingPtfOverviewStatement() implements Statement {
    }

    record SavingTransStatement(
            String accountId,
            LocalDate periodFrom,
            LocalDate periodTo,
            List<TradingTransaction> transactions   //todo 5
    ) implements Statement {
    }


}
