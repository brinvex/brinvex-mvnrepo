package com.brinvex.fintracker.core.api;

import com.brinvex.fintracker.core.api.internal.FinTrackerModule;

import java.lang.reflect.InvocationTargetException;

public interface FinTracker {

    <MODULE extends FinTrackerModule> MODULE get(Class<MODULE> moduleType);

    static FinTracker newInstance() {
        return newInstance(FinTrackerConfig.builder().build());
    }

    static FinTracker newInstance(FinTrackerConfig config) {
        String implClassName = "com.brinvex.fintracker.core.impl.FinTrackerImpl";
        try {
            return (FinTracker) Class.forName(implClassName)
                    .getConstructor(FinTrackerConfig.class)
                    .newInstance(config);
        } catch (ClassNotFoundException
                 | IllegalAccessException
                 | InstantiationException
                 | NoSuchMethodException
                 | InvocationTargetException e
        ) {
            throw new IllegalStateException("Failed to instantiate %s, %s".formatted(implClassName, e), e);
        }
    }


}
