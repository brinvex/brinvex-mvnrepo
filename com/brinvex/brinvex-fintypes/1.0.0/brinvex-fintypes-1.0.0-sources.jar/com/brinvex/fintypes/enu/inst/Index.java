package com.brinvex.fintypes.enu.inst;

import com.brinvex.fintypes.enu.Country;
import com.brinvex.fintypes.enu.IndustrySector;
import com.brinvex.fintypes.vo.FullSymbol;

import static com.brinvex.fintypes.enu.Country.US;

@SuppressWarnings("SpellCheckingInspection")
public enum Index {
    /**
     * S&P500
     */
    SPX_US("SPX", US, "S&P500", IndustrySector.CROSS_SECTOR, false),
    /**
     * S&P500 TR
     */
    SPXT_US("SPXT", US, "S&P500 TR", IndustrySector.CROSS_SECTOR, true),

    /**
     * S&P500 Materials
     */
    IXB_US("IXB", US, "S&P500 Materials", IndustrySector.MATERIALS, false),
    /**
     * S&P500 Materials TR
     */
    IXBTR_US("IXBTR", US, "S&P500 Materials TR", IndustrySector.MATERIALS, true),
    /**
     * S&P500 Communication Services
     */
    IXCPR_US("IXCPR", US, "S&P500 Communication Services", IndustrySector.COMMUNICATION_SERVICES, false),
    /**
     * S&P500 Communication Services TR
     */
    IXCTR_US("IXCTR", US, "S&P500 Communication Services TR", IndustrySector.COMMUNICATION_SERVICES, true),
    /**
     * S&P500 Energy
     */
    IXE_US("IXE", US, "S&P500 Energy", IndustrySector.ENERGY, false),
    /**
     * S&P500 Energy TR
     */
    IXETR_US("IXETR", US, "S&P500 Energy TR", IndustrySector.ENERGY, true),
    /**
     * S&P500 Industrials
     */
    IXI_US("IXI", US, "S&P500 Industrials", IndustrySector.INDUSTRIALS, false),
    /**
     * S&P500 Industrials TR
     */
    IXITR_US("IXITR", US, "S&P500 Industrials TR", IndustrySector.INDUSTRIALS, true),
    /**
     * S&P500 Financials
     */
    IXM_US("IXM", US, "S&P500 Financials", IndustrySector.FINANCIALS, false),
    /**
     * S&P500 Financials TR
     */
    IXMTR_US("IXMTR", US, "S&P500 Financials TR", IndustrySector.FINANCIALS, true),
    /**
     * S&P500 Consumer Staples
     */
    IXR_US("IXR", US, "S&P500 Consumer Staples", IndustrySector.CONSUMER_STAPLES, false),
    /**
     * S&P500 Consumer Staples TR
     */
    IXRTR_US("IXRTR", US, "S&P500 Consumer Staples TR", IndustrySector.CONSUMER_STAPLES, true),
    /**
     * S&P500 Real Estate
     */
    IXRE_US("IXRE", US, "S&P500 Real Estate", IndustrySector.REAL_ESTATE, false),
    /**
     * S&P500 Real Estate TR
     */
    IXRETR_US("IXRETR", US, "S&P500 Real Estate TR", IndustrySector.REAL_ESTATE, true),
    /**
     * S&P500 Technology
     */
    IXT_US("IXT", US, "S&P500 Technology", IndustrySector.INFORMATION_TECHNOLOGY, false),
    /**
     * S&P500 Technology TR
     */
    IXTTR_US("IXTTR", US, "S&P500 Technology TR", IndustrySector.INFORMATION_TECHNOLOGY, true),
    /**
     * S&P500 Utilities
     */
    IXU_US("IXU", US, "S&P500 Utilities", IndustrySector.UTILITIES, false),
    /**
     * S&P500 Utilities TR
     */
    IXUTR_US("IXUTR", US, "S&P500 Utilities TR", IndustrySector.UTILITIES, true),
    /**
     * S&P500 Health Care
     */
    IXV_US("IXV", US, "S&P500 Health Care", IndustrySector.HEALTH_CARE, false),
    /**
     * S&P500 Health Care TR
     */
    IXVTR_US("IXVTR", US, "S&P500 Health Care TR", IndustrySector.HEALTH_CARE, true),
    /**
     * S&P500 Consumer Discretionary
     */
    IXY_US("IXY", US, "S&P500 Consumer Discretionary", IndustrySector.CONSUMER_DISCRETIONARY, false),
    /**
     * S&P500 Consumer Discretionary TR
     */
    IXYTR_US("IXYTR", US, "S&P500 Consumer Discretionary TR", IndustrySector.CONSUMER_DISCRETIONARY, true),
    ;

    public static Index of(Country country, String symbol) {
        return valueOf(symbol + "_" + country);
    }

    private final FullSymbol fullSymbol;

    private final String title;

    private final IndustrySector sector;

    private final boolean totalReturn;

    Index(String symbol, Country country, String title, IndustrySector sector, boolean totalReturn) {
        this.fullSymbol = new FullSymbol(symbol, country);
        this.title = title;
        this.sector = sector;
        this.totalReturn = totalReturn;
    }

    public String symbol() {
        return fullSymbol.symbol();
    }

    public Country country() {
        return fullSymbol.country();
    }

    public FullSymbol fullSymbol() {
        return fullSymbol;
    }

    public String title() {
        return title;
    }

    public IndustrySector sector() {
        return sector;
    }

    public boolean totalReturn() {
        return totalReturn;
    }
}
