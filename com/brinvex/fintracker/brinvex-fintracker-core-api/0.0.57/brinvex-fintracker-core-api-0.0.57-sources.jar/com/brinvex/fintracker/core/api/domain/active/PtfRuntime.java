package com.brinvex.fintracker.core.api.domain.active;

import com.brinvex.fintracker.core.api.domain.vo.FinTransaction;

import java.util.List;
import java.util.SequencedCollection;

/**
 * Represents the runtime state and operational behavior of a portfolio.
 * <p>
 * This class holds the mutable state of the portfolio and provides methods
 * for performing for portfolio-related business operations.
 */
public interface PtfRuntime {

    default void applyFinTransaction(FinTransaction finTransaction) {
        applyFinTransactions(List.of(finTransaction));
    }

    void applyFinTransactions(SequencedCollection<FinTransaction> finTransactions);
}
