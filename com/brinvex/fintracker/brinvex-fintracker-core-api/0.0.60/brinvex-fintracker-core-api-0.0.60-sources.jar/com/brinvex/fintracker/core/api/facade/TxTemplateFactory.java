package com.brinvex.fintracker.core.api.facade;

public interface TxTemplateFactory {

    TxTemplateFacade getTxTemplate(String propagationBehaviour);

}
