package com.brinvex.util.ibkr.impl;

import com.brinvex.util.ibkr.api.model.Credentials;
import com.brinvex.util.ibkr.api.model.DocKey;
import com.brinvex.util.ibkr.api.model.DocKey.ActivityDocKey;
import com.brinvex.util.ibkr.api.model.DocKey.TradeConfirmDocKey;
import com.brinvex.util.ibkr.api.model.FinTransaction;
import com.brinvex.util.ibkr.api.model.PtfProgress;
import com.brinvex.util.ibkr.api.model.statement.EquitySummary;
import com.brinvex.util.ibkr.api.model.statement.FlexStatement.ActivityStatement;
import com.brinvex.util.ibkr.api.model.statement.FlexStatement.TradeConfirmStatement;
import com.brinvex.util.ibkr.api.service.IbkrDms;
import com.brinvex.util.ibkr.api.service.IbkrFetcher;
import com.brinvex.util.ibkr.api.service.IbkrPtfTracker;
import com.brinvex.util.ibkr.api.service.IbkrStatementMerger;
import com.brinvex.util.ibkr.api.service.IbkrStatementParser;
import com.brinvex.util.ibkr.api.service.IbkrTransactionMapper;
import com.brinvex.util.ibkr.api.service.exception.IbkrException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.math.BigDecimal;
import java.time.Duration;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.SequencedMap;
import java.util.stream.Stream;

import static com.brinvex.util.ibkr.impl.Util.nullSafe;
import static java.time.Duration.ofMillis;
import static java.time.Duration.ofSeconds;
import static java.util.Collections.emptyList;
import static java.util.Comparator.comparing;
import static java.util.stream.Collectors.toMap;

@SuppressWarnings({"DuplicatedCode", "unused"})
public class IbkrPtfTrackerImpl implements IbkrPtfTracker {

    private static final Logger LOG = LoggerFactory.getLogger(IbkrPtfTrackerImpl.class);

    private static final ZoneId IBKR_ZONE_ID = ZoneId.of("America/New_York");

    private final IbkrDms dms;

    private final IbkrStatementParser parser;

    private final IbkrFetcher fetcher;

    private final IbkrStatementMerger statementMerger;

    private final IbkrTransactionMapper transactionMapper;

    public IbkrPtfTrackerImpl(
            IbkrDms dms,
            IbkrStatementParser parser,
            IbkrFetcher fetcher,
            IbkrStatementMerger statementMerger,
            IbkrTransactionMapper transactionMapper
    ) {
        this.dms = dms;
        this.parser = parser;
        this.fetcher = fetcher;
        this.statementMerger = statementMerger;
        this.transactionMapper = transactionMapper;
    }

    @Override
    public PtfProgress getPortfolioProgressOffline(String accountId, LocalDate fromDayIncl, LocalDate toDayIncl) {
        if (accountId == null || accountId.isEmpty()) {
            throw new IllegalArgumentException("accountId cannot be null or empty");
        }
        if (fromDayIncl == null || toDayIncl == null) {
            throw new IllegalArgumentException("fromDayIncl and toDayIncl cannot be null ");
        }
        return getPortfolioProgress(accountId, null, fromDayIncl, toDayIncl, null);
    }

    @Override
    public PtfProgress getPortfolioProgressOnline(
            String accountId,
            Credentials credential,
            LocalDate fromDayIncl,
            LocalDate toDayIncl,
            Duration staleTolerance
    ) {
        if (accountId == null || accountId.isEmpty()) {
            throw new IllegalArgumentException("accountId cannot be null or empty");
        }
        if (credential == null) {
            throw new IllegalArgumentException("credential cannot be null ");
        }
        if (fromDayIncl == null || toDayIncl == null) {
            throw new IllegalArgumentException("fromDayIncl and toDayIncl cannot be null ");
        }
        if (staleTolerance == null) {
            throw new IllegalArgumentException("staleTolerance cannot be null ");
        }
        return getPortfolioProgress(accountId, credential, fromDayIncl, toDayIncl, staleTolerance);
    }

    private PtfProgress getPortfolioProgress(String accountId, Credentials credentials, LocalDate fromDayIncl, LocalDate toDayIncl, Duration staleTolerance) {
        LocalDate ibkrToday = ZonedDateTime.now(IBKR_ZONE_ID).toLocalDate();

        {
            boolean actOnline = credentials != null && credentials.activityFlexQueryId() != null;
            if (actOnline) {
                LocalDate fetchFromDayIncl;
                List<DocKey.ActivityDocKey> oldActDocKeys = dms.getActivityDocKeys(accountId, fromDayIncl, toDayIncl);
                if (oldActDocKeys.isEmpty()) {
                    fetchFromDayIncl = fromDayIncl;
                } else {
                    LocalDate oldOldestDay = oldActDocKeys.getFirst().fromDayIncl();
                    LocalDate oldNewestDay = oldActDocKeys.getLast().toDayIncl();
                    if (fromDayIncl.isBefore(oldOldestDay)) {
                        fetchFromDayIncl = fromDayIncl;
                    } else if (toDayIncl.isAfter(oldNewestDay)) {
                        fetchFromDayIncl = oldNewestDay.plusDays(1);
                    } else {
                        fetchFromDayIncl = null;
                    }
                }
                if (fetchFromDayIncl != null && fetchFromDayIncl.isBefore(ibkrToday)) {
                    if (fetchFromDayIncl.isBefore(ibkrToday.minusDays(365))) {
                        throw new IbkrException(
                                "IBKR does not allow automatic fetching of Flex Activity Statements for periods starting more than 365 days ago. " +
                                "Please manually retrieve the missed statements and upload them to DMS. " +
                                "accountId=%s, activityFlexQueryId=%s, fromDayIncl=%s, toDayIncl=%s, fetchFromDayIncl=%s"
                                        .formatted(accountId, credentials.activityFlexQueryId(), fromDayIncl, toDayIncl, fetchFromDayIncl));
                    }
                    String fetchedContent = fetcher.fetchFlexStatement(credentials.token(), credentials.activityFlexQueryId(), 4, ofSeconds(5));
                    ActivityStatement fetchedActStatement = parser.parseActivityStatement(fetchedContent);
                    ActivityDocKey fetchedDocKey = new ActivityDocKey(accountId, fetchedActStatement.fromDate(), fetchedActStatement.toDate());
                    boolean useful = dms.putStatementIfUseful(fetchedDocKey, fetchedContent);
                    if (useful) {
                        LOG.debug("getPortfolioProgress - saved fetched statement - {}", fetchedDocKey);
                    } else {
                        LOG.debug("getPortfolioProgress - fetched statement is useless - {}", fetchedDocKey);
                    }
                    {
                        List<TradeConfirmDocKey> unnecessaryTcDocKeys = dms.getTradeConfirmDocKeys(accountId, fetchedActStatement.fromDate(), fetchedActStatement.toDate());
                        for (TradeConfirmDocKey unnecessaryTcDocKey : unnecessaryTcDocKeys) {
                            LOG.debug("getPortfolioProgress - deleting unnecessary statement - {}", unnecessaryTcDocKey);
                            dms.delete(unnecessaryTcDocKey);
                        }
                    }
                }
            }
        }
        List<ActivityStatement> actStatements = dms.getActivityDocKeys(accountId, fromDayIncl, toDayIncl)
                .stream()
                .map(dms::getStatementContent)
                .map(parser::parseActivityStatement)
                .toList();

        ActivityStatement mergedActStatement = statementMerger.mergeActivityStatements(actStatements).orElse(null);
        if (mergedActStatement == null) {
            return null;
        }

        List<FinTransaction> newCashTrans = transactionMapper.mapCashTransactions(mergedActStatement.cashTransactions());

        List<FinTransaction> newTrades = transactionMapper.mapTrades(mergedActStatement.trades());

        List<FinTransaction> newCorpActions = transactionMapper.mapCorporateAction(mergedActStatement.corporateActions());

        List<FinTransaction> tcTrades;
        {
            LocalDate tcDay = mergedActStatement.toDate().plusDays(1);
            TradeConfirmStatement tcStatement = null;
            if (!tcDay.isAfter(toDayIncl)) {
                boolean tcOnline = credentials != null && credentials.tradeConfirmFlexQueryId() != null;
                if (tcOnline) {
                    if (tcDay.isEqual(ibkrToday)) {
                        TradeConfirmDocKey oldTcDocKey = dms.getUniqueTradeConfirmDocKey(accountId, tcDay);
                        if (oldTcDocKey != null) {
                            ZonedDateTime ibkrNow = ZonedDateTime.now(IBKR_ZONE_ID);
                            ZonedDateTime oldWhenGenerated = ZonedDateTime.of(oldTcDocKey.day(), oldTcDocKey.whenGenerated(), IBKR_ZONE_ID);
                            boolean oldIsStale = oldWhenGenerated.plus(staleTolerance).isBefore(ibkrNow);
                            if (oldIsStale) {
                                LOG.debug("getPortfolioProgress - old is stale - oldTcDocKey={}, staleTolerance={}, ibkrNow={}", oldTcDocKey, staleTolerance, ibkrNow);
                            } else {
                                LOG.debug("getPortfolioProgress - going to use old - oldTcDocKey={}, staleTolerance={}, ibkrNow={}", oldTcDocKey, staleTolerance, ibkrNow);
                                tcStatement = parser.parseTradeConfirmStatement(dms.getStatementContent(oldTcDocKey));
                            }
                        }
                        if (tcStatement == null) {
                            if (oldTcDocKey != null) {
                                dms.delete(oldTcDocKey);
                            }
                            String tcContent = fetcher.fetchFlexStatement(credentials.token(), credentials.tradeConfirmFlexQueryId(), 2, ofMillis(250));
                            tcStatement = parser.parseTradeConfirmStatement(tcContent);
                            dms.putStatement(new TradeConfirmDocKey(accountId, tcStatement.fromDate(), tcStatement.whenGenerated().toLocalTime()), tcContent);
                        }
                    }
                }
                if (tcStatement == null) {
                    tcStatement = nullSafe(
                            dms.getUniqueTradeConfirmDocKey(accountId, tcDay),
                            dms::getStatementContent,
                            parser::parseTradeConfirmStatement
                    );
                }
            }
            if (tcStatement != null) {
                tcTrades = transactionMapper.mapTradeConfirms(tcStatement.tradeConfirmations());
            } else {
                tcTrades = emptyList();
            }
        }

        List<FinTransaction> newTrans = Stream.of(
                        newCorpActions,
                        newCashTrans,
                        newTrades,
                        tcTrades
                )
                .flatMap(Collection::stream)
                .filter(t -> {
                    LocalDate reportDate = t.reportDate();
                    return !reportDate.isBefore(fromDayIncl) && !reportDate.isAfter(toDayIncl);
                })
                .sorted(comparing(FinTransaction::reportDate))
                .toList();

        SequencedMap<LocalDate, BigDecimal> navs = mergedActStatement.equitySummaries()
                .stream()
                .filter(t -> {
                    LocalDate reportDate = t.reportDate();
                    return !reportDate.isBefore(fromDayIncl) && !reportDate.isAfter(toDayIncl);
                })
                .collect(toMap(EquitySummary::reportDate, EquitySummary::total, (u, v) -> {
                    throw new RuntimeException("Values conflict: %s, %s".formatted(u, v));
                }, LinkedHashMap::new));

        return new PtfProgress(newTrans, navs);
    }
}
