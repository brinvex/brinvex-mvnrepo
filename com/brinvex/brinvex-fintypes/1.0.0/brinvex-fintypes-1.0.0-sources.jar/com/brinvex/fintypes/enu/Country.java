package com.brinvex.fintypes.enu;

public enum Country {

    /**
     * alpha2="AF" <br/> alpha3="AFG" <br/> numCode="004" <br/> name="Afghanistan"
     */
    AF(null),

    /**
     * alpha2="AL" <br/> alpha3="ALB" <br/> numCode="008" <br/> name="Albania"
     */
    AL(null),

    /**
     * alpha2="DZ" <br/> alpha3="DZA" <br/> numCode="012" <br/> name="Algeria"
     */
    DZ(null),

    /**
     * alpha2="AD" <br/> alpha3="AND" <br/> numCode="020" <br/> name="Andorra"
     */
    AD(null),

    /**
     * alpha2="AO" <br/> alpha3="AGO" <br/> numCode="024" <br/> name="Angola"
     */
    AO(null),

    /**
     * alpha2="AG" <br/> alpha3="ATG" <br/> numCode="028" <br/> name="Antigua and Barbuda"
     */
    AG(null),

    /**
     * alpha2="AR" <br/> alpha3="ARG" <br/> numCode="032" <br/> name="Argentina"
     */
    AR(null),

    /**
     * alpha2="AM" <br/> alpha3="ARM" <br/> numCode="051" <br/> name="Armenia"
     */
    AM(null),

    /**
     * alpha2="AU" <br/> alpha3="AUS" <br/> numCode="036" <br/> name="Australia"
     */
    AU(null),

    /**
     * alpha2="AT" <br/> alpha3="AUT" <br/> numCode="040" <br/> name="Austria"
     */
    AT(Currency.EUR),

    /**
     * alpha2="AZ" <br/> alpha3="AZE" <br/> numCode="031" <br/> name="Azerbaijan"
     */
    AZ(null),

    /**
     * alpha2="BS" <br/> alpha3="BHS" <br/> numCode="044" <br/> name="Bahamas"
     */
    BS(null),

    /**
     * alpha2="BH" <br/> alpha3="BHR" <br/> numCode="048" <br/> name="Bahrain"
     */
    BH(null),

    /**
     * alpha2="BD" <br/> alpha3="BGD" <br/> numCode="050" <br/> name="Bangladesh"
     */
    BD(null),

    /**
     * alpha2="BB" <br/> alpha3="BRB" <br/> numCode="052" <br/> name="Barbados"
     */
    BB(null),

    /**
     * alpha2="BY" <br/> alpha3="BLR" <br/> numCode="112" <br/> name="Belarus"
     */
    BY(null),

    /**
     * alpha2="BE" <br/> alpha3="BEL" <br/> numCode="056" <br/> name="Belgium"
     */
    BE(Currency.EUR),

    /**
     * alpha2="BZ" <br/> alpha3="BLZ" <br/> numCode="084" <br/> name="Belize"
     */
    BZ(null),

    /**
     * alpha2="BJ" <br/> alpha3="BEN" <br/> numCode="204" <br/> name="Benin"
     */
    BJ(null),

    /**
     * alpha2="BT" <br/> alpha3="BTN" <br/> numCode="064" <br/> name="Bhutan"
     */
    BT(null),

    /**
     * alpha2="BO" <br/> alpha3="BOL" <br/> numCode="068" <br/> name="Bolivia (Plurinational State of)"
     */
    BO(null),

    /**
     * alpha2="BA" <br/> alpha3="BIH" <br/> numCode="070" <br/> name="Bosnia and Herzegovina"
     */
    BA(null),

    /**
     * alpha2="BW" <br/> alpha3="BWA" <br/> numCode="072" <br/> name="Botswana"
     */
    BW(null),

    /**
     * alpha2="BR" <br/> alpha3="BRA" <br/> numCode="076" <br/> name="Brazil"
     */
    BR(null),

    /**
     * alpha2="BN" <br/> alpha3="BRN" <br/> numCode="096" <br/> name="Brunei Darussalam"
     */
    BN(null),

    /**
     * alpha2="BM" <br/> alpha3="BMU" <br/> numCode="060" <br/> name="Bermuda"
     */
    BM(null),

    /**
     * alpha2="BG" <br/> alpha3="BGR" <br/> numCode="100" <br/> name="Bulgaria"
     */
    BG(null),

    /**
     * alpha2="BF" <br/> alpha3="BFA" <br/> numCode="854" <br/> name="Burkina Faso"
     */
    BF(null),

    /**
     * alpha2="BI" <br/> alpha3="BDI" <br/> numCode="108" <br/> name="Burundi"
     */
    BI(null),

    /**
     * alpha2="CV" <br/> alpha3="CPV" <br/> numCode="132" <br/> name="Cabo Verde"
     */
    CV(null),

    /**
     * alpha2="KH" <br/> alpha3="KHM" <br/> numCode="116" <br/> name="Cambodia"
     */
    KH(null),

    /**
     * alpha2="CM" <br/> alpha3="CMR" <br/> numCode="120" <br/> name="Cameroon"
     */
    CM(null),

    /**
     * alpha2="CA" <br/> alpha3="CAN" <br/> numCode="124" <br/> name="Canada"
     */
    CA(null),

    /**
     * alpha2="CF" <br/> alpha3="CAF" <br/> numCode="140" <br/> name="Central African Republic"
     */
    CF(null),

    /**
     * alpha2="TD" <br/> alpha3="TCD" <br/> numCode="148" <br/> name="Chad"
     */
    TD(null),

    /**
     * alpha2="CL" <br/> alpha3="CHL" <br/> numCode="152" <br/> name="Chile"
     */
    CL(null),

    /**
     * alpha2="CN" <br/> alpha3="CHN" <br/> numCode="156" <br/> name="China"
     */
    CN(null),

    /**
     * alpha2="CO" <br/> alpha3="COL" <br/> numCode="170" <br/> name="Colombia"
     */
    CO(null),

    /**
     * alpha2="KM" <br/> alpha3="COM" <br/> numCode="174" <br/> name="Comoros"
     */
    KM(null),

    /**
     * alpha2="CG" <br/> alpha3="COG" <br/> numCode="178" <br/> name="Congo"
     */
    CG(null),

    /**
     * alpha2="CD" <br/> alpha3="COD" <br/> numCode="180" <br/> name="Congo, Democratic Republic of the"
     */
    CD(null),

    /**
     * alpha2="CR" <br/> alpha3="CRI" <br/> numCode="188" <br/> name="Costa Rica"
     */
    CR(null),

    /**
     * alpha2="CI" <br/> alpha3="CIV" <br/> numCode="384" <br/> name="Côte d'Ivoire"
     */
    CI(null),

    /**
     * alpha2="CW" <br/> alpha3="CUW" <br/> numCode="599" <br/> name="Curacao"
     */
    CW(null),

    /**
     * alpha2="GG" <br/> alpha3="GGY" <br/> numCode="831" <br/> name="Guernsey"
     */
    GG(null),

    /**
     * alpha2="HR" <br/> alpha3="HRV" <br/> numCode="191" <br/> name="Croatia"
     */
    HR(Currency.EUR),

    /**
     * alpha2="CU" <br/> alpha3="CUB" <br/> numCode="192" <br/> name="Cuba"
     */
    CU(null),

    /**
     * alpha2="CY" <br/> alpha3="CYP" <br/> numCode="196" <br/> name="Cyprus"
     */
    CY(Currency.EUR),

    /**
     * alpha2="KY" <br/> alpha3="CYM" <br/> numCode="136" <br/> name="Cayman Islands"
     */
    KY(null),

    /**
     * alpha2="CZ" <br/> alpha3="CZE" <br/> numCode="203" <br/> name="Czechia"
     */
    CZ(Currency.CZK),

    /**
     * alpha2="DK" <br/> alpha3="DNK" <br/> numCode="208" <br/> name="Denmark"
     */
    DK(null),

    /**
     * alpha2="DJ" <br/> alpha3="DJI" <br/> numCode="262" <br/> name="Djibouti"
     */
    DJ(null),

    /**
     * alpha2="DM" <br/> alpha3="DMA" <br/> numCode="212" <br/> name="Dominica"
     */
    DM(null),

    /**
     * alpha2="DO" <br/> alpha3="DOM" <br/> numCode="214" <br/> name="Dominican Republic"
     */
    DO(null),

    /**
     * alpha2="EC" <br/> alpha3="ECU" <br/> numCode="218" <br/> name="Ecuador"
     */
    EC(null),

    /**
     * alpha2="EG" <br/> alpha3="EGY" <br/> numCode="818" <br/> name="Egypt"
     */
    EG(null),

    /**
     * alpha2="SV" <br/> alpha3="SLV" <br/> numCode="222" <br/> name="El Salvador"
     */
    SV(null),

    /**
     * alpha2="GQ" <br/> alpha3="GNQ" <br/> numCode="226" <br/> name="Equatorial Guinea"
     */
    GQ(null),

    /**
     * alpha2="ER" <br/> alpha3="ERI" <br/> numCode="232" <br/> name="Eritrea"
     */
    ER(null),

    /**
     * alpha2="EE" <br/> alpha3="EST" <br/> numCode="233" <br/> name="Estonia"
     */
    EE(Currency.EUR),

    /**
     * alpha2="SZ" <br/> alpha3="SWZ" <br/> numCode="748" <br/> name="Eswatini"
     */
    SZ(null),

    /**
     * alpha2="ET" <br/> alpha3="ETH" <br/> numCode="231" <br/> name="Ethiopia"
     */
    ET(null),

    /**
     * alpha2="FJ" <br/> alpha3="FJI" <br/> numCode="242" <br/> name="Fiji"
     */
    FJ(null),

    /**
     * alpha2="FI" <br/> alpha3="FIN" <br/> numCode="246" <br/> name="Finland"
     */
    FI(Currency.EUR),

    /**
     * alpha2="FR" <br/> alpha3="FRA" <br/> numCode="250" <br/> name="France"
     */
    FR(Currency.EUR),

    /**
     * alpha2="GA" <br/> alpha3="GAB" <br/> numCode="266" <br/> name="Gabon"
     */
    GA(null),

    /**
     * alpha2="GM" <br/> alpha3="GMB" <br/> numCode="270" <br/> name="Gambia"
     */
    GM(null),

    /**
     * alpha2="GE" <br/> alpha3="GEO" <br/> numCode="268" <br/> name="Georgia"
     */
    GE(null),

    /**
     * alpha2="GI" <br/> alpha3="GIB" <br/> numCode="292" <br/> name="Gibraltar"
     */
    GI(null),

    /**
     * alpha2="HK" <br/> alpha3="HKG" <br/> numCode="344" <br/> name="Hong Kong"
     */
    HK(null),

    /**
     * alpha2="DE" <br/> alpha3="DEU" <br/> numCode="276" <br/> name="Germany"
     */
    DE(Currency.EUR),

    /**
     * alpha2="GH" <br/> alpha3="GHA" <br/> numCode="288" <br/> name="Ghana"
     */
    GH(null),

    /**
     * alpha2="GR" <br/> alpha3="GRC" <br/> numCode="300" <br/> name="Greece"
     */
    GR(Currency.EUR),

    /**
     * alpha2="GD" <br/> alpha3="GRD" <br/> numCode="308" <br/> name="Grenada"
     */
    GD(null),

    /**
     * alpha2="GT" <br/> alpha3="GTM" <br/> numCode="320" <br/> name="Guatemala"
     */
    GT(null),

    /**
     * alpha2="GN" <br/> alpha3="GIN" <br/> numCode="324" <br/> name="Guinea"
     */
    GN(null),

    /**
     * alpha2="GW" <br/> alpha3="GNB" <br/> numCode="624" <br/> name="Guinea-Bissau"
     */
    GW(null),

    /**
     * alpha2="GY" <br/> alpha3="GUY" <br/> numCode="328" <br/> name="Guyana"
     */
    GY(null),

    /**
     * alpha2="HT" <br/> alpha3="HTI" <br/> numCode="332" <br/> name="Haiti"
     */
    HT(null),

    /**
     * alpha2="HN" <br/> alpha3="HND" <br/> numCode="340" <br/> name="Honduras"
     */
    HN(null),

    /**
     * alpha2="HU" <br/> alpha3="HUN" <br/> numCode="348" <br/> name="Hungary"
     */
    HU(null),

    /**
     * alpha2="IS" <br/> alpha3="ISL" <br/> numCode="352" <br/> name="Iceland"
     */
    IS(null),

    /**
     * alpha2="IN" <br/> alpha3="IND" <br/> numCode="356" <br/> name="India"
     */
    IN(null),

    /**
     * alpha2="ID" <br/> alpha3="IDN" <br/> numCode="360" <br/> name="Indonesia"
     */
    ID(null),

    /**
     * alpha2="IR" <br/> alpha3="IRN" <br/> numCode="364" <br/> name="Iran (Islamic Republic of)"
     */
    IR(null),

    /**
     * alpha2="IQ" <br/> alpha3="IRQ" <br/> numCode="368" <br/> name="Iraq"
     */
    IQ(null),

    /**
     * alpha2="IE" <br/> alpha3="IRL" <br/> numCode="372" <br/> name="Ireland"
     */
    IE(Currency.EUR),

    /**
     * alpha2="IM" <br/> alpha3="IMN" <br/> numCode="833" <br/> name="Isle of Man"
     */
    IM(null),

    /**
     * alpha2="IL" <br/> alpha3="ISR" <br/> numCode="376" <br/> name="Israel"
     */
    IL(null),

    /**
     * alpha2="IT" <br/> alpha3="ITA" <br/> numCode="380" <br/> name="Italy"
     */
    IT(Currency.EUR),

    /**
     * alpha2="JM" <br/> alpha3="JAM" <br/> numCode="388" <br/> name="Jamaica"
     */
    JM(null),

    /**
     * alpha2="JP" <br/> alpha3="JPN" <br/> numCode="392" <br/> name="Japan"
     */
    JP(null),

    /**
     * alpha2="JE" <br/> alpha3="JEY" <br/> numCode="832" <br/> name="Jersey"
     */
    JE(null),

    /**
     * alpha2="JO" <br/> alpha3="JOR" <br/> numCode="400" <br/> name="Jordan"
     */
    JO(null),

    /**
     * alpha2="KZ" <br/> alpha3="KAZ" <br/> numCode="398" <br/> name="Kazakhstan"
     */
    KZ(null),

    /**
     * alpha2="KE" <br/> alpha3="KEN" <br/> numCode="404" <br/> name="Kenya"
     */
    KE(null),

    /**
     * alpha2="KI" <br/> alpha3="KIR" <br/> numCode="296" <br/> name="Kiribati"
     */
    KI(null),

    /**
     * alpha2="KP" <br/> alpha3="PRK" <br/> numCode="408" <br/> name="Korea (Democratic People's Republic of)"
     */
    KP(null),

    /**
     * alpha2="KR" <br/> alpha3="KOR" <br/> numCode="410" <br/> name="Korea, Republic of"
     */
    KR(null),

    /**
     * alpha2="KW" <br/> alpha3="KWT" <br/> numCode="414" <br/> name="Kuwait"
     */
    KW(null),

    /**
     * alpha2="KG" <br/> alpha3="KGZ" <br/> numCode="417" <br/> name="Kyrgyzstan"
     */
    KG(null),

    /**
     * alpha2="LA" <br/> alpha3="LAO" <br/> numCode="418" <br/> name="Lao People's Democratic Republic"
     */
    LA(null),

    /**
     * alpha2="LV" <br/> alpha3="LVA" <br/> numCode="428" <br/> name="Latvia"
     */
    LV(Currency.EUR),

    /**
     * alpha2="LB" <br/> alpha3="LBN" <br/> numCode="422" <br/> name="Lebanon"
     */
    LB(null),

    /**
     * alpha2="LS" <br/> alpha3="LSO" <br/> numCode="426" <br/> name="Lesotho"
     */
    LS(null),

    /**
     * alpha2="LR" <br/> alpha3="LBR" <br/> numCode="430" <br/> name="Liberia"
     */
    LR(null),

    /**
     * alpha2="LY" <br/> alpha3="LBY" <br/> numCode="434" <br/> name="Libya"
     */
    LY(null),

    /**
     * alpha2="LI" <br/> alpha3="LIE" <br/> numCode="438" <br/> name="Liechtenstein"
     */
    LI(null),

    /**
     * alpha2="LT" <br/> alpha3="LTU" <br/> numCode="440" <br/> name="Lithuania"
     */
    LT(Currency.EUR),

    /**
     * alpha2="LU" <br/> alpha3="LUX" <br/> numCode="442" <br/> name="Luxembourg"
     */
    LU(Currency.EUR),

    /**
     * alpha2="MG" <br/> alpha3="MDG" <br/> numCode="450" <br/> name="Madagascar"
     */
    MG(null),

    /**
     * alpha2="MW" <br/> alpha3="MWI" <br/> numCode="454" <br/> name="Malawi"
     */
    MW(null),

    /**
     * alpha2="MY" <br/> alpha3="MYS" <br/> numCode="458" <br/> name="Malaysia"
     */
    MY(null),

    /**
     * alpha2="MV" <br/> alpha3="MDV" <br/> numCode="462" <br/> name="Maldives"
     */
    MV(null),

    /**
     * alpha2="ML" <br/> alpha3="MLI" <br/> numCode="466" <br/> name="Mali"
     */
    ML(null),

    /**
     * alpha2="MT" <br/> alpha3="MLT" <br/> numCode="470" <br/> name="Malta"
     */
    MT(Currency.EUR),

    /**
     * alpha2="MH" <br/> alpha3="MHL" <br/> numCode="584" <br/> name="Marshall Islands"
     */
    MH(null),

    /**
     * alpha2="MR" <br/> alpha3="MRT" <br/> numCode="478" <br/> name="Mauritania"
     */
    MR(null),

    /**
     * alpha2="MU" <br/> alpha3="MUS" <br/> numCode="480" <br/> name="Mauritius"
     */
    MU(null),

    /**
     * alpha2="MX" <br/> alpha3="MEX" <br/> numCode="484" <br/> name="Mexico"
     */
    MX(null),

    /**
     * alpha2="FM" <br/> alpha3="FSM" <br/> numCode="583" <br/> name="Micronesia (Federated States of)"
     */
    FM(null),

    /**
     * alpha2="MD" <br/> alpha3="MDA" <br/> numCode="498" <br/> name="Moldova, Republic of"
     */
    MD(null),

    /**
     * alpha2="MC" <br/> alpha3="MCO" <br/> numCode="492" <br/> name="Monaco"
     */
    MC(null),

    /**
     * alpha2="MN" <br/> alpha3="MNG" <br/> numCode="496" <br/> name="Mongolia"
     */
    MN(null),

    /**
     * alpha2="ME" <br/> alpha3="MNE" <br/> numCode="499" <br/> name="Montenegro"
     */
    ME(null),

    /**
     * alpha2="MA" <br/> alpha3="MAR" <br/> numCode="504" <br/> name="Morocco"
     */
    MA(null),

    /**
     * alpha2="MO" <br/> alpha3="MAC" <br/> numCode="446" <br/> name="Macao"
     */
    MO(null),

    /**
     * alpha2="MZ" <br/> alpha3="MOZ" <br/> numCode="508" <br/> name="Mozambique"
     */
    MZ(null),

    /**
     * alpha2="MM" <br/> alpha3="MMR" <br/> numCode="104" <br/> name="Myanmar"
     */
    MM(null),

    /**
     * alpha2="NA" <br/> alpha3="NAM" <br/> numCode="516" <br/> name="Namibia"
     */
    NA(null),

    /**
     * alpha2="NR" <br/> alpha3="NRU" <br/> numCode="520" <br/> name="Nauru"
     */
    NR(null),

    /**
     * alpha2="NP" <br/> alpha3="NPL" <br/> numCode="524" <br/> name="Nepal"
     */
    NP(null),

    /**
     * alpha2="NL" <br/> alpha3="NLD" <br/> numCode="528" <br/> name="Netherlands"
     */
    NL(Currency.EUR),

    /**
     * alpha2="NZ" <br/> alpha3="NZL" <br/> numCode="554" <br/> name="New Zealand"
     */
    NZ(null),

    /**
     * alpha2="NI" <br/> alpha3="NIC" <br/> numCode="558" <br/> name="Nicaragua"
     */
    NI(null),

    /**
     * alpha2="NE" <br/> alpha3="NER" <br/> numCode="562" <br/> name="Niger"
     */
    NE(null),

    /**
     * alpha2="NG" <br/> alpha3="NGA" <br/> numCode="566" <br/> name="Nigeria"
     */
    NG(null),

    /**
     * alpha2="MK" <br/> alpha3="MKD" <br/> numCode="807" <br/> name="North Macedonia"
     */
    MK(null),

    /**
     * alpha2="NO" <br/> alpha3="NOR" <br/> numCode="578" <br/> name="Norway"
     */
    NO(null),

    /**
     * alpha2="OM" <br/> alpha3="OMN" <br/> numCode="512" <br/> name="Oman"
     */
    OM(null),

    /**
     * alpha2="PK" <br/> alpha3="PAK" <br/> numCode="586" <br/> name="Pakistan"
     */
    PK(null),

    /**
     * alpha2="PW" <br/> alpha3="PLW" <br/> numCode="585" <br/> name="Palau"
     */
    PW(null),

    /**
     * alpha2="PA" <br/> alpha3="PAN" <br/> numCode="591" <br/> name="Panama"
     */
    PA(null),

    /**
     * alpha2="PG" <br/> alpha3="PNG" <br/> numCode="598" <br/> name="Papua New Guinea"
     */
    PG(null),

    /**
     * alpha2="PY" <br/> alpha3="PRY" <br/> numCode="600" <br/> name="Paraguay"
     */
    PY(null),

    /**
     * alpha2="PR" <br/> alpha3="PRI" <br/> numCode="630" <br/> name="Puerto Rico"
     */
    PR(null),

    /**
     * alpha2="PE" <br/> alpha3="PER" <br/> numCode="604" <br/> name="Peru"
     */
    PE(null),

    /**
     * alpha2="PH" <br/> alpha3="PHL" <br/> numCode="608" <br/> name="Philippines"
     */
    PH(null),

    /**
     * alpha2="PL" <br/> alpha3="POL" <br/> numCode="616" <br/> name="Poland"
     */
    PL(null),

    /**
     * alpha2="PT" <br/> alpha3="PRT" <br/> numCode="620" <br/> name="Portugal"
     */
    PT(Currency.EUR),

    /**
     * alpha2="QA" <br/> alpha3="QAT" <br/> numCode="634" <br/> name="Qatar"
     */
    QA(null),

    /**
     * alpha2="RO" <br/> alpha3="ROU" <br/> numCode="642" <br/> name="Romania"
     */
    RO(null),

    /**
     * alpha2="RU" <br/> alpha3="RUS" <br/> numCode="643" <br/> name="Russian Federation"
     */
    RU(null),

    /**
     * alpha2="RW" <br/> alpha3="RWA" <br/> numCode="646" <br/> name="Rwanda"
     */
    RW(null),

    /**
     * alpha2="KN" <br/> alpha3="KNA" <br/> numCode="659" <br/> name="Saint Kitts and Nevis"
     */
    KN(null),

    /**
     * alpha2="LC" <br/> alpha3="LCA" <br/> numCode="662" <br/> name="Saint Lucia"
     */
    LC(null),

    /**
     * alpha2="VC" <br/> alpha3="VCT" <br/> numCode="670" <br/> name="Saint Vincent and the Grenadines"
     */
    VC(null),

    /**
     * alpha2="WS" <br/> alpha3="WSM" <br/> numCode="882" <br/> name="Samoa"
     */
    WS(null),

    /**
     * alpha2="SM" <br/> alpha3="SMR" <br/> numCode="674" <br/> name="San Marino"
     */
    SM(null),

    /**
     * alpha2="ST" <br/> alpha3="STP" <br/> numCode="678" <br/> name="Sao Tome and Principe"
     */
    ST(null),

    /**
     * alpha2="SA" <br/> alpha3="SAU" <br/> numCode="682" <br/> name="Saudi Arabia"
     */
    SA(null),

    /**
     * alpha2="SN" <br/> alpha3="SEN" <br/> numCode="686" <br/> name="Senegal"
     */
    SN(null),

    /**
     * alpha2="RS" <br/> alpha3="SRB" <br/> numCode="688" <br/> name="Serbia"
     */
    RS(null),

    /**
     * alpha2="SC" <br/> alpha3="SYC" <br/> numCode="690" <br/> name="Seychelles"
     */
    SC(null),

    /**
     * alpha2="SL" <br/> alpha3="SLE" <br/> numCode="694" <br/> name="Sierra Leone"
     */
    SL(null),

    /**
     * alpha2="SG" <br/> alpha3="SGP" <br/> numCode="702" <br/> name="Singapore"
     */
    SG(null),

    /**
     * alpha2="SK" <br/> alpha3="SVK" <br/> numCode="703" <br/> name="Slovakia"
     */
    SK(Currency.EUR),

    /**
     * alpha2="SI" <br/> alpha3="SVN" <br/> numCode="705" <br/> name="Slovenia"
     */
    SI(Currency.EUR),

    /**
     * alpha2="SB" <br/> alpha3="SLB" <br/> numCode="090" <br/> name="Solomon Islands"
     */
    SB(null),

    /**
     * alpha2="SO" <br/> alpha3="SOM" <br/> numCode="706" <br/> name="Somalia"
     */
    SO(null),

    /**
     * alpha2="ZA" <br/> alpha3="ZAF" <br/> numCode="710" <br/> name="South Africa"
     */
    ZA(null),

    /**
     * alpha2="SS" <br/> alpha3="SSD" <br/> numCode="728" <br/> name="South Sudan"
     */
    SS(null),

    /**
     * alpha2="ES" <br/> alpha3="ESP" <br/> numCode="724" <br/> name="Spain"
     */
    ES(Currency.EUR),

    /**
     * alpha2="LK" <br/> alpha3="LKA" <br/> numCode="144" <br/> name="Sri Lanka"
     */
    LK(null),

    /**
     * alpha2="SD" <br/> alpha3="SDN" <br/> numCode="729" <br/> name="Sudan"
     */
    SD(null),

    /**
     * alpha2="SR" <br/> alpha3="SUR" <br/> numCode="740" <br/> name="Suriname"
     */
    SR(null),

    /**
     * alpha2="SE" <br/> alpha3="SWE" <br/> numCode="752" <br/> name="Sweden"
     */
    SE(null),

    /**
     * alpha2="CH" <br/> alpha3="CHE" <br/> numCode="756" <br/> name="Switzerland"
     */
    CH(null),

    /**
     * alpha2="SY" <br/> alpha3="SYR" <br/> numCode="760" <br/> name="Syrian Arab Republic"
     */
    SY(null),

    /**
     * alpha2="TJ" <br/> alpha3="TJK" <br/> numCode="762" <br/> name="Tajikistan"
     */
    TJ(null),

    /**
     * alpha2="TZ" <br/> alpha3="TZA" <br/> numCode="834" <br/> name="Tanzania, United Republic of"
     */
    TZ(null),

    /**
     * alpha2="TH" <br/> alpha3="THA" <br/> numCode="764" <br/> name="Thailand"
     */
    TH(null),

    /**
     * alpha2="TL" <br/> alpha3="TLS" <br/> numCode="626" <br/> name="Timor-Leste"
     */
    TL(null),

    /**
     * alpha2="TG" <br/> alpha3="TGO" <br/> numCode="768" <br/> name="Togo"
     */
    TG(null),

    /**
     * alpha2="TO" <br/> alpha3="TON" <br/> numCode="776" <br/> name="Tonga"
     */
    TO(null),

    /**
     * alpha2="TT" <br/> alpha3="TTO" <br/> numCode="780" <br/> name="Trinidad and Tobago"
     */
    TT(null),

    /**
     * alpha2="TN" <br/> alpha3="TUN" <br/> numCode="788" <br/> name="Tunisia"
     */
    TN(null),

    /**
     * alpha2="TR" <br/> alpha3="TUR" <br/> numCode="792" <br/> name="Turkey"
     */
    TR(null),

    /**
     * alpha2="TM" <br/> alpha3="TKM" <br/> numCode="795" <br/> name="Turkmenistan"
     */
    TM(null),

    /**
     * alpha2="TW" <br/> alpha3="TWN" <br/> numCode="158" <br/> name="Taiwan (Province of China)"
     */
    TW(null),

    /**
     * alpha2="TV" <br/> alpha3="TUV" <br/> numCode="798" <br/> name="Tuvalu"
     */
    TV(null),

    /**
     * alpha2="UG" <br/> alpha3="UGA" <br/> numCode="800" <br/> name="Uganda"
     */
    UG(null),

    /**
     * alpha2="UA" <br/> alpha3="UKR" <br/> numCode="804" <br/> name="Ukraine"
     */
    UA(null),

    /**
     * alpha2="AE" <br/> alpha3="ARE" <br/> numCode="784" <br/> name="United Arab Emirates"
     */
    AE(null),

    /**
     * alpha2="GB" <br/> alpha3="GBR" <br/> numCode="826" <br/> name="United Kingdom of Great Britain and Northern Ireland"
     */
    GB(null),

    /**
     * alpha2="US" <br/> alpha3="USA" <br/> numCode="840" <br/> name="United States of America"
     */
    US(Currency.USD),

    /**
     * alpha2="UY" <br/> alpha3="URY" <br/> numCode="858" <br/> name="Uruguay"
     */
    UY(null),

    /**
     * alpha2="UZ" <br/> alpha3="UZB" <br/> numCode="860" <br/> name="Uzbekistan"
     */
    UZ(null),

    /**
     * alpha2="VU" <br/> alpha3="VUT" <br/> numCode="548" <br/> name="Vanuatu"
     */
    VU(null),

    /**
     * alpha2="VG" <br/> alpha3="VGB" <br/> numCode="092" <br/> name="Virgin Islands (British)"
     */
    VG(null),

    /**
     * alpha2="VE" <br/> alpha3="VEN" <br/> numCode="862" <br/> name="Venezuela (Bolivarian Republic of)"
     */
    VE(null),

    /**
     * alpha2="VN" <br/> alpha3="VNM" <br/> numCode="704" <br/> name="Vietnam"
     */
    VN(null),

    /**
     * alpha2="YE" <br/> alpha3="YEM" <br/> numCode="887" <br/> name="Yemen"
     */
    YE(null),

    /**
     * alpha2="ZM" <br/> alpha3="ZMB" <br/> numCode="894" <br/> name="Zambia"
     */
    ZM(null),

    /**
     * alpha2="ZW" <br/> alpha3="ZWE" <br/> numCode="716" <br/> name="Zimbabwe"
     */
    ZW(null),
    ;

    private final Currency ccy;

    Country(Currency ccy) {
        this.ccy = ccy;
    }

    public String alpha2code() {
        return name();
    }

    public Currency ccy() {
        if (ccy == null) {
            throw new IllegalStateException("Currency not defined for country: " + this);
        }
        return ccy;
    }

}
