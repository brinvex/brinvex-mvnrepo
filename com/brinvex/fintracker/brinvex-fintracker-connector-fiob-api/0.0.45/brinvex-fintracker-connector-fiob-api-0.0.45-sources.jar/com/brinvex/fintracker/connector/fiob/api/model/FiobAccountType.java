package com.brinvex.fintracker.connector.fiob.api.model;

public enum FiobAccountType {

    SAVING,

    TRADING
}
