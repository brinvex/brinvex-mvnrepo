package com.brinvex.fintracker.connector.amnd.api.service;

import com.brinvex.fintracker.connector.amnd.api.model.statement.Trade;
import com.brinvex.fintracker.core.api.domain.vo.FinTransaction;

import java.util.List;

public interface AmndFinTransactionMapper {

    List<FinTransaction.FinTransactionBuilder> mapTradeToFinTransactionPair(Trade trade);

}
