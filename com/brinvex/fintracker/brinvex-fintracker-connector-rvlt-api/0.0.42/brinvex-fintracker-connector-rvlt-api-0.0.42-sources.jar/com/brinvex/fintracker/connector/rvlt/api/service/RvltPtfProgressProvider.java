package com.brinvex.fintracker.connector.rvlt.api.service;

import com.brinvex.fintracker.connector.rvlt.api.model.RvltAccount;
import com.brinvex.fintracker.core.api.model.domain.PtfProgress;

import java.time.LocalDate;

public interface RvltPtfProgressProvider {

    PtfProgress getPtfProgress(
            RvltAccount rvltAccount,
            LocalDate fromDateIncl,
            LocalDate toDateIncl
    );
}
