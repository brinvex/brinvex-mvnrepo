package com.brinvex.fintracker.core.api.internal;

import com.brinvex.fintracker.core.api.facade.HttpClientFacade;
import com.brinvex.fintracker.core.api.facade.PdfReaderFacade;
import com.brinvex.fintracker.core.api.facade.ValidatorFacade;
import com.brinvex.util.dms.api.DmsFactory;

public interface FinTrackerSupport {

    DmsFactory dmsFactory();

    HttpClientFacade httpClient();

    ValidatorFacade validator();

    PdfReaderFacade pdfReader();

}
