/*
 * Copyright © 2023 Brinvex (dev@brinvex.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.brinvex.util.ibkr.api.model.statement;

import com.brinvex.util.ibkr.api.model.Currency;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.ZonedDateTime;

public record Trade(
        Currency currency,
        AssetCategory assetCategory,
        AssetSubCategory assetSubCategory,
        String symbol,
        String description,
        String securityID,
        SecurityIDType securityIDType,
        String figi,
        String isin,
        String listingExchange,
        String tradeID,
        LocalDate reportDate,
        LocalDate tradeDate,
        LocalDate settleDateTarget,
        TradeType transactionType,
        String exchange,
        BigDecimal quantity,
        BigDecimal tradePrice,
        BigDecimal tradeMoney,
        BigDecimal proceeds,
        BigDecimal taxes,
        BigDecimal ibCommission,
        Currency ibCommissionCurrency,
        BigDecimal netCash,
        BigDecimal cost,
        BuySell buySell,
        String transactionID,
        String ibOrderID,
        String extraDateTimeStr,
        ZonedDateTime orderTime
) implements Serializable {

    public Trade {
        if (assetCategory == null && assetSubCategory != null) {
            throw new IllegalArgumentException("assetCategory cannot be null when assetSubCategory is not null");
        }
    }

}
