package com.brinvex.fintracker.connector.rvlt.api.service;

import com.brinvex.fintracker.connector.rvlt.api.model.RvltAccount;
import com.brinvex.fintracker.core.api.domain.dto.PtfProgress;
import com.brinvex.fintracker.core.api.provider.PtfProgressProvider;

import java.time.LocalDate;

public interface RvltPtfProgressProvider extends PtfProgressProvider {

    PtfProgress getPtfProgress(
            RvltAccount rvltAccount,
            LocalDate fromDateIncl,
            LocalDate toDateIncl
    );
}
