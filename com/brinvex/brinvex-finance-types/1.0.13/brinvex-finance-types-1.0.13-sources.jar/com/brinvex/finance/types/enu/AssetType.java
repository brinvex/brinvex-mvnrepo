package com.brinvex.finance.types.enu;

public enum AssetType {

    CASH,

    STOCK,

    ETF,

    FUND,

    BOND,

    DERIVATIVE,

}
