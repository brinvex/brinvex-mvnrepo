package com.brinvex.util.ibkr.api.service;

import com.brinvex.util.ibkr.api.model.statement.FlexStatement.ActivityStatement;
import com.brinvex.util.ibkr.api.model.statement.FlexStatement.TradeConfirmStatement;

public interface IbkrStatementParser {

    ActivityStatement parseActivityStatement(String statementXmlContent);

    TradeConfirmStatement parseTradeConfirmStatement(String statementXmlContent);

    static IbkrStatementParser create() {
        try {
            return (IbkrStatementParser) Class.forName("com.brinvex.util.ibkr.impl.IbkrStatementParserImpl")
                    .getConstructor()
                    .newInstance();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

}
