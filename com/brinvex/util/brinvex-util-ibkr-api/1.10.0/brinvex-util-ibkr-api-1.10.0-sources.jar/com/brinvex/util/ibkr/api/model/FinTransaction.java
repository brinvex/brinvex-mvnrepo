package com.brinvex.util.ibkr.api.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDate;

public record FinTransaction(
        String id,
        LocalDate reportDate,
        FinTransactionType type,
        Country country,
        String symbol,
        String isin,
        String figi,
        InstrumentType instrumentType,
        BigDecimal qty,
        Currency currency,
        BigDecimal price,
        BigDecimal grossValue,
        BigDecimal netValue,
        BigDecimal tax,
        BigDecimal fees,
        LocalDate settleDate,
        String description,
        String extraDateTimeStr
) implements Serializable {

    public FinTransaction(
            String id,
            LocalDate reportDate,
            FinTransactionType type,
            Country country,
            String symbol,
            String isin,
            String figi,
            InstrumentType instrumentType,
            BigDecimal qty,
            Currency currency,
            BigDecimal price,
            BigDecimal grossValue,
            BigDecimal netValue,
            BigDecimal tax,
            BigDecimal fees,
            LocalDate settleDate,
            String description,
            String extraDateTimeStr
    ) {
        this.id = id;
        this.reportDate = reportDate;
        this.type = type;
        this.country = country;
        this.symbol = symbol;
        this.isin = isin;
        this.figi = figi;
        this.instrumentType = instrumentType;
        this.qty = qty;
        this.currency = currency;
        this.price = price;
        this.grossValue = grossValue;
        this.netValue = netValue;
        this.tax = tax;
        this.fees = fees;
        this.settleDate = settleDate;
        this.description = description;
        this.extraDateTimeStr = extraDateTimeStr;

        if (!type.transactionIsValid(this)) {
            throw new IllegalArgumentException("Transaction is not valid: %s".formatted(this));
        }
    }
}
