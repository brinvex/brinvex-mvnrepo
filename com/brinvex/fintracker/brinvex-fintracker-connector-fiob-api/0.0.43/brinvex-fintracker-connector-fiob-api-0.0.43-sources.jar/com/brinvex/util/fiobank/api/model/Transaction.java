package com.brinvex.util.fiobank.api.model;

import com.brinvex.fintracker.core.api.model.domain.Asset;
import com.brinvex.fintracker.core.api.model.domain.AssetType;
import com.brinvex.fintracker.core.api.model.domain.FinTransaction;
import com.brinvex.fintracker.core.api.model.domain.FinTransactionType;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDate;

@Getter
@Setter
@Accessors(chain = true, fluent = true)
public class Transaction implements Serializable {

    private String id;

    private LocalDate date;

    private TransactionType type;

    private Country country;

    private String symbol;

    private BigDecimal qty;

    private Currency ccy;

    private BigDecimal price;

    private BigDecimal grossValue;

    private BigDecimal netValue;

    private BigDecimal tax;

    private BigDecimal fees;

    private LocalDate settleDate;

    private String bunchId;

    private String note;


    public FinTransaction toFinTransaction() {
        return FinTransaction.builder()
                .type(mapTranType(type))
                .date(date)
                .ccy(ccy.name())
                .netValue(netValue)
                .qty(qty)
                .price(price)
                .asset(symbol == null ? null : Asset.builder()
                        //todo 5
                        .type(AssetType.STOCK)
                        .symbol(symbol)
                        .country(country.name())
                        .build())
                .grossValue(grossValue)
                .tax(tax)
                .fee(fees)
                .settleDate(settleDate)
                .groupId(bunchId)
                .extraId(id)
                .extraType(type.toString())
                .extraDetail(note)
                .build();
    }

    private FinTransactionType mapTranType(com.brinvex.util.fiobank.api.model.TransactionType fiobType) {
        return switch (fiobType) {
            case BUY -> FinTransactionType.BUY;
            case SELL -> FinTransactionType.SELL;
            case DEPOSIT -> FinTransactionType.DEPOSIT;
            case WITHDRAWAL -> FinTransactionType.WITHDRAWAL;
            case CAPITAL_DIVIDEND -> FinTransactionType.CASH_DIVIDEND;
            case STOCK_DIVIDEND -> FinTransactionType.CASH_DIVIDEND;
            case DIVIDEND_REVERSAL -> FinTransactionType.CASH_DIVIDEND;
            case CASH_DIVIDEND -> FinTransactionType.CASH_DIVIDEND;
            case INTEREST -> FinTransactionType.INTEREST;
            case FX_BUY -> FinTransactionType.FX_BUY;
            case FX_SELL -> FinTransactionType.FX_SELL;
            case FEE -> FinTransactionType.FEE;
            case TAX -> FinTransactionType.TAX;
            case TAX_REFUND -> FinTransactionType.TAX;
            case RECLAMATION -> FinTransactionType.OTHER_INTERNAL_FLOW;
            case INSTRUMENT_CHANGE_CHILD -> FinTransactionType.TRANSFORMATION;
            case MERGER_CHILD -> FinTransactionType.TRANSFORMATION;
            case MERGER_PARENT -> FinTransactionType.TRANSFORMATION;
            case LIQUIDATION -> FinTransactionType.TRANSFORMATION;
            case SPLIT -> FinTransactionType.TRANSFORMATION;
            case SPINOFF_VALUE -> FinTransactionType.TRANSFORMATION;
            case SPINOFF_CHILD -> FinTransactionType.TRANSFORMATION;
            case SPINOFF_PARENT -> FinTransactionType.TRANSFORMATION;
            case INSTRUMENT_CHANGE_PARENT -> FinTransactionType.TRANSFORMATION;
        };
    }

    private Country mapCountry(com.brinvex.util.fiobank.api.model.Country fiobCountry) {
        return fiobCountry == null ? null : switch (fiobCountry) {
            case US -> Country.US;
            case CZ -> Country.CZ;
            case DE -> Country.DE;
        };
    }

    private Currency mapCurrency(com.brinvex.util.fiobank.api.model.Currency fiobCcy) {
        return fiobCcy == null ? null : switch (fiobCcy) {
            case CZK -> Currency.CZK;
            case EUR -> Currency.EUR;
            case USD -> Currency.USD;
        };
    }

}
