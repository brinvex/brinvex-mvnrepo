package com.brinvex.fintracker.core.api.infra;

import com.brinvex.fintracker.core.api.facade.PdfReaderFacade;
import com.brinvex.fintracker.core.api.facade.ValidatorFacade;
import com.brinvex.util.dms.api.DmsFactory;

public interface FinTrackerSupport {

    DmsFactory dmsFactory();

    ValidatorFacade validator();

    PdfReaderFacade pdfReader();

}
