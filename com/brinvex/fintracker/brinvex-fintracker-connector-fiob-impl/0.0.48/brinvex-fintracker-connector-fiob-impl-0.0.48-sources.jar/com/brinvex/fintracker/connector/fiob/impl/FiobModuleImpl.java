package com.brinvex.fintracker.connector.fiob.impl;

import com.brinvex.fintracker.connector.fiob.api.FiobModule;
import com.brinvex.fintracker.connector.fiob.api.service.FiobDms;
import com.brinvex.fintracker.connector.fiob.api.service.FiobFetcher;
import com.brinvex.fintracker.connector.fiob.api.service.FiobFinTransactionMapper;
import com.brinvex.fintracker.connector.fiob.api.service.FiobPtfProgressProvider;
import com.brinvex.fintracker.connector.fiob.api.service.FiobStatementMerger;
import com.brinvex.fintracker.connector.fiob.api.service.FiobStatementParser;
import com.brinvex.fintracker.connector.fiob.impl.service.FiobDmsImpl;
import com.brinvex.fintracker.connector.fiob.impl.service.FiobFetcherImpl;
import com.brinvex.fintracker.connector.fiob.impl.service.FiobPtfProgressProviderImpl;
import com.brinvex.fintracker.connector.fiob.impl.service.FiobStatementMergerImpl;
import com.brinvex.fintracker.connector.fiob.impl.service.mapper.FiobFinTransactionMapperImpl;
import com.brinvex.fintracker.connector.fiob.impl.service.parser.FiobStatementParserImpl;
import com.brinvex.fintracker.core.api.FinTrackerModule;
import com.brinvex.fintracker.core.api.FinTrackerModuleContext;
import com.brinvex.fintracker.core.api.FinTrackerModuleFactory;
import com.brinvex.fintracker.core.api.provider.Provider;
import com.brinvex.fintracker.core.api.provider.PtfProgressProvider;

import java.util.List;
import java.util.SequencedCollection;
import java.util.Set;

import static java.util.Collections.emptyList;

public class FiobModuleImpl implements FiobModule, FinTrackerModule {

    public static class FiobModuleFactory implements FinTrackerModuleFactory<FiobModule> {

        @Override
        public Class<FiobModule> moduleType() {
            return FiobModule.class;
        }

        @Override
        public Set<Class<? extends Provider<?, ?>>> providerTypes() {
            return Set.of(PtfProgressProvider.class);
        }

        @Override
        public FiobModule createModule(FinTrackerModuleContext moduleCtx) {
            return new FiobModuleImpl(moduleCtx);
        }
    }

    private final FinTrackerModuleContext moduleCtx;

    public FiobModuleImpl(FinTrackerModuleContext moduleCtx) {
        this.moduleCtx = moduleCtx;
    }

    @Override
    public SequencedCollection<Provider<?, ?>> providers(Class<? extends Provider<?, ?>> providerType) {
        if (providerType == PtfProgressProvider.class) {
            return List.of(ptfProgressProvider());
        }
        return emptyList();
    }

    @Override
    public FiobFetcher fetcher() {
        return moduleCtx.singletonService(FiobFetcher.class, FiobFetcherImpl::new);
    }

    @Override
    public FiobDms dms() {
        return moduleCtx.singletonService(FiobDms.class, () -> new FiobDmsImpl(moduleCtx.dms()));
    }

    @Override
    public FiobStatementParser statementParser() {
        return moduleCtx.singletonService(FiobStatementParser.class, FiobStatementParserImpl::new);
    }

    @Override
    public FiobStatementMerger statementMerger() {
        return moduleCtx.singletonService(FiobStatementMerger.class, FiobStatementMergerImpl::new);
    }

    @Override
    public FiobFinTransactionMapper finTransactionMapper() {
        return moduleCtx.singletonService(FiobFinTransactionMapper.class, FiobFinTransactionMapperImpl::new);
    }

    @Override
    public FiobPtfProgressProvider ptfProgressProvider() {
        return moduleCtx.singletonService(FiobPtfProgressProvider.class, () -> new FiobPtfProgressProviderImpl(
                dms(),
                statementParser(),
                fetcher(),
                statementMerger(),
                finTransactionMapper()
        ));
    }
}
