package com.brinvex.fintracker.core.impl.service;

import com.brinvex.fintracker.core.api.domain.active.PtfRuntime;
import com.brinvex.fintracker.core.api.service.PtfService;
import com.brinvex.fintracker.core.impl.domain.active.PtfRuntimeImpl;

public class PtfServiceImpl implements PtfService {

    @Override
    public PtfRuntime newPtfRuntime() {
        return new PtfRuntimeImpl();
    }

}
