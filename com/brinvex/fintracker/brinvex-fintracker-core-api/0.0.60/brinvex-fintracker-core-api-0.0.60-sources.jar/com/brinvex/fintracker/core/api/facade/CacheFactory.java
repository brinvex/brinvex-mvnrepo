package com.brinvex.fintracker.core.api.facade;

@FunctionalInterface
public interface CacheFactory {

    CacheFacade getCache(String name);
}
