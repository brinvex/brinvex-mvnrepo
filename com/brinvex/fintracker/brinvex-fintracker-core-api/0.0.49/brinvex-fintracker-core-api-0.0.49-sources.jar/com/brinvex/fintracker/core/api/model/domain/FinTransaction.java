package com.brinvex.fintracker.core.api.model.domain;

import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDate;

import static java.math.BigDecimal.ZERO;
import static java.util.Objects.requireNonNullElse;

public record FinTransaction(
        String id,
        FinTransactionType type,
        LocalDate date,
        String ccy,
        BigDecimal netValue,
        BigDecimal qty,
        BigDecimal price,
        Asset asset,
        BigDecimal grossValue,
        BigDecimal tax,
        BigDecimal fee,
        LocalDate settleDate,
        String groupId,
        String extraId,
        String extraType,
        String extraDetail
) implements Serializable {

    public FinTransaction {
        if (type == null) {
            throw new IllegalArgumentException("type must not be null");
        }
    }

    public static FinTransactionBuilder builder() {
        return new FinTransactionBuilder();
    }

    @Getter
    @Setter
    @Accessors(fluent = true, chain = true)
    public static class FinTransactionBuilder {
        private String id;
        private FinTransactionType type;
        private LocalDate date;
        private String ccy;
        private BigDecimal netValue;
        private BigDecimal qty;
        private BigDecimal price;
        private Asset asset;
        private BigDecimal grossValue;
        private BigDecimal tax;
        private BigDecimal fee;
        private LocalDate settleDate;
        private String groupId;
        private String extraId;
        private String extraType;
        private String extraDetail;

        FinTransactionBuilder() {
        }

        public FinTransaction build() {
            return new FinTransaction(
                    this.id,
                    this.type,
                    this.date,
                    this.ccy,
                    this.netValue,
                    this.qty,
                    this.price,
                    this.asset,
                    this.grossValue,
                    this.tax,
                    this.fee,
                    this.settleDate,
                    this.groupId,
                    this.extraId,
                    this.extraType,
                    this.extraDetail
            );
        }

        public FinTransactionBuilder reconcileNetValue() {
            netValue = requireNonNullElse(grossValue, ZERO).add(requireNonNullElse(fee, ZERO)).add(requireNonNullElse(tax, ZERO));
            return this;
        }

        public FinTransactionBuilder reconcileGrossValue() {
            grossValue = requireNonNullElse(netValue, ZERO).subtract(requireNonNullElse(fee, ZERO)).subtract(requireNonNullElse(tax, ZERO));
            return this;
        }

    }
}
