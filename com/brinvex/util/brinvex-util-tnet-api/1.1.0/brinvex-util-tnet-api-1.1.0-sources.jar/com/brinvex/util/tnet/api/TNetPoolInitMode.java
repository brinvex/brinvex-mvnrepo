package com.brinvex.util.tnet.api;

public enum TNetPoolInitMode {

    ALL_LAZY,

    ONE_EAGER,

    ALL_EAGER,

}
