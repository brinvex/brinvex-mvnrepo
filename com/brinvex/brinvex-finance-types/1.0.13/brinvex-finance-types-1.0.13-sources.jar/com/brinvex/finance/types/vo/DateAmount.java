package com.brinvex.finance.types.vo;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Map;
import java.util.function.BiFunction;
import java.util.function.Function;

public record DateAmount(
        LocalDate date,
        BigDecimal amount
) implements Serializable {

    public DateAmount {
        if (date == null) {
            throw new IllegalArgumentException("date must not be null, rate=%s".formatted(amount));
        }
        if (amount == null) {
            throw new IllegalArgumentException("rate must not be null, date=%s".formatted(date));
        }
    }

    public DateAmount(String date, String amount) {
        this(LocalDate.parse(date), new BigDecimal(amount));
    }

    public DateAmount(Map.Entry<LocalDate, BigDecimal> mapEntry) {
        this(mapEntry.getKey(), mapEntry.getValue());
    }

    public boolean isBefore(LocalDate date) {
        return this.date.isBefore(date);
    }

    public boolean isAfter(LocalDate date) {
        return this.date.isAfter(date);
    }

    public DateAmount combine(DateAmount other, BiFunction<BigDecimal, BigDecimal, BigDecimal> amountOperation) {
        if (!date.isEqual(other.date())) {
            throw new IllegalArgumentException(
                    "Add operation not allowed for different dates: %s, %s.".formatted(this, other)
            );
        }
        return new DateAmount(date, amountOperation.apply(amount, other.amount));
    }

    public DateAmount add(DateAmount other) {
        return combine(other, BigDecimal::add);
    }

    public DateAmount subtract(DateAmount other) {
        return combine(other, BigDecimal::subtract);
    }

    public DateAmount with(Function<BigDecimal, BigDecimal> amountOperation) {
        return new DateAmount(date, amountOperation.apply(amount));
    }

    @Override
    public String toString() {
        return "DateAmount[%s/%s]".formatted(date, amount.toPlainString());
    }

}
