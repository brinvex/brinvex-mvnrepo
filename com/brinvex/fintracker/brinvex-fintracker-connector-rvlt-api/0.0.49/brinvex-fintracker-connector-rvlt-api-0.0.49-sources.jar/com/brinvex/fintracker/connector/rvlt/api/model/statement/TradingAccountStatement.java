package com.brinvex.fintracker.connector.rvlt.api.model.statement;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

public record TradingAccountStatement(
        String accountName,
        String accountNumber,
        LocalDate periodStartIncl,
        LocalDate periodEndIncl,
        String ccy,
        BigDecimal startStocksValue,
        BigDecimal startCashValue,
        BigDecimal startValue,
        BigDecimal endStocksValue,
        BigDecimal endCashValue,
        BigDecimal endValue,
        List<Transaction> transactions
) {
}
