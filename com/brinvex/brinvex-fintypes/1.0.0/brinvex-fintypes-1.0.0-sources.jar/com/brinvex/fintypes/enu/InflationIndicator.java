package com.brinvex.fintypes.enu;

public enum InflationIndicator {

    CPI,

    YOY_RATE,

    MONTH_RATE,

}
