package com.brinvex.util.ibkr.api.service;

import com.brinvex.util.ibkr.api.model.FinTransaction;
import com.brinvex.util.ibkr.api.model.statement.CashTransaction;
import com.brinvex.util.ibkr.api.model.statement.CorporateAction;
import com.brinvex.util.ibkr.api.model.statement.Trade;
import com.brinvex.util.ibkr.api.model.statement.TradeConfirm;

import java.util.List;

public interface IbkrTransactionMapper {

    List<FinTransaction> mapCashTransactions(List<CashTransaction> cashTrans);

    List<FinTransaction> mapTrades(List<Trade> trades);

    List<FinTransaction> mapCorporateAction(List<CorporateAction> corpActions);

    List<FinTransaction> mapTradeConfirms(List<TradeConfirm> tradeConfirms);

    static IbkrTransactionMapper create() {
        try {
            return (IbkrTransactionMapper) Class.forName("com.brinvex.util.ibkr.impl.IbkrTransactionMapperImpl")
                    .getConstructor()
                    .newInstance();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}
