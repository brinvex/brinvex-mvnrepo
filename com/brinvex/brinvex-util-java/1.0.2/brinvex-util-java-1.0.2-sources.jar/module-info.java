module brinvex.util.java {
    exports com.brinvex.util.java;
    exports com.brinvex.util.java.validation;
    exports com.brinvex.util.java.venndiagram;
}