package com.brinvex.fintypes.enu;

import static java.util.Objects.requireNonNull;

/// Market Identifier Code
///
/// The Market Identifier Code (MIC) (ISO 10383) is a unique identification code
/// used to identify securities trading exchanges, regulated and non-regulated trading markets.
///
/// <a href="https://en.wikipedia.org/wiki/Market_Identifier_Code">https://en.wikipedia.org/wiki/Market_Identifier_Code</a>
public enum Market {

    XPRA(Country.CZ),

    XETR(Country.DE),

    XFRA(Country.DE),

    XNAS(Country.US),

    XNYS(Country.US);

    private final Country country;

    Market(Country country) {
        this.country = requireNonNull(country);
    }

    public Country getCountry() {
        return country;
    }

}

