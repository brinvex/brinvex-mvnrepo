package com.brinvex.fintypes.vo;

import com.brinvex.fintypes.enu.Currency;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDate;

import static java.math.BigDecimal.ZERO;

public record FxRate(
        Currency baseCcy,
        Currency quoteCcy,
        LocalDate fromDateIncl,
        LocalDate toDateIncl,
        BigDecimal rate
) implements Serializable {

    public FxRate {
        if (baseCcy == null) {
            throw new IllegalArgumentException("baseCcy must not be null");
        }
        if (quoteCcy == null) {
            throw new IllegalArgumentException("quoteCcy must not be null");
        }
        if (fromDateIncl != null && toDateIncl != null) {
            if (fromDateIncl.isAfter(toDateIncl)) {
                throw new IllegalArgumentException("fromDateIncl must not be after toDateIncl, %s, %s".formatted(fromDateIncl, toDateIncl));
            }
        }
        if (rate == null || rate.compareTo(ZERO) <= 0) {
            throw new IllegalArgumentException("rate must be greater than zero");
        }
    }

    public FxRate(Currency baseCcy, Currency quoteCcy, BigDecimal rate) {
        this(baseCcy, quoteCcy, null, null, rate);
    }

    public FxRate(Currency baseCcy, Currency quoteCcy, LocalDate fromDateIncl, BigDecimal rate) {
        this(baseCcy, quoteCcy, fromDateIncl, fromDateIncl, rate);
    }

    public FxRate(CurrencyPair ccyPair, LocalDate fromDateIncl, LocalDate toDateIncl, BigDecimal rate) {
        this(ccyPair.baseCcy(), ccyPair.quoteCcy(), fromDateIncl, toDateIncl, rate);
    }

    public FxRate(CurrencyPair ccyPair, LocalDate fromDateIncl, BigDecimal rate) {
        this(ccyPair.baseCcy(), ccyPair.quoteCcy(), fromDateIncl, fromDateIncl, rate);
    }

    @Override
    public String toString() {
        return "%s/%s,%s,%s,%s".formatted(baseCcy, quoteCcy, fromDateIncl, toDateIncl, rate);
    }
}
