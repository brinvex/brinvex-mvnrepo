package com.brinvex.metamodelgen.processor.internal.model;

public interface MetaAttribute {

    String getAttributeNameDeclarationString();

    String getPropertyName();

}
